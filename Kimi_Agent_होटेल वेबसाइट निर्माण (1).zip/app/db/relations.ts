import { relations } from "drizzle-orm";
import { rooms, bookings, calendarSync, seasonalRates, tasks, checkIns } from "./schema";

export const roomsRelations = relations(rooms, ({ many }) => ({
  bookings: many(bookings),
  calendarSyncs: many(calendarSync),
  seasonalRates: many(seasonalRates),
}));

export const bookingsRelations = relations(bookings, ({ one }) => ({
  room: one(rooms, {
    fields: [bookings.roomId],
    references: [rooms.id],
  }),
}));

export const calendarSyncRelations = relations(calendarSync, ({ one }) => ({
  room: one(rooms, {
    fields: [calendarSync.roomId],
    references: [rooms.id],
  }),
}));

export const seasonalRatesRelations = relations(seasonalRates, ({ one }) => ({
  room: one(rooms, {
    fields: [seasonalRates.roomId],
    references: [rooms.id],
  }),
}));

export const tasksRelations = relations(tasks, ({ one }) => ({
  room: one(rooms, {
    fields: [tasks.roomId],
    references: [rooms.id],
  }),
}));

export const checkInsRelations = relations(checkIns, ({ one }) => ({
  booking: one(bookings, {
    fields: [checkIns.bookingId],
    references: [bookings.id],
  }),
}));
