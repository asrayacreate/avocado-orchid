import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  date,
  bigint,
  decimal,
  time,
} from "drizzle-orm/mysql-core";

// ─── Users (auth) ───
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin", "staff", "manager"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type InsertBooking = typeof bookings.$inferInsert;
export type InsertContactMessage = typeof contactMessages.$inferInsert;
export type InsertRoom = typeof rooms.$inferInsert;
export type InsertTask = typeof tasks.$inferInsert;
export type InsertInboxMessage = typeof inboxMessages.$inferInsert;
export type InsertCheckIn = typeof checkIns.$inferInsert;
export type InsertRestaurantOrder = typeof restaurantOrders.$inferInsert;
export type InsertStaff = typeof staff.$inferInsert;

// ─── Rooms ───
export const rooms = mysqlTable("rooms", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  pricePerNight: int("price_per_night").notNull(),
  maxGuests: int("max_guests").notNull().default(2),
  sizeSqFt: int("size_sq_ft"),
  beds: varchar("beds", { length: 255 }),
  amenities: text("amenities"),
  image: varchar("image", { length: 500 }),
  isActive: mysqlEnum("is_active", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type Room = typeof rooms.$inferSelect;

// ─── Bookings ───
export const bookings = mysqlTable("bookings", {
  id: serial("id").primaryKey(),
  roomId: bigint("room_id", { mode: "number", unsigned: true }).notNull(),
  guestName: varchar("guest_name", { length: 255 }).notNull(),
  guestEmail: varchar("guest_email", { length: 320 }).notNull(),
  guestPhone: varchar("guest_phone", { length: 50 }),
  checkIn: date("check_in").notNull(),
  checkOut: date("check_out").notNull(),
  adults: int("adults").notNull().default(2),
  children: int("children").notNull().default(0),
  totalNights: int("total_nights").notNull(),
  totalAmount: int("total_amount").notNull(),
  specialRequests: text("special_requests"),
  status: mysqlEnum("status", ["pending", "confirmed", "cancelled", "completed"]).default("pending").notNull(),
  paymentId: varchar("payment_id", { length: 255 }),
  paymentStatus: mysqlEnum("payment_status", ["Pending", "Paid", "Failed"]).default("Pending").notNull(),
  paymentMethod: varchar("payment_method", { length: 100 }),
  invoiceUrl: varchar("invoice_url", { length: 500 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type Booking = typeof bookings.$inferSelect;

// ─── Contact Messages ───
export const contactMessages = mysqlTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  message: text("message").notNull(),
  isRead: mysqlEnum("is_read", ["read", "unread"]).default("unread").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Phase 2: iCal Sync ───
export const calendarSync = mysqlTable("calendar_sync", {
  id: serial("id").primaryKey(),
  roomId: bigint("room_id", { mode: "number", unsigned: true }).notNull(),
  source: varchar("source", { length: 100 }).notNull(),
  sourceUrl: text("source_url"),
  icalToken: varchar("ical_token", { length: 255 }).notNull().unique(),
  lastSyncAt: timestamp("last_sync_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Phase 4: Coupons ───
export const coupons = mysqlTable("coupons", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  description: text("description"),
  discountType: mysqlEnum("discount_type", ["percentage", "fixed"]).notNull(),
  discountValue: int("discount_value").notNull(),
  maxUses: int("max_uses"),
  usedCount: int("used_count").default(0).notNull(),
  validFrom: date("valid_from").notNull(),
  validUntil: date("valid_until").notNull(),
  isActive: mysqlEnum("is_active", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Phase 4: Seasonal Rates ───
export const seasonalRates = mysqlTable("seasonal_rates", {
  id: serial("id").primaryKey(),
  roomId: bigint("room_id", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  multiplier: decimal("multiplier", { precision: 4, scale: 2 }).notNull(),
  isActive: mysqlEnum("is_active", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Phase 5: Currency Rates ───
export const currencyRates = mysqlTable("currency_rates", {
  id: serial("id").primaryKey(),
  baseCurrency: varchar("base_currency", { length: 10 }).notNull().default("NPR"),
  targetCurrency: varchar("target_currency", { length: 10 }).notNull(),
  rate: decimal("rate", { precision: 12, scale: 6 }).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── NEW: Tasks (Cleaning, Maintenance, Inspection) ───
export const tasks = mysqlTable("tasks", {
  id: serial("id").primaryKey(),
  roomId: bigint("room_id", { mode: "number", unsigned: true }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["cleaning", "maintenance", "inspection", "service", "other"]).notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  status: mysqlEnum("status", ["todo", "in_progress", "done", "cancelled"]).default("todo").notNull(),
  assignedTo: varchar("assigned_to", { length: 255 }),
  dueDate: date("due_date"),
  completedAt: timestamp("completed_at"),
  createdBy: varchar("created_by", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;

// ─── NEW: Unified Inbox (Guest Messages) ───
export const inboxMessages = mysqlTable("inbox_messages", {
  id: serial("id").primaryKey(),
  bookingId: bigint("booking_id", { mode: "number", unsigned: true }),
  guestName: varchar("guest_name", { length: 255 }).notNull(),
  guestEmail: varchar("guest_email", { length: 320 }).notNull(),
  channel: mysqlEnum("channel", ["website", "email", "phone", "whatsapp", "booking_com", "agoda", "airbnb"]).default("website").notNull(),
  subject: varchar("subject", { length: 255 }),
  message: text("message").notNull(),
  reply: text("reply"),
  isReplied: mysqlEnum("is_replied", ["yes", "no"]).default("no").notNull(),
  assignedTo: varchar("assigned_to", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type InboxMessage = typeof inboxMessages.$inferSelect;

// ─── NEW: Online Check-ins ───
export const checkIns = mysqlTable("check_ins", {
  id: serial("id").primaryKey(),
  bookingId: bigint("booking_id", { mode: "number", unsigned: true }).notNull(),
  guestName: varchar("guest_name", { length: 255 }).notNull(),
  guestEmail: varchar("guest_email", { length: 320 }).notNull(),
  guestPhone: varchar("guest_phone", { length: 50 }),
  idDocument: varchar("id_document", { length: 500 }),
  arrivalTime: time("arrival_time"),
  numberOfGuests: int("number_of_guests").default(1).notNull(),
  vehicleNumber: varchar("vehicle_number", { length: 50 }),
  specialRequests: text("special_requests"),
  signature: text("signature"),
  status: mysqlEnum("status", ["pending", "completed"]).default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type CheckIn = typeof checkIns.$inferSelect;

// ─── NEW: Restaurant Orders ───
export const restaurantOrders = mysqlTable("restaurant_orders", {
  id: serial("id").primaryKey(),
  tableNumber: varchar("table_number", { length: 50 }),
  guestName: varchar("guest_name", { length: 255 }).notNull(),
  roomNumber: varchar("room_number", { length: 50 }),
  items: text("items").notNull(),
  totalAmount: int("total_amount").notNull(),
  orderType: mysqlEnum("order_type", ["dine_in", "room_service", "takeaway"]).default("dine_in").notNull(),
  status: mysqlEnum("status", ["pending", "preparing", "ready", "served", "cancelled"]).default("pending").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type RestaurantOrder = typeof restaurantOrders.$inferSelect;

// ─── NEW: Staff Members ───
export const staff = mysqlTable("staff", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  position: mysqlEnum("position", ["manager", "receptionist", "housekeeping", "chef", "waiter", "maintenance", "security"]).notNull(),
  department: varchar("department", { length: 100 }),
  salary: int("salary"),
  isActive: mysqlEnum("is_active", ["active", "inactive"]).default("active").notNull(),
  joinedDate: date("joined_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Staff = typeof staff.$inferSelect;

// ═══════════════════════════════════════════════
// PHASE 7: AUTOMATION
// ═══════════════════════════════════════════════

// ─── Email/SMS Log ───
export const notificationLogs = mysqlTable("notification_logs", {
  id: serial("id").primaryKey(),
  bookingId: bigint("booking_id", { mode: "number", unsigned: true }),
  type: mysqlEnum("type", ["email", "sms", "whatsapp"]).notNull(),
  recipient: varchar("recipient", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 255 }),
  content: text("content"),
  status: mysqlEnum("status", ["sent", "failed", "queued"]).default("queued").notNull(),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Chatbot Conversations ───
export const chatbotConversations = mysqlTable("chatbot_conversations", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 100 }).notNull(),
  guestName: varchar("guest_name", { length: 255 }),
  message: text("message").notNull(),
  response: text("response"),
  isHandledByHuman: mysqlEnum("is_handled_by_human", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Review Requests ───
export const reviewRequests = mysqlTable("review_requests", {
  id: serial("id").primaryKey(),
  bookingId: bigint("booking_id", { mode: "number", unsigned: true }).notNull(),
  guestEmail: varchar("guest_email", { length: 320 }).notNull(),
  guestName: varchar("guest_name", { length: 255 }),
  status: mysqlEnum("status", ["pending", "sent", "responded"]).default("pending").notNull(),
  rating: int("rating"),
  reviewText: text("review_text"),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ═══════════════════════════════════════════════
// PHASE 8: HOUSEKEEPING
// ═══════════════════════════════════════════════

// ─── Room Status (Real-time) ───
export const roomStatuses = mysqlTable("room_statuses", {
  id: serial("id").primaryKey(),
  roomId: bigint("room_id", { mode: "number", unsigned: true }).notNull(),
  status: mysqlEnum("status", ["clean", "dirty", "inspected", "out_of_order", "repairing"]).default("clean").notNull(),
  housekeeperName: varchar("housekeeper_name", { length: 255 }),
  cleanedAt: timestamp("cleaned_at"),
  notes: text("notes"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Maintenance Schedule ───
export const maintenanceSchedules = mysqlTable("maintenance_schedules", {
  id: serial("id").primaryKey(),
  roomId: bigint("room_id", { mode: "number", unsigned: true }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  equipment: varchar("equipment", { length: 255 }),
  frequency: mysqlEnum("frequency", ["daily", "weekly", "monthly", "quarterly", "yearly"]).notNull(),
  lastDone: date("last_done"),
  nextDue: date("next_due").notNull(),
  assignedTo: varchar("assigned_to", { length: 255 }),
  isActive: mysqlEnum("is_active", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Lost & Found ───
export const lostAndFound = mysqlTable("lost_and_found", {
  id: serial("id").primaryKey(),
  bookingId: bigint("booking_id", { mode: "number", unsigned: true }),
  guestName: varchar("guest_name", { length: 255 }),
  itemName: varchar("item_name", { length: 255 }).notNull(),
  description: text("description"),
  foundDate: date("found_date").notNull(),
  foundLocation: varchar("found_location", { length: 255 }),
  status: mysqlEnum("status", ["found", "claimed", "returned", "disposed"]).default("found").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ═══════════════════════════════════════════════
// PHASE 9: ACCOUNTING
// ═══════════════════════════════════════════════

// ─── Daily Cash Register ───
export const cashRegisters = mysqlTable("cash_registers", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  openingBalance: int("opening_balance").notNull().default(0),
  closingBalance: int("closing_balance"),
  totalIncome: int("total_income").default(0).notNull(),
  totalExpense: int("total_expense").default(0).notNull(),
  notes: text("notes"),
  closedBy: varchar("closed_by", { length: 255 }),
  isClosed: mysqlEnum("is_closed", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Expenses ───
export const expenses = mysqlTable("expenses", {
  id: serial("id").primaryKey(),
  category: mysqlEnum("category", ["salary", "electricity", "water", "food", "maintenance", "marketing", "tax", "other"]).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  amount: int("amount").notNull(),
  paidTo: varchar("paid_to", { length: 255 }),
  date: date("date").notNull(),
  receiptUrl: varchar("receipt_url", { length: 500 }),
  createdBy: varchar("created_by", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ═══════════════════════════════════════════════
// PHASE 11: LOYALTY & REFERRAL
// ═══════════════════════════════════════════════

// ─── Loyalty Points ───
export const loyaltyMembers = mysqlTable("loyalty_members", {
  id: serial("id").primaryKey(),
  guestEmail: varchar("guest_email", { length: 320 }).notNull().unique(),
  guestName: varchar("guest_name", { length: 255 }),
  totalPoints: int("total_points").default(0).notNull(),
  tier: mysqlEnum("tier", ["bronze", "silver", "gold", "platinum"]).default("bronze").notNull(),
  totalSpent: int("total_spent").default(0).notNull(),
  visitCount: int("visit_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Referrals ───
export const referrals = mysqlTable("referrals", {
  id: serial("id").primaryKey(),
  referrerEmail: varchar("referrer_email", { length: 320 }).notNull(),
  refereeName: varchar("referee_name", { length: 255 }).notNull(),
  refereeEmail: varchar("referee_email", { length: 320 }).notNull(),
  status: mysqlEnum("status", ["pending", "booked", "completed", "rewarded"]).default("pending").notNull(),
  rewardPoints: int("reward_points").default(500),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ═══════════════════════════════════════════════
// PHASE 12: ADVANCED
// ═══════════════════════════════════════════════

// ─── AI Pricing Rules ───
export const aiPricingRules = mysqlTable("ai_pricing_rules", {
  id: serial("id").primaryKey(),
  roomId: bigint("room_id", { mode: "number", unsigned: true }),
  name: varchar("name", { length: 255 }).notNull(),
  condition: mysqlEnum("condition", ["occupancy_high", "occupancy_low", "weekend", "holiday", "advance_booking", "last_minute"]).notNull(),
  threshold: int("threshold"),
  adjustmentType: mysqlEnum("adjustment_type", ["increase_pct", "decrease_pct", "fixed_amount"]).notNull(),
  adjustmentValue: int("adjustment_value").notNull(),
  isActive: mysqlEnum("is_active", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Multi-Property ───
export const properties = mysqlTable("properties", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 320 }),
  isActive: mysqlEnum("is_active", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Activity Log ───
export const activityLogs = mysqlTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }),
  userName: varchar("user_name", { length: 255 }),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entity_type", { length: 50 }),
  entityId: bigint("entity_id", { mode: "number", unsigned: true }),
  details: text("details"),
  ipAddress: varchar("ip_address", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Type Exports ───
export type InsertNotificationLog = typeof notificationLogs.$inferInsert;
export type InsertChatbotConversation = typeof chatbotConversations.$inferInsert;
export type InsertReviewRequest = typeof reviewRequests.$inferInsert;
export type InsertRoomStatus = typeof roomStatuses.$inferInsert;
export type InsertMaintenanceSchedule = typeof maintenanceSchedules.$inferInsert;
export type InsertLostAndFound = typeof lostAndFound.$inferInsert;
export type InsertCashRegister = typeof cashRegisters.$inferInsert;
export type InsertExpense = typeof expenses.$inferInsert;
export type InsertLoyaltyMember = typeof loyaltyMembers.$inferInsert;
export type InsertReferral = typeof referrals.$inferInsert;
export type InsertAIPricingRule = typeof aiPricingRules.$inferInsert;
export type InsertProperty = typeof properties.$inferInsert;
export type InsertActivityLog = typeof activityLogs.$inferInsert;
