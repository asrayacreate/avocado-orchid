// Demo data for admin pages when backend is unavailable

export const mockBookings = [
  { id: 1, guestName: 'Ram Sharma', guestEmail: 'ram@email.com', guestPhone: '+977 9801234567', checkIn: '2025-06-15', checkOut: '2025-06-18', adults: 2, children: 1, totalNights: 3, totalAmount: 10500, status: 'confirmed', paymentStatus: 'Paid', paymentMethod: 'Khalti', roomName: 'Super Deluxe A/C', createdAt: '2025-06-01T10:30:00' },
  { id: 2, guestName: 'Sita Devi', guestEmail: 'sita@email.com', guestPhone: '+977 9812345678', checkIn: '2025-06-20', checkOut: '2025-06-22', adults: 2, children: 0, totalNights: 2, totalAmount: 7000, status: 'pending', paymentStatus: 'Pending', paymentMethod: null, roomName: 'Deluxe A/C', createdAt: '2025-06-02T14:15:00' },
  { id: 3, guestName: 'Pablo Morales', guestEmail: 'pablo@email.com', guestPhone: '+7 9998887776', checkIn: '2025-06-25', checkOut: '2025-06-28', adults: 2, children: 2, totalNights: 3, totalAmount: 22500, status: 'confirmed', paymentStatus: 'Paid', paymentMethod: 'eSewa', roomName: 'Suite', createdAt: '2025-06-03T09:00:00' },
  { id: 4, guestName: 'John Smith', guestEmail: 'john@email.com', guestPhone: '+1 5554443333', checkIn: '2025-07-01', checkOut: '2025-07-05', adults: 2, children: 0, totalNights: 4, totalAmount: 18000, status: 'confirmed', paymentStatus: 'Paid', paymentMethod: 'Stripe', roomName: 'Semi Suite', createdAt: '2025-06-04T16:45:00' },
  { id: 5, guestName: 'Anita Gurung', guestEmail: 'anita@email.com', guestPhone: '+977 9823456789', checkIn: '2025-07-10', checkOut: '2025-07-12', adults: 3, children: 0, totalNights: 2, totalAmount: 7000, status: 'pending', paymentStatus: 'Pending', paymentMethod: null, roomName: 'Deluxe A/C', createdAt: '2025-06-05T11:20:00' },
  { id: 6, guestName: 'David Chen', guestEmail: 'david@email.com', guestPhone: '+86 13800138000', checkIn: '2025-07-15', checkOut: '2025-07-18', adults: 2, children: 1, totalNights: 3, totalAmount: 13500, status: 'confirmed', paymentStatus: 'Paid', paymentMethod: 'Khalti', roomName: 'Super Deluxe A/C', createdAt: '2025-06-06T08:30:00' },
]

export const mockMessages = [
  { id: 1, name: 'Ram Sharma', email: 'ram@email.com', phone: '+977 9801234567', message: 'Do you provide airport pickup service from Kathmandu?', isRead: 'unread', createdAt: '2025-06-08T10:30:00' },
  { id: 2, name: 'Pablo Morales', email: 'pablo@email.com', phone: '+7 9998887776', message: 'Thank you for the wonderful stay! The orchid garden was breathtaking. Will definitely come back next year.', isRead: 'read', createdAt: '2025-06-07T14:15:00' },
  { id: 3, name: 'Sita Devi', email: 'sita@email.com', phone: '+977 9812345678', message: 'Can I get a room with orchid garden view? Also, do you have wheelchair accessibility?', isRead: 'unread', createdAt: '2025-06-06T09:45:00' },
  { id: 4, name: 'John Smith', email: 'john@email.com', phone: '+1 5554443333', message: 'Is there a conference hall available for 50 people? We need it for 2 days with projector and Wi-Fi.', isRead: 'read', createdAt: '2025-06-05T16:20:00' },
  { id: 5, name: 'Priya Patel', email: 'priya@email.com', phone: '+91 9876543210', message: 'We are a group of 15 people visiting in July. Can you arrange a group discount and package?', isRead: 'unread', createdAt: '2025-06-04T11:00:00' },
]

export const mockStaff = [
  { id: 1, name: 'Hari Bahadur', role: 'Manager', department: 'Front Desk', phone: '+977 9801112222', status: 'active', joined: '2018-03-15' },
  { id: 2, name: 'Gita Kumari', role: 'Receptionist', department: 'Front Desk', phone: '+977 9802223333', status: 'active', joined: '2020-06-01' },
  { id: 3, name: 'Ram Prasad', role: 'Head Chef', department: 'Kitchen', phone: '+977 9803334444', status: 'active', joined: '2019-01-10' },
  { id: 4, name: 'Sunita Devi', role: 'Housekeeping', department: 'Housekeeping', phone: '+977 9804445555', status: 'active', joined: '2021-04-20' },
  { id: 5, name: 'Bikash Thapa', role: 'Security', department: 'Security', phone: '+977 9805556666', status: 'on-leave', joined: '2020-09-05' },
  { id: 6, name: 'Maya Gurung', role: 'Waitress', department: 'Restaurant', phone: '+977 9806667777', status: 'active', joined: '2022-02-14' },
]

export const mockTasks = [
  { id: 1, title: 'Clean Room 101', type: 'cleaning', priority: 'high', status: 'pending', roomNumber: '101', assignedTo: 'Sunita Devi', dueDate: '2025-06-08' },
  { id: 2, title: 'Fix AC in Room 205', type: 'maintenance', priority: 'high', status: 'in-progress', roomNumber: '205', assignedTo: 'Ram Prasad', dueDate: '2025-06-08' },
  { id: 3, title: 'Garden watering', type: 'maintenance', priority: 'low', status: 'completed', roomNumber: null, assignedTo: 'Bikash Thapa', dueDate: '2025-06-07' },
  { id: 4, title: 'Inspect Room 302', type: 'inspection', priority: 'medium', status: 'pending', roomNumber: '302', assignedTo: 'Hari Bahadur', dueDate: '2025-06-09' },
  { id: 5, title: 'Restaurant deep clean', type: 'cleaning', priority: 'medium', status: 'in-progress', roomNumber: null, assignedTo: 'Sunita Devi', dueDate: '2025-06-08' },
]

export const mockOrders = [
  { id: 1, roomNumber: '205', guestName: 'Pablo Morales', items: 'Chicken Momo x2, Fried Rice, Beer x2', total: 2800, status: 'completed', type: 'room-service', createdAt: '2025-06-07T19:30:00' },
  { id: 2, roomNumber: '102', guestName: 'John Smith', items: 'Breakfast Buffet x2, Cappuccino x2', total: 1600, status: 'in-progress', type: 'restaurant', createdAt: '2025-06-08T08:15:00' },
  { id: 3, roomNumber: null, guestName: 'Walk-in', items: 'Dal Bhat x4, Coke x4', total: 2400, status: 'pending', type: 'restaurant', createdAt: '2025-06-08T12:45:00' },
  { id: 4, roomNumber: '301', guestName: 'Anita Gurung', items: 'Sandwich, Latte, Fruit Salad', total: 950, status: 'completed', type: 'cafe', createdAt: '2025-06-08T15:20:00' },
]

export const mockRooms = [
  { id: 1, name: 'Deluxe A/C', number: '101-120', status: 'clean', floor: 1, price: 3500 },
  { id: 2, name: 'Super Deluxe A/C', number: '201-215', status: 'occupied', floor: 2, price: 4500 },
  { id: 3, name: 'Semi Suite', number: '301-310', status: 'cleaning', floor: 3, price: 5500 },
  { id: 4, name: 'Suite', number: '401-405', status: 'occupied', floor: 4, price: 7500 },
]

// Safe tRPC query wrapper
export const safeQuery = (queryFn: any) => {
  try {
    return queryFn
  } catch {
    return { data: undefined, isLoading: false, error: null }
  }
}
