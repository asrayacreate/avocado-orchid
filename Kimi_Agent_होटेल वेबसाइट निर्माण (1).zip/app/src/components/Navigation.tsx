import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Menu, X, Phone, LayoutDashboard, User, Globe } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { useLanguage } from '@/contexts/LanguageContext'

const Navigation = () => {
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const location = useLocation()
  const { user, isAuthenticated, logout } = useAuth()
  const { _, toggleLang, isNepali } = useLanguage()
  const isAdmin = user?.role === 'admin'

  const isHome = location.pathname === '/'

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => { setMobileMenuOpen(false) }, [location])

  const navLinks = [
    { to: '/', label: _('home') },
    { to: '/rooms', label: _('rooms') },
    { to: '/dining', label: _('dining') },
    { to: '/gallery', label: _('gallery') },
  ]

  const showTransparent = isHome && !scrolled && !mobileMenuOpen

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${
          showTransparent ? 'bg-transparent' : 'bg-cream/95 backdrop-blur-xl shadow-[0_2px_20px_rgba(0,0,0,0.06)]'
        }`}>
        <div className="max-w-[1280px] mx-auto px-6 lg:px-10 h-[72px] flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-full flex items-center justify-center border-2 transition-colors duration-400 ${
              showTransparent ? 'border-white/40' : 'border-avocado'
            }`}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M12 2C8 6 4 10 4 14c0 4.4 3.6 8 8 8s8-3.6 8-8c0-4-4-8-8-12z" fill={showTransparent ? '#c8a55c' : '#2d5a2d'} />
                <circle cx="12" cy="14" r="3" fill={showTransparent ? '#ffffff' : '#f5f0e8'} />
              </svg>
            </div>
            <div className="hidden sm:block">
              <div className={`font-display font-bold text-[15px] leading-tight transition-colors duration-400 ${showTransparent ? 'text-white' : 'text-avocado-dark'}`}>
                Avocado & Orchid Resort
              </div>
              <div className="text-[10px] tracking-[0.15em] font-medium text-gold">
                HETAUDA, NEPAL
              </div>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center gap-9">
            {navLinks.map((link) => (
              <Link key={link.to} to={link.to}
                className={`text-sm font-medium tracking-[0.06em] transition-colors duration-300 hover:text-gold ${
                  showTransparent ? 'text-white/90' : 'text-avocado-dark'
                } ${location.pathname === link.to ? 'text-gold' : ''}`}>
                {link.label}
              </Link>
            ))}
            {isAdmin && (
              <Link to="/admin"
                className={`text-sm font-medium tracking-[0.06em] transition-colors duration-300 flex items-center gap-1.5 ${
                  showTransparent ? 'text-gold' : 'text-avocado'
                } ${location.pathname.startsWith('/admin') ? 'text-gold' : ''}`}>
                <LayoutDashboard size={14} /> {_('admin')}
              </Link>
            )}
            {isAuthenticated && (
              <Link to="/portal"
                className={`text-sm font-medium tracking-[0.06em] transition-colors duration-300 flex items-center gap-1.5 ${
                  showTransparent ? 'text-white/90' : 'text-avocado-dark'
                } ${location.pathname === '/portal' ? 'text-gold' : ''}`}>
                <User size={14} /> {_('myAccount')}
              </Link>
            )}
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-3">
            {/* Language Switcher */}
            <button
              onClick={toggleLang}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-300 border ${
                showTransparent
                  ? 'border-white/30 text-white hover:bg-white/10'
                  : 'border-avocado/30 text-avocado-dark hover:bg-avocado/10'
              }`}
              title={isNepali ? 'Switch to English' : 'अंग्रेजीमा बदल्नुहोस्'}
            >
              <Globe size={13} />
              {isNepali ? 'EN' : 'नेपा'}
            </button>

            <a href="tel:+9779801804340"
              className={`hidden md:flex items-center gap-2 text-sm font-medium transition-colors duration-400 ${showTransparent ? 'text-white/80' : 'text-avocado-dark'}`}>
              <Phone size={15} />
              <span>+977 980 1804340</span>
            </a>

            {isAuthenticated ? (
              <div className="hidden sm:flex items-center gap-3">
                <span className={`text-sm font-medium ${showTransparent ? 'text-white/80' : 'text-avocado-dark'}`}>{user?.name}</span>
                <button onClick={logout}
                  className={`text-sm font-medium transition-colors ${showTransparent ? 'text-white/60 hover:text-white' : 'text-text-muted hover:text-avocado-dark'}`}>
                  {_('logout')}
                </button>
              </div>
            ) : (
              <Link to="/login"
                className={`hidden sm:inline-block px-5 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
                  showTransparent ? 'bg-white/10 text-white border border-white/30 hover:bg-white/20' : 'bg-avocado/10 text-avocado border border-avocado/30 hover:bg-avocado/20'
                }`}>
                {_('login')}
              </Link>
            )}

            <Link to="/rooms"
              className={`px-5 py-2.5 rounded-full text-sm font-semibold tracking-wide transition-all duration-300 hover:-translate-y-0.5 ${
                showTransparent ? 'bg-gold text-forest hover:bg-gold-light shadow-button' : 'bg-avocado text-white hover:bg-avocado-light shadow-button'
              }`}>
              {_('bookNow')}
            </Link>

            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`lg:hidden p-2 transition-colors ${showTransparent ? 'text-white' : 'text-avocado-dark'}`}>
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 z-40 bg-forest transition-all duration-500 lg:hidden ${mobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
        <div className="flex flex-col items-center justify-center h-full gap-8 pt-20">
          {[...navLinks, ...(isAdmin ? [{ to: '/admin', label: _('admin') }] : []), ...(isAuthenticated ? [{ to: '/portal', label: _('myAccount') }] : [])].map((link) => (
            <Link key={link.to} to={link.to} onClick={() => setMobileMenuOpen(false)}
              className="text-white font-display text-3xl hover:text-gold transition-colors">{link.label}</Link>
          ))}
          <button onClick={toggleLang}
            className="flex items-center gap-2 text-gold font-display text-2xl hover:text-white transition-colors">
            <Globe size={24} /> {isNepali ? 'Switch to English' : 'नेपालीमा बदल्नुहोस्'}
          </button>
          {isAuthenticated ? (
            <button onClick={() => { logout(); setMobileMenuOpen(false); }}
              className="text-gold font-display text-2xl hover:text-white transition-colors">{_('logout')} ({user?.name})</button>
          ) : (
            <Link to="/login" onClick={() => setMobileMenuOpen(false)}
              className="text-gold font-display text-2xl hover:text-white transition-colors">{_('login')}</Link>
          )}
        </div>
      </div>
    </>
  )
}

export default Navigation
