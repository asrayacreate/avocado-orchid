import { Outlet } from 'react-router-dom'
import Navigation from './Navigation'
import Footer from './Footer'
import BookingWidget from './BookingWidget'
import SecretAdminAccess from './SecretAdminAccess'
import ScrollToTop from './ScrollToTop'

export default function Layout() {
  return (
    <div className="min-h-screen bg-cream">
      <Navigation />
      <main>
        <Outlet />
      </main>
      <Footer />
      <BookingWidget />
      <SecretAdminAccess />
      <ScrollToTop />
    </div>
  )
}
