import { Link } from 'react-router-dom'
import { MapPin, Phone, Mail, Clock, Lock } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

const Footer = () => {
  const { _ } = useLanguage()

  const quickLinks = [
    { to: '/', label: _('home') },
    { to: '/rooms', label: _('rooms') },
    { to: '/dining', label: _('dining') },
    { to: '/gallery', label: _('gallery') },
    { to: '/#contact', label: _('contact') },
  ]

  return (
    <footer className="bg-avocado-dark text-white">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10 pt-20 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-14 h-14 rounded-full border-2 border-gold flex items-center justify-center">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2C8 6 4 10 4 14c0 4.4 3.6 8 8 8s8-3.6 8-8c0-4-4-8-8-12z" fill="#c8a55c" />
                  <circle cx="12" cy="14" r="3" fill="#f5f0e8" />
                </svg>
              </div>
              <div><div className="font-display font-semibold text-lg">Avocado & Orchid Resort</div></div>
            </div>
            <p className="text-sm text-white/60 leading-relaxed">{_('exclusiveAccommodation')}</p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs tracking-[0.08em] font-semibold text-gold uppercase mb-5">{_('quickLinks')}</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sm text-white/70 hover:text-white transition-colors">{link.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xs tracking-[0.08em] font-semibold text-gold uppercase mb-5">{_('contactUs')}</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin size={16} className="text-gold mt-0.5 shrink-0" />
                <span className="text-sm text-white/70">{_('address')}</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={16} className="text-gold shrink-0" />
                <a href="tel:+9779801804340" className="text-sm text-white/70 hover:text-white transition-colors">+977 980 1804340</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={16} className="text-gold shrink-0" />
                <a href="mailto:info@avocadoresort.com" className="text-sm text-white/70 hover:text-white transition-colors">info@avocadoresort.com</a>
              </li>
              <li className="flex items-center gap-3">
                <Clock size={16} className="text-gold shrink-0" />
                <span className="text-sm text-white/70">{_('checkInOut')}</span>
              </li>
            </ul>
          </div>

          {/* Location Map */}
          <div>
            <h4 className="text-xs tracking-[0.08em] font-semibold text-gold uppercase mb-5">{_('ourLocation')}</h4>
            <div className="rounded-xl overflow-hidden shadow-card">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3544.3320620474694!2d85.0326873148929!3d27.42842114346325!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb498e2f6c0d87%3A0x3d1ad26e1e9f2f8e!2sAvocado%20%26%20Orchid%20Resort!5e0!3m2!1sen!2snp!4v1700000000000!5m2!1sen!2snp"
                width="100%" height="180" style={{ border: 0 }} allowFullScreen loading="lazy"
                referrerPolicy="no-referrer-when-downgrade" title="Avocado & Orchid Resort Location" />
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/40">&copy; 2025 Avocado & Orchid Resort. {_('allRightsReserved')}</p>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('open-admin-modal'))}
            className="flex items-center gap-1.5 text-xs text-white/30 hover:text-gold transition-colors"
          >
            <Lock size={10} /> Staff / Admin Access
          </button>
        </div>
      </div>
    </footer>
  )
}

export default Footer
