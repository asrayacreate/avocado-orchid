import { useState } from 'react'
import { Link, useLocation, Outlet } from 'react-router-dom'
import {
  LayoutDashboard, CalendarDays, Mail, LogOut, ChevronLeft, Hotel,
  Tag, ClipboardList, Inbox, ChefHat, Users, ClipboardCheck,
  Bot, Sparkles, DollarSign, Crown, PanelLeftClose, PanelLeft,
  Settings, BarChart3, Image,
} from 'lucide-react'
import { useApp } from '@/contexts/AppContext'

const navGroups = [
  { label: 'Main', items: [
    { to: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/admin/calendar', label: 'Calendar', icon: CalendarDays },
    { to: '/admin/bookings', label: 'Bookings', icon: ClipboardCheck },
    { to: '/admin/messages', label: 'Messages', icon: Mail },
  ]},
  { label: 'Operations', items: [
    { to: '/admin/tasks', label: 'Tasks', icon: ClipboardList },
    { to: '/admin/restaurant', label: 'Restaurant', icon: ChefHat },
    { to: '/admin/staff', label: 'Staff', icon: Users },
    { to: '/admin/housekeeping', label: 'Housekeeping', icon: Sparkles },
  ]},
  { label: 'Finance', items: [
    { to: '/admin/accounting', label: 'Accounting', icon: DollarSign },
    { to: '/admin/coupons', label: 'Coupons', icon: Tag },
    { to: '/admin/loyalty', label: 'Loyalty', icon: Crown },
  ]},
  { label: 'Advanced', items: [
    { to: '/admin/inbox', label: 'Inbox', icon: Inbox },
    { to: '/admin/automation', label: 'Automation', icon: Bot },
    { to: '/admin/reports', label: 'Reports', icon: BarChart3 },
    { to: '/admin/banners', label: 'Banners', icon: Image },
    { to: '/admin/settings', label: 'Settings', icon: Settings },
  ]},
]

export default function AdminLayout() {
  const location = useLocation()
  const { isAdminActive, setAdminActive, sidebarCollapsed, setSidebarCollapsed } = useApp()
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleLogout = () => {
    localStorage.removeItem('admin-session')
    localStorage.removeItem('admin-email')
    setAdminActive(false)
    window.location.href = '/'
  }

  const sidebarW = sidebarCollapsed ? 'w-20' : 'w-64'
  const mainMl = sidebarCollapsed ? 'ml-20' : 'ml-64'

  const renderSidebarContent = () => (
    <>
      {/* Logo */}
      <div className="p-5 border-b border-white/10 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <Hotel size={24} className="text-gold shrink-0" />
          {!sidebarCollapsed && (
            <div>
              <div className="font-display font-semibold text-sm leading-tight">Avocado & Orchid</div>
              <div className="text-[9px] text-white/40 tracking-wider">PMS ADMIN</div>
            </div>
          )}
        </Link>
        {!sidebarCollapsed && (
          <button onClick={() => setSidebarCollapsed(true)} className="text-white/30 hover:text-white/60">
            <PanelLeftClose size={16} />
          </button>
        )}
        {sidebarCollapsed && (
          <button onClick={() => setSidebarCollapsed(false)} className="text-white/30 hover:text-white/60 mx-auto">
            <PanelLeft size={16} />
          </button>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 px-2 overflow-y-auto">
        {navGroups.map((group) => (
          <div key={group.label} className="mb-4">
            {!sidebarCollapsed && (
              <p className="px-4 text-[10px] font-semibold text-white/25 uppercase tracking-wider mb-1">{group.label}</p>
            )}
            {group.items.map((item) => {
              const Icon = item.icon
              const isActive = location.pathname === item.to
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    isActive ? 'bg-gold/20 text-gold' : 'text-white/50 hover:text-white hover:bg-white/5'
                  } ${sidebarCollapsed ? 'justify-center' : ''}`}
                  title={sidebarCollapsed ? item.label : undefined}
                >
                  <Icon size={18} className="shrink-0" />
                  {!sidebarCollapsed && <span>{item.label}</span>}
                </Link>
              )
            })}
          </div>
        ))}
      </nav>

      {/* User */}
      <div className="p-4 border-t border-white/10 space-y-2">
        <div className={`flex items-center gap-3 px-3 py-2 ${sidebarCollapsed ? 'justify-center' : ''}`}>
          <div className="w-8 h-8 rounded-full bg-gold/20 flex items-center justify-center shrink-0">
            <span className="text-gold text-xs font-bold">A</span>
          </div>
          {!sidebarCollapsed && (
            <div className="text-sm min-w-0">
              <div className="text-white font-medium truncate">Admin User</div>
              <div className="text-white/30 text-[10px]">{isAdminActive ? 'super-admin' : 'demo'}</div>
            </div>
          )}
        </div>
        {!sidebarCollapsed && (
          <>
            <Link to="/" className="flex items-center gap-3 px-3 py-2 text-sm text-white/40 hover:text-white transition-colors">
              <ChevronLeft size={16} /> Back to Site
            </Link>
            <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2 text-sm text-white/40 hover:text-red-400 transition-colors w-full">
              <LogOut size={16} /> Logout
            </button>
          </>
        )}
        {sidebarCollapsed && (
          <button onClick={handleLogout} className="flex items-center justify-center w-full py-2 text-white/40 hover:text-red-400">
            <LogOut size={16} />
          </button>
        )}
      </div>
    </>
  )

  return (
    <div className="min-h-screen bg-[#f5f3ef] flex">
      {/* Desktop Sidebar */}
      <aside className={`hidden md:flex ${sidebarW} bg-[#1a2e1a] text-white flex-col fixed h-full z-30 transition-all duration-300`}>
        {renderSidebarContent()}
      </aside>

      {/* Mobile Sidebar Overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden" onClick={() => setMobileOpen(false)}>
          <div className="absolute inset-0 bg-black/50" />
          <aside className="absolute left-0 top-0 bottom-0 w-64 bg-[#1a2e1a] text-white flex flex-col" onClick={(e) => e.stopPropagation()}>
            {renderSidebarContent()}
          </aside>
        </div>
      )}

      {/* Mobile Toggle */}
      <button
        onClick={() => setMobileOpen(true)}
        className="md:hidden fixed top-4 left-4 z-30 w-10 h-10 bg-[#1a2e1a] text-white rounded-lg flex items-center justify-center shadow-lg"
      >
        <PanelLeft size={20} />
      </button>

      {/* Main Content */}
      <main className={`flex-1 ${mainMl} transition-all duration-300 min-w-0`}>
        {!isAdminActive && (
          <div className="bg-amber-50 border-b border-amber-200 px-6 py-2 text-xs text-amber-700 flex items-center justify-between">
            <span>Demo Mode — Secret login: Press 5 then Ctrl+Shift+A</span>
            <span className="hidden sm:inline">admin@avocadoresort.com / admin123 / 123456</span>
          </div>
        )}
        <div className="p-6 lg:p-10">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
