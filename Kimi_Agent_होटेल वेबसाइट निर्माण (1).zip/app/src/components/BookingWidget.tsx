import { useState, useEffect } from 'react'
import { Calendar, X } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

export default function BookingWidget() {
  const { _ } = useLanguage()
  const [isOpen, setIsOpen] = useState(false)
  const [minimized, setMinimized] = useState(false)
  const [step, setStep] = useState<'form' | 'payment' | 'success'>('form')
  const [checkIn, setCheckIn] = useState('')
  const [checkOut, setCheckOut] = useState('')
  const [adults, setAdults] = useState(2)
  const [children, setChildren] = useState(0)
  const [guestName, setGuestName] = useState('')
  const [guestEmail, setGuestEmail] = useState('')
  const [guestPhone, setGuestPhone] = useState('')

  // Auto-collapse to minimized FAB when scrolling past 300px
  useEffect(() => {
    let lastY = 0
    const onScroll = () => {
      const y = window.scrollY
      if (y > 300 && y > lastY && !isOpen) {
        setMinimized(true)
      }
      if (y < 100 || y < lastY) {
        setMinimized(false)
      }
      lastY = y
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [isOpen])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!checkIn || !checkOut || !guestName || !guestEmail) return
    setStep('success')
    setTimeout(() => { setStep('form'); setIsOpen(false) }, 3000)
  }

  const openWidget = () => { setIsOpen(true); setMinimized(false) }

  return (
    <>
      {/* Floating FAB - shows when minimized and not open */}
      {!isOpen && (
        <button
          onClick={openWidget}
          className={`fixed z-50 flex items-center gap-2 bg-gold text-forest font-semibold rounded-full shadow-lg hover:-translate-y-0.5 transition-all duration-300 ${
            minimized ? 'bottom-6 right-6 px-4 py-3 text-xs' : 'bottom-6 right-6 px-6 py-4 text-sm'
          }`}
        >
          <Calendar size={minimized ? 16 : 18} />
          {!minimized && <span>{_('checkAvailability')}</span>}
        </button>
      )}

      {/* Expanded Panel */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsOpen(false)} />
          <div className="relative bg-white rounded-t-2xl sm:rounded-2xl w-full sm:w-[500px] sm:mx-4 max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-display font-semibold text-xl text-avocado-dark">{_('bookYourStay')}</h3>
                <button onClick={() => setIsOpen(false)} className="w-8 h-8 rounded-full bg-cream flex items-center justify-center hover:bg-sand"><X size={16} /></button>
              </div>

              {step === 'success' ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  </div>
                  <h4 className="font-display font-semibold text-xl text-avocado-dark mb-2">{_('thankYou')}</h4>
                  <p className="text-text-muted">{_('messageReply')}</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="text-xs font-medium text-text-muted mb-1 block">{_('checkIn')}</label><input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className="w-full px-3 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" required /></div>
                    <div><label className="text-xs font-medium text-text-muted mb-1 block">{_('checkOut')}</label><input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} className="w-full px-3 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" required /></div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="text-xs font-medium text-text-muted mb-1 block">{_('adults')}</label><input type="number" min={1} max={10} value={adults} onChange={(e) => setAdults(Number(e.target.value))} className="w-full px-3 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" /></div>
                    <div><label className="text-xs font-medium text-text-muted mb-1 block">{_('children')}</label><input type="number" min={0} max={10} value={children} onChange={(e) => setChildren(Number(e.target.value))} className="w-full px-3 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" /></div>
                  </div>
                  <div><label className="text-xs font-medium text-text-muted mb-1 block">{_('yourName')}</label><input type="text" value={guestName} onChange={(e) => setGuestName(e.target.value)} className="w-full px-3 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" required placeholder="Full name" /></div>
                  <div><label className="text-xs font-medium text-text-muted mb-1 block">{_('emailAddress')}</label><input type="email" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} className="w-full px-3 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" required placeholder="Email" /></div>
                  <div><label className="text-xs font-medium text-text-muted mb-1 block">{_('phoneNumber')}</label><input type="tel" value={guestPhone} onChange={(e) => setGuestPhone(e.target.value)} className="w-full px-3 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" placeholder="Phone (optional)" /></div>
                  <button type="submit" className="w-full py-3.5 bg-avocado text-white font-semibold text-sm rounded-lg hover:bg-avocado-light transition-colors">{_('submitBooking')}</button>
                  <p className="text-[10px] text-text-muted text-center">You will be redirected to our secure payment page</p>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}
