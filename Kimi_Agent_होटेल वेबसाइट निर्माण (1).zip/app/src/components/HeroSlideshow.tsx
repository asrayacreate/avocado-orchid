import { useState, useEffect, useCallback, useRef } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

interface Slide {
  src: string
  alt: string
  label: string
}

const slides: Slide[] = [
  { src: '/images/hero-exterior-night.jpg', alt: 'Resort exterior at night', label: 'Resort Exterior' },
  { src: '/images/room-suite.jpg', alt: 'Suite Room', label: 'Suite Room' },
  { src: '/images/hero-exterior-day.jpg', alt: 'Resort panoramic view', label: 'Panoramic View' },
  { src: '/images/room-super-deluxe.jpg', alt: 'Super Deluxe Room', label: 'Super Deluxe' },
  { src: '/images/restaurant-dining.jpg', alt: 'Restaurant dining', label: 'Avocado Restaurant' },
  { src: '/images/orchid-garden.jpg', alt: 'Orchid Garden', label: 'Orchid Garden' },
  { src: '/images/room-semi-suite.jpg', alt: 'Semi Suite', label: 'Semi Suite' },
  { src: '/images/hotel-lobby.jpg', alt: 'Hotel Lobby', label: 'Grand Lobby' },
  { src: '/images/room-deluxe.jpg', alt: 'Deluxe Room', label: 'Deluxe Room' },
  { src: '/images/bar-lounge.jpg', alt: 'Bar & Lounge', label: 'Bar & Lounge' },
  { src: '/images/avocado-orchard.jpg', alt: 'Avocado Orchard', label: 'Avocado Orchard' },
  { src: '/images/cafe-interior.jpg', alt: 'Crust Cafe', label: 'Crust Cafe' },
]

const HeroSlideshow = () => {
  const [current, setCurrent] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const DURATION = 5000 // 5 seconds per slide

  const goTo = useCallback((index: number) => {
    if (isTransitioning) return
    setIsTransitioning(true)
    setCurrent(index)
    setTimeout(() => setIsTransitioning(false), 1200)
  }, [isTransitioning])

  const next = useCallback(() => {
    goTo((current + 1) % slides.length)
  }, [current, goTo])

  const prev = useCallback(() => {
    goTo((current - 1 + slides.length) % slides.length)
  }, [current, goTo])

  // Auto-play
  useEffect(() => {
    timerRef.current = setInterval(next, DURATION)
    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [next])

  // Preload images
  useEffect(() => {
    slides.forEach((slide) => {
      const img = new Image()
      img.src = slide.src
    })
  }, [])

  const handleManualNav = (action: () => void) => {
    if (timerRef.current) clearInterval(timerRef.current)
    action()
    timerRef.current = setInterval(next, DURATION)
  }

  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Slides with Ken Burns effect */}
      {slides.map((slide, index) => (
        <div
          key={slide.src}
          className={`absolute inset-0 transition-opacity duration-[1200ms] ease-in-out ${
            index === current ? 'opacity-100 z-[1]' : 'opacity-0 z-0'
          }`}
        >
          <img
            src={slide.src}
            alt={slide.alt}
            className={`w-full h-full object-cover transition-transform duration-[8000ms] ease-out ${
              index === current ? 'scale-100' : 'scale-110'
            }`}
            fetchPriority={index === 0 ? 'high' : 'low'}
            loading={index === 0 ? 'eager' : 'lazy'}
          />
        </div>
      ))}

      {/* Gradient Overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-forest/40 via-forest/15 to-forest/80 z-[2]" />
      <div className="absolute inset-0 bg-gradient-to-r from-forest/30 via-transparent to-forest/30 z-[2]" />

      {/* Navigation Arrows */}
      <button
        onClick={() => handleManualNav(prev)}
        className="absolute left-4 lg:left-8 top-1/2 -translate-y-1/2 z-[4] w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 opacity-0 hover:opacity-100 group-hover:opacity-100 focus:opacity-100"
        style={{ opacity: undefined }}
        aria-label="Previous slide"
      >
        <ChevronLeft size={22} />
      </button>
      <button
        onClick={() => handleManualNav(next)}
        className="absolute right-4 lg:right-8 top-1/2 -translate-y-1/2 z-[4] w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300"
        aria-label="Next slide"
      >
        <ChevronRight size={22} />
      </button>

      {/* Slide Indicators (dots + labels) */}
      <div className="absolute bottom-[140px] left-1/2 -translate-x-1/2 z-[4] flex flex-col items-center gap-3">
        {/* Current slide label */}
        <span className="text-[11px] tracking-[0.15em] text-white/60 uppercase font-medium">
          {slides[current].label}
        </span>
        {/* Dots */}
        <div className="flex items-center gap-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => handleManualNav(() => goTo(index))}
              className={`transition-all duration-500 rounded-full ${
                index === current
                  ? 'w-8 h-2 bg-gold'
                  : 'w-2 h-2 bg-white/30 hover:bg-white/50'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 right-0 z-[4] h-[2px] bg-white/10">
        <div
          key={current}
          className="h-full bg-gold/60 origin-left"
          style={{
            animation: `progress ${DURATION}ms linear forwards`,
          }}
        />
      </div>
    </div>
  )
}

export default HeroSlideshow
