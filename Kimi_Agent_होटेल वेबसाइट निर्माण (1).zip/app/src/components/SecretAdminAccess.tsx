import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { X, Shield, Mail, Lock, KeyRound, ChevronLeft } from 'lucide-react'
import { useApp } from '@/contexts/AppContext'

export default function SecretAdminAccess() {
  const navigate = useNavigate()
  const { setAdminActive } = useApp()
  const [isOpen, setIsOpen] = useState(false)
  const [step, setStep] = useState<'email' | 'otp'>('email')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [otpDigits, setOtpDigits] = useState(['', '', '', '', '', ''])
  const [error, setError] = useState('')
  const otpRefs = useRef<(HTMLInputElement | null)[]>([])

  // Keyboard shortcut: Press "5" then Ctrl+Shift+A
  useEffect(() => {
    let pressed5 = false
    let timer: ReturnType<typeof setTimeout> | null = null

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === '5' && !e.ctrlKey && !e.shiftKey && !e.altKey && !e.metaKey) {
        pressed5 = true
        if (timer) clearTimeout(timer)
        timer = setTimeout(() => { pressed5 = false }, 3000)
        return
      }
      if (e.ctrlKey && e.shiftKey && (e.key === 'a' || e.key === 'A')) {
        if (pressed5) {
          e.preventDefault()
          pressed5 = false
          if (timer) clearTimeout(timer)
          setIsOpen(true)
          setStep('email')
          setError('')
        }
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      if (timer) clearTimeout(timer)
    }
  }, [])

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return
    const onEsc = (e: KeyboardEvent) => { if (e.key === 'Escape') handleClose() }
    window.addEventListener('keydown', onEsc)
    return () => window.removeEventListener('keydown', onEsc)
  }, [isOpen])

  const handleClose = () => {
    setIsOpen(false)
    setStep('email')
    setEmail('')
    setPassword('')
    setOtpDigits(['', '', '', '', '', ''])
    setError('')
  }

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (email === 'admin@avocadoresort.com' && password === 'admin123') {
      setStep('otp')
      // Focus first OTP input after transition
      setTimeout(() => otpRefs.current[0]?.focus(), 100)
    } else {
      setError('Invalid email or password')
    }
  }

  const handleOtpChange = (index: number, value: string) => {
    const digit = value.replace(/\D/g, '').slice(-1)
    const next = [...otpDigits]
    next[index] = digit
    setOtpDigits(next)
    setError('')
    // Auto-focus next
    if (digit && index < 5) {
      otpRefs.current[index + 1]?.focus()
    }
    // Auto-submit when all filled
    const code = next.join('')
    if (code.length === 6) {
      if (code === '123456') {
        finishLogin()
      } else {
        setError('Invalid verification code')
      }
    }
  }

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpRefs.current[index - 1]?.focus()
    }
  }

  const finishLogin = () => {
    localStorage.setItem('admin-session', 'true')
    localStorage.setItem('admin-email', email)
    setAdminActive(true)
    handleClose()
    navigate('/admin')
  }

  // Listen for custom event from footer link
  useEffect(() => {
    const handler = () => {
      setIsOpen(true)
      setStep('email')
      setError('')
    }
    window.addEventListener('open-admin-modal', handler)
    return () => window.removeEventListener('open-admin-modal', handler)
  }, [])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={handleClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-[440px] mx-4 overflow-hidden">
        {/* Header */}
        <div className="bg-forest px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center">
              <Shield size={20} className="text-gold" />
            </div>
            <div>
              <h3 className="font-display font-semibold text-white text-lg">Super Admin Access</h3>
              <p className="text-white/60 text-xs">Secure Staff Portal</p>
            </div>
          </div>
          <button onClick={handleClose} className="text-white/60 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Body */}
        <div className="p-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-2.5 text-sm text-red-600 mb-4">
              {error}
            </div>
          )}

          {step === 'email' ? (
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-medium text-text-muted mb-1.5 flex items-center gap-1.5">
                  <Mail size={13} /> Admin Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@avocadoresort.com"
                  className="w-full px-4 py-3 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none focus:ring-2 focus:ring-avocado/10"
                  required
                  autoFocus
                />
              </div>
              <div>
                <label className="text-xs font-medium text-text-muted mb-1.5 flex items-center gap-1.5">
                  <Lock size={13} /> Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full px-4 py-3 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none focus:ring-2 focus:ring-avocado/10"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3.5 bg-avocado text-white font-semibold text-sm rounded-lg hover:bg-avocado-light transition-colors flex items-center justify-center gap-2"
              >
                <KeyRound size={16} /> Continue
              </button>
              <p className="text-[11px] text-text-muted text-center">
                Demo: admin@avocadoresort.com / admin123
              </p>
            </form>
          ) : (
            <div className="space-y-4">
              <button
                onClick={() => { setStep('email'); setError('') }}
                className="flex items-center gap-1 text-xs text-avocado hover:underline mb-2"
              >
                <ChevronLeft size={14} /> Back to login
              </button>

              <div className="text-center mb-4">
                <div className="w-14 h-14 rounded-full bg-avocado/10 flex items-center justify-center mx-auto mb-3">
                  <Mail size={24} className="text-avocado" />
                </div>
                <p className="text-sm text-charcoal">Enter the 6-digit code sent to</p>
                <p className="text-sm font-semibold text-avocado-dark">{email}</p>
              </div>

              {/* OTP Grid */}
              <div className="flex justify-center gap-2 mb-4">
                {otpDigits.map((digit, i) => (
                  <input
                    key={i}
                    ref={(el) => { otpRefs.current[i] = el }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(i, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(i, e)}
                    className="w-12 h-14 text-center text-xl font-bold border-2 border-sand rounded-lg focus:border-avocado focus:outline-none focus:ring-2 focus:ring-avocado/10 transition-all"
                  />
                ))}
              </div>

              <p className="text-[11px] text-text-muted text-center">
                Demo code: 1 2 3 4 5 6
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
