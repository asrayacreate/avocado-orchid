import { useApp } from '@/contexts/AppContext'
import { Sparkles, BedDouble } from 'lucide-react'

const statusConfig: Record<string, { label: string; color: string; next: string }> = {
  clean: { label: 'Clean', color: 'bg-green-500', next: 'dirty' },
  occupied: { label: 'Occupied', color: 'bg-red-500', next: 'dirty' },
  cleaning: { label: 'Cleaning', color: 'bg-blue-500', next: 'clean' },
  dirty: { label: 'Dirty', color: 'bg-amber-500', next: 'cleaning' },
  repairing: { label: 'Repairing', color: 'bg-purple-500', next: 'cleaning' },
}

export default function AdminHousekeeping() {
  const { roomUnits, updateRoomStatus } = useApp()

  const counts = {
    clean: roomUnits.filter((r) => r.status === 'clean').length,
    occupied: roomUnits.filter((r) => r.status === 'occupied').length,
    cleaning: roomUnits.filter((r) => r.status === 'cleaning').length,
    dirty: roomUnits.filter((r) => r.status === 'dirty').length,
    repairing: roomUnits.filter((r) => r.status === 'repairing').length,
  }

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Housekeeping</h1>
      <p className="text-text-muted mb-6">Click status buttons to cycle room states</p>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-8">
        {Object.entries(counts).map(([status, count]) => (
          <div key={status} className="bg-white rounded-xl p-4 shadow-sm border border-sand/30 text-center">
            <div className={`w-3 h-3 rounded-full ${statusConfig[status]?.color || 'bg-gray-400'} mx-auto mb-2`} />
            <p className="text-2xl font-display font-bold text-avocado-dark">{count}</p>
            <p className="text-xs text-text-muted capitalize">{status}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {roomUnits.map((r) => {
          const cfg = statusConfig[r.status]
          return (
            <div key={r.id} className="bg-white rounded-xl p-5 shadow-sm border border-sand/30 hover:shadow-md transition-all">
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center"><BedDouble size={20} className="text-avocado" /></div>
                <span className={`text-[11px] px-2.5 py-1 rounded-full font-medium text-white ${cfg.color}`}>{cfg.label}</span>
              </div>
              <h3 className="font-semibold text-avocado-dark">{r.name}</h3>
              <p className="text-sm text-text-muted">{r.number} &middot; Floor {r.floor}</p>
              <p className="text-sm text-gold font-medium mb-3">NPR {r.price.toLocaleString()}/night</p>
              <button onClick={() => updateRoomStatus(r.id, cfg.next as any)}
                className="w-full py-2 bg-cream text-charcoal text-xs font-medium rounded-lg hover:bg-sand transition-colors border border-sand/50">
                Mark {cfg.next.charAt(0).toUpperCase() + cfg.next.slice(1)}
              </button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
