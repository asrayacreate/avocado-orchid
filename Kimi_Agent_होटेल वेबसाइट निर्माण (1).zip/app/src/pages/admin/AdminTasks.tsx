import { useState } from 'react'
import { useApp } from '@/contexts/AppContext'
import { ClipboardList, Plus, X } from 'lucide-react'

const priorityColors: Record<string, string> = { high: 'bg-red-100 text-red-700', medium: 'bg-amber-100 text-amber-700', low: 'bg-green-100 text-green-700' }
const statusColors: Record<string, string> = { pending: 'bg-gray-100 text-gray-600', 'in-progress': 'bg-blue-100 text-blue-700', completed: 'bg-green-100 text-green-700' }

export default function AdminTasks() {
  const { tasks, addTask, updateTaskStatus, setTasks } = useApp()
  const [filter, setFilter] = useState('all')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ title: '', type: 'cleaning' as const, priority: 'medium' as const, roomNumber: '', assignedTo: '', dueDate: '' })

  const filtered = filter === 'all' ? tasks : tasks.filter((t) => t.status === filter)

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    addTask({ ...form, status: 'pending' })
    setForm({ title: '', type: 'cleaning', priority: 'medium', roomNumber: '', assignedTo: '', dueDate: '' })
    setShowForm(false)
  }

  const cycleStatus = (id: number, current: string) => {
    const next = current === 'pending' ? 'in-progress' : current === 'in-progress' ? 'completed' : 'pending'
    updateTaskStatus(id, next as any)
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="font-display font-semibold text-3xl text-avocado-dark">Task Manager</h1><p className="text-text-muted mt-1">{tasks.filter((t) => t.status !== 'completed').length} active tasks</p></div>
        <button onClick={() => setShowForm(true)} className="flex items-center gap-2 px-4 py-2.5 bg-avocado text-white text-sm font-medium rounded-lg hover:bg-avocado-light"><Plus size={16} /> New Task</button>
      </div>

      {showForm && (
        <form onSubmit={handleAdd} className="bg-white rounded-xl p-6 shadow-sm border border-sand/30 mb-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <input required placeholder="Task title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as any })} className="px-4 py-2.5 border border-sand rounded-lg text-sm bg-white focus:border-avocado focus:outline-none">
            <option value="cleaning">Cleaning</option><option value="maintenance">Maintenance</option><option value="inspection">Inspection</option>
          </select>
          <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as any })} className="px-4 py-2.5 border border-sand rounded-lg text-sm bg-white focus:border-avocado focus:outline-none">
            <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
          </select>
          <input placeholder="Room number (optional)" value={form.roomNumber} onChange={(e) => setForm({ ...form, roomNumber: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <input placeholder="Assigned to" value={form.assignedTo} onChange={(e) => setForm({ ...form, assignedTo: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <div className="flex gap-2 sm:col-span-3">
            <button type="submit" className="px-6 py-2.5 bg-avocado text-white text-sm rounded-lg hover:bg-avocado-light">Add Task</button>
            <button type="button" onClick={() => setShowForm(false)} className="px-6 py-2.5 text-text-muted text-sm hover:text-charcoal"><X size={16} /></button>
          </div>
        </form>
      )}

      <div className="flex gap-2 mb-6">
        {['all', 'pending', 'in-progress', 'completed'].map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === f ? 'bg-avocado text-white' : 'bg-white text-charcoal hover:bg-avocado/10 border border-sand/30'}`}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden divide-y divide-sand/30">
        {filtered.map((t) => (
          <div key={t.id} className="p-5 hover:bg-cream/30 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center shrink-0"><ClipboardList size={18} className="text-avocado" /></div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <p className="font-medium text-avocado-dark">{t.title}</p>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${priorityColors[t.priority]}`}>{t.priority}</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-text-muted">
                <span className="capitalize">{t.type}</span>
                {t.roomNumber && <span>Room {t.roomNumber}</span>}
                <span>Assigned: {t.assignedTo}</span>
                <span>Due: {new Date(t.dueDate).toLocaleDateString()}</span>
              </div>
            </div>
            <button onClick={() => cycleStatus(t.id, t.status)} className={`text-[11px] px-3 py-1.5 rounded-full font-medium transition-all ${statusColors[t.status]}`}>{t.status}</button>
          </div>
        ))}
      </div>
    </div>
  )
}
