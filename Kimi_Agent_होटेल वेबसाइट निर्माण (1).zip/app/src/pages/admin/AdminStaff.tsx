import { useState } from 'react'
import { useApp } from '@/contexts/AppContext'
import { Users, Search, Plus, X } from 'lucide-react'

const statusColors: Record<string, string> = {
  active: 'bg-green-100 text-green-700',
  'on-leave': 'bg-amber-100 text-amber-700',
  inactive: 'bg-red-100 text-red-700',
}

export default function AdminStaff() {
  const { staff, addStaff, setStaff } = useApp()
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name: '', role: '', department: 'Front Desk', phone: '', status: 'active' as const, joined: '' })

  const filtered = staff.filter((s) => !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.department.toLowerCase().includes(search.toLowerCase()))

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    addStaff({ ...form, joined: form.joined || new Date().toISOString().split('T')[0] })
    setForm({ name: '', role: '', department: 'Front Desk', phone: '', status: 'active', joined: '' })
    setShowForm(false)
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="font-display font-semibold text-3xl text-avocado-dark">Staff Management</h1><p className="text-text-muted mt-1">{staff.length} team members</p></div>
        <button onClick={() => setShowForm(true)} className="flex items-center gap-2 px-4 py-2.5 bg-avocado text-white text-sm font-medium rounded-lg hover:bg-avocado-light"><Plus size={16} /> Add Staff</button>
      </div>

      {showForm && (
        <form onSubmit={handleAdd} className="bg-white rounded-xl p-6 shadow-sm border border-sand/30 mb-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <input required placeholder="Full Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <input required placeholder="Role (e.g. Receptionist)" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <select value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none bg-white">
            {['Front Desk', 'Kitchen', 'Housekeeping', 'Security', 'Restaurant'].map((d) => <option key={d}>{d}</option>)}
          </select>
          <input placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <div className="flex gap-2 sm:col-span-2">
            <button type="submit" className="px-6 py-2.5 bg-avocado text-white text-sm rounded-lg hover:bg-avocado-light">Add Member</button>
            <button type="button" onClick={() => setShowForm(false)} className="px-6 py-2.5 text-text-muted text-sm hover:text-charcoal"><X size={16} /></button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-4 mb-6">
        <div className="relative max-w-sm">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
          <input type="text" placeholder="Search staff..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-sand/50 bg-cream/50">
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Staff</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Department</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Phone</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Status</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Joined</th>
          </tr></thead>
          <tbody className="divide-y divide-sand/30">
            {filtered.map((s) => (
              <tr key={s.id} className="hover:bg-cream/30">
                <td className="px-6 py-4"><div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-avocado/10 flex items-center justify-center"><Users size={14} className="text-avocado" /></div>
                  <div><p className="font-medium text-avocado-dark">{s.name}</p><p className="text-xs text-text-muted">{s.role}</p></div>
                </div></td>
                <td className="px-6 py-4 text-text-muted">{s.department}</td>
                <td className="px-6 py-4 text-text-muted">{s.phone}</td>
                <td className="px-6 py-4"><span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${statusColors[s.status]}`}>{s.status}</span></td>
                <td className="px-6 py-4 text-text-muted">{new Date(s.joined).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
