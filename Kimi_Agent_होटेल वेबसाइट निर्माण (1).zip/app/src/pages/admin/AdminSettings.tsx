import { useState } from 'react'
import { Settings, Save, Facebook, Instagram, Globe, Phone, Mail, MapPin } from 'lucide-react'

const initialSettings = {
  hotelName: 'Avocado & Orchid Resort',
  phone: '+977 980 1804340',
  email: 'info@avocadoresort.com',
  address: 'Chaukitol 2, Tribhuvan Rajpath, Hetauda 44107, Nepal',
  facebook: 'https://facebook.com/avocadoresort',
  instagram: 'https://instagram.com/avocadoresort',
  checkIn: '12:00 PM',
  checkOut: '11:00 AM',
  currency: 'NPR',
  vatRate: '13',
}

export default function AdminSettings() {
  const [s, setS] = useState(initialSettings)
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Global Settings</h1>
      <p className="text-text-muted mb-6">Master configuration for the hotel</p>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-6 max-w-2xl">
        <div className="space-y-5">
          <div>
            <label className="text-xs font-medium text-text-muted mb-1.5 flex items-center gap-1.5"><Globe size={12} /> Hotel Name</label>
            <input value={s.hotelName} onChange={(e) => setS({ ...s, hotelName: e.target.value })} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-text-muted mb-1.5 flex items-center gap-1.5"><Phone size={12} /> Phone</label>
              <input value={s.phone} onChange={(e) => setS({ ...s, phone: e.target.value })} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
            </div>
            <div>
              <label className="text-xs font-medium text-text-muted mb-1.5 flex items-center gap-1.5"><Mail size={12} /> Email</label>
              <input value={s.email} onChange={(e) => setS({ ...s, email: e.target.value })} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-text-muted mb-1.5 flex items-center gap-1.5"><MapPin size={12} /> Address</label>
            <textarea value={s.address} onChange={(e) => setS({ ...s, address: e.target.value })} rows={2} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none resize-none" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-text-muted mb-1.5 flex items-center gap-1.5"><Facebook size={12} /> Facebook URL</label>
              <input value={s.facebook} onChange={(e) => setS({ ...s, facebook: e.target.value })} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
            </div>
            <div>
              <label className="text-xs font-medium text-text-muted mb-1.5 flex items-center gap-1.5"><Instagram size={12} /> Instagram URL</label>
              <input value={s.instagram} onChange={(e) => setS({ ...s, instagram: e.target.value })} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-medium text-text-muted mb-1.5 block">Check-in Time</label>
              <input value={s.checkIn} onChange={(e) => setS({ ...s, checkIn: e.target.value })} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
            </div>
            <div>
              <label className="text-xs font-medium text-text-muted mb-1.5 block">Check-out Time</label>
              <input value={s.checkOut} onChange={(e) => setS({ ...s, checkOut: e.target.value })} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
            </div>
            <div>
              <label className="text-xs font-medium text-text-muted mb-1.5 block">VAT Rate (%)</label>
              <input value={s.vatRate} onChange={(e) => setS({ ...s, vatRate: e.target.value })} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
            </div>
          </div>

          <div className="pt-4 border-t border-sand/50 flex items-center gap-3">
            <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2.5 bg-avocado text-white font-medium text-sm rounded-lg hover:bg-avocado-light"><Save size={16} /> Save Settings</button>
            {saved && <span className="text-sm text-green-600">Settings saved!</span>}
          </div>
        </div>
      </div>
    </div>
  )
}
