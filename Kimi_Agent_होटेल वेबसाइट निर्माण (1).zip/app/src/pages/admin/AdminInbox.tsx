import { useState } from 'react'
import { Send, User } from 'lucide-react'

const mockChats = [
  { id: 1, guestName: 'Pablo Morales', room: '205', messages: [{ from: 'guest', text: 'Can we get extra towels?', time: '10:30 AM' }, { from: 'admin', text: 'Sure, sending housekeeping right away!', time: '10:32 AM' }] },
  { id: 2, guestName: 'John Smith', room: '102', messages: [{ from: 'guest', text: 'Restaurant timing?', time: '09:15 AM' }] },
  { id: 3, guestName: 'Ram Sharma', room: '301', messages: [{ from: 'guest', text: 'Checkout time please', time: '08:45 AM' }, { from: 'admin', text: 'Checkout is at 11:00 AM. Late checkout available on request.', time: '08:50 AM' }] },
]

export default function AdminInbox() {
  const [activeChat, setActiveChat] = useState(mockChats[0])
  const [reply, setReply] = useState('')
  const [chats, setChats] = useState(mockChats)

  const sendReply = () => {
    if (!reply.trim()) return
    setChats((prev) => prev.map((c) => c.id === activeChat.id ? { ...c, messages: [...c.messages, { from: 'admin', text: reply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }] } : c))
    setActiveChat((prev) => ({ ...prev, messages: [...prev.messages, { from: 'admin', text: reply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }] }))
    setReply('')
  }

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-6">Unified Inbox</h1>
      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden flex h-[600px]">
        <div className="w-72 border-r border-sand/50 overflow-y-auto bg-cream/30">
          <div className="p-4 border-b border-sand/50">
            <input type="text" placeholder="Search conversations..." className="w-full px-3 py-2 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          </div>
          {chats.map((chat) => (
            <button key={chat.id} onClick={() => setActiveChat(chat)} className={`w-full text-left p-4 border-b border-sand/30 hover:bg-cream/50 transition-colors ${activeChat.id === chat.id ? 'bg-white border-l-4 border-l-avocado' : ''}`}>
              <div className="flex items-center justify-between"><p className="font-medium text-sm text-avocado-dark">{chat.guestName}</p><span className="text-[10px] text-text-muted">Room {chat.room}</span></div>
              <p className="text-xs text-text-muted truncate">{chat.messages[chat.messages.length - 1].text}</p>
            </button>
          ))}
        </div>
        <div className="flex-1 flex flex-col">
          <div className="p-4 border-b border-sand/50 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-avocado/10 flex items-center justify-center"><User size={16} className="text-avocado" /></div>
            <div><p className="font-medium text-avocado-dark">{activeChat.guestName}</p><p className="text-xs text-text-muted">Room {activeChat.room}</p></div>
          </div>
          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            {activeChat.messages.map((m, i) => (
              <div key={i} className={`flex ${m.from === 'admin' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[70%] rounded-xl px-4 py-2.5 ${m.from === 'admin' ? 'bg-avocado text-white rounded-br-sm' : 'bg-cream text-charcoal rounded-bl-sm'}`}>
                  <p className="text-sm">{m.text}</p>
                  <p className={`text-[10px] mt-1 ${m.from === 'admin' ? 'text-white/60' : 'text-text-muted'}`}>{m.time}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="p-4 border-t border-sand/50 flex gap-2">
            <input type="text" placeholder="Type a message..." value={reply} onChange={(e) => setReply(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && sendReply()}
              className="flex-1 px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
            <button onClick={sendReply} className="px-4 py-2.5 bg-avocado text-white rounded-lg hover:bg-avocado-light transition-colors"><Send size={16} /></button>
          </div>
        </div>
      </div>
    </div>
  )
}
