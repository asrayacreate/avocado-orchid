import { useState } from 'react'
import { useApp } from '@/contexts/AppContext'
import { BedDouble, Search, Trash2, ChevronDown } from 'lucide-react'

const statusColors: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-700',
  confirmed: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
  completed: 'bg-blue-100 text-blue-700',
}

export default function AdminBookings() {
  const { bookings, setBookings } = useApp()
  const [statusFilter, setStatusFilter] = useState('all')
  const [search, setSearch] = useState('')

  const filtered = bookings
    .filter((b) => statusFilter === 'all' || b.status === statusFilter)
    .filter((b) => !search || b.guestName.toLowerCase().includes(search.toLowerCase()) || b.guestEmail.toLowerCase().includes(search.toLowerCase()))

  const deleteBooking = (id: number) => {
    if (confirm('Delete this booking?')) setBookings((prev) => prev.filter((b) => b.id !== id))
  }

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Bookings</h1>
      <p className="text-text-muted mb-6">Manage all guest reservations</p>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-4 mb-6 flex flex-wrap gap-4 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
          <input type="text" placeholder="Search by guest name or email..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
        </div>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none bg-white">
          <option value="all">All Status</option>
          <option value="pending">Pending</option>
          <option value="confirmed">Confirmed</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-sand/50 bg-cream/50">
              <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Guest</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Room</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Dates</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Amount</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Payment</th>
              <th className="px-6 py-3"></th>
            </tr></thead>
            <tbody className="divide-y divide-sand/30">
              {filtered.map((b) => (
                <tr key={b.id} className="hover:bg-cream/30">
                  <td className="px-6 py-4"><div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-avocado/10 flex items-center justify-center"><BedDouble size={14} className="text-avocado" /></div>
                    <div><p className="font-medium text-avocado-dark">{b.guestName}</p><p className="text-xs text-text-muted">{b.guestEmail}</p></div>
                  </div></td>
                  <td className="px-6 py-4 text-text-muted">{b.roomName}</td>
                  <td className="px-6 py-4"><p className="text-charcoal">{new Date(b.checkIn).toLocaleDateString()}</p><p className="text-xs text-text-muted">to {new Date(b.checkOut).toLocaleDateString()}</p></td>
                  <td className="px-6 py-4 font-semibold text-avocado-dark">NPR {b.totalAmount.toLocaleString()}</td>
                  <td className="px-6 py-4"><span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${statusColors[b.status]}`}>{b.status}</span></td>
                  <td className="px-6 py-4"><span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${b.paymentStatus === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>{b.paymentStatus}</span></td>
                  <td className="px-6 py-4"><button onClick={() => deleteBooking(b.id)} className="text-red-400 hover:text-red-600"><Trash2 size={16} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
