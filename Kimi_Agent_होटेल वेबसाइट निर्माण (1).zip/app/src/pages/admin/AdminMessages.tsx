import { useState } from 'react'
import { useApp } from '@/contexts/AppContext'
import { Mail, Search, AlertCircle, CheckCircle2, Trash2 } from 'lucide-react'

export default function AdminMessages() {
  const { messages, markMessageRead, setMessages } = useApp()
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<'all' | 'unread' | 'read'>('all')

  const filtered = messages
    .filter((m) => filter === 'all' || m.isRead === filter)
    .filter((m) => !search || m.name.toLowerCase().includes(search.toLowerCase()) || m.message.toLowerCase().includes(search.toLowerCase()))

  const unreadCount = messages.filter((m) => m.isRead === 'unread').length

  const deleteMessage = (id: number) => {
    if (confirm('Delete this message?')) setMessages((prev) => prev.filter((m) => m.id !== id))
  }

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Messages</h1>
      <p className="text-text-muted mb-6">{unreadCount} unread out of {messages.length} total</p>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-4 mb-6 flex flex-wrap gap-4 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
          <input type="text" placeholder="Search messages..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
        </div>
        <div className="flex gap-2">
          {(['all', 'unread', 'read'] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === f ? 'bg-avocado text-white' : 'bg-cream text-charcoal hover:bg-avocado/10'}`}>
              {f.charAt(0).toUpperCase() + f.slice(1)} {f === 'unread' && unreadCount > 0 && <span className="ml-1 bg-red-500 text-white text-[10px] px-1.5 rounded-full">{unreadCount}</span>}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden divide-y divide-sand/30">
        {filtered.map((m) => (
          <div key={m.id} className={`p-6 hover:bg-cream/30 transition-colors ${m.isRead === 'unread' ? 'bg-amber-50/30' : ''}`} onClick={() => markMessageRead(m.id)}>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center shrink-0"><Mail size={18} className="text-avocado" /></div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  {m.isRead === 'unread' ? <AlertCircle size={14} className="text-amber-500" /> : <CheckCircle2 size={14} className="text-green-500" />}
                  <p className="font-semibold text-avocado-dark">{m.name}</p>
                  <span className="text-xs text-text-muted ml-auto">{new Date(m.createdAt).toLocaleDateString()}</span>
                </div>
                <p className="text-xs text-text-muted mb-1">{m.email} {m.phone && `| ${m.phone}`}</p>
                <p className="text-sm text-charcoal leading-relaxed">{m.message}</p>
              </div>
              <button onClick={(e) => { e.stopPropagation(); deleteMessage(m.id) }} className="text-red-400 hover:text-red-600 shrink-0"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
