import { useState } from 'react'
import { Image, Save, Eye } from 'lucide-react'

const initialBanners = [
  { id: 1, title: 'Summer Special 2026', subtitle: 'Get 20% off on all Suite bookings this summer!', active: true, position: 'hero' },
  { id: 2, title: 'Orchid Festival Package', subtitle: 'Includes guided garden tour + complimentary breakfast', active: false, position: 'hero' },
  { id: 3, title: 'Weekend Family Deal', subtitle: 'Kids stay free + free airport pickup', active: true, position: 'rooms' },
]

export default function AdminBanners() {
  const [banners, setBanners] = useState(initialBanners)
  const [preview, setPreview] = useState<string | null>(null)

  const toggleActive = (id: number) => {
    setBanners((prev) => prev.map((b) => b.id === id ? { ...b, active: !b.active } : b))
  }

  const updateBanner = (id: number, field: string, value: string) => {
    setBanners((prev) => prev.map((b) => b.id === id ? { ...b, [field]: value } : b))
  }

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Banner & Offer Settings</h1>
      <p className="text-text-muted mb-6">Manage promotional banners and special offers</p>

      <div className="space-y-4">
        {banners.map((b) => (
          <div key={b.id} className={`bg-white rounded-xl p-6 shadow-sm border transition-all ${b.active ? 'border-avocado/30' : 'border-sand/30'}`}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center"><Image size={18} className="text-avocado" /></div>
                <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${b.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>{b.active ? 'Active' : 'Inactive'}</span>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setPreview(preview === String(b.id) ? null : String(b.id))} className="px-3 py-1.5 text-xs bg-cream rounded-lg hover:bg-sand flex items-center gap-1"><Eye size={12} /> Preview</button>
                <button onClick={() => toggleActive(b.id)} className={`w-12 h-7 rounded-full transition-colors relative ${b.active ? 'bg-avocado' : 'bg-sand'}`}><div className={`w-5 h-5 rounded-full bg-white shadow absolute top-1 transition-all ${b.active ? 'left-6' : 'left-1'}`} /></button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-text-muted mb-1 block">Banner Title</label>
                <input value={b.title} onChange={(e) => updateBanner(b.id, 'title', e.target.value)} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
              </div>
              <div>
                <label className="text-xs font-medium text-text-muted mb-1 block">Subtitle</label>
                <input value={b.subtitle} onChange={(e) => updateBanner(b.id, 'subtitle', e.target.value)} className="w-full px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
              </div>
            </div>

            {preview === String(b.id) && (
              <div className="mt-4 p-6 bg-forest rounded-xl text-center">
                <p className="text-gold text-xs tracking-wider uppercase mb-2">Special Offer</p>
                <h3 className="font-display font-bold text-2xl text-white mb-2">{b.title}</h3>
                <p className="text-white/70 text-sm">{b.subtitle}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-6 flex justify-end">
        <button onClick={() => alert('Banners saved!')} className="flex items-center gap-2 px-6 py-3 bg-avocado text-white font-semibold text-sm rounded-lg hover:bg-avocado-light"><Save size={16} /> Save Changes</button>
      </div>
    </div>
  )
}
