import { Crown, Star, Gift } from 'lucide-react'

const tiers = [
  { name: 'Bronze', minSpent: 0, color: 'bg-amber-800' },
  { name: 'Silver', minSpent: 50000, color: 'bg-gray-400' },
  { name: 'Gold', minSpent: 150000, color: 'bg-gold' },
  { name: 'Platinum', minSpent: 300000, color: 'bg-purple-600' },
]

const guests = [
  { id: 1, name: 'Pablo Morales', visits: 4, totalSpent: 85000, tier: 'Silver', points: 3400 },
  { id: 2, name: 'John Smith', visits: 2, totalSpent: 18000, tier: 'Bronze', points: 720 },
  { id: 3, name: 'Ram Sharma', visits: 6, totalSpent: 125000, tier: 'Gold', points: 5000 },
]

export default function AdminLoyalty() {
  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Loyalty & Referrals</h1>
      <p className="text-text-muted mb-6">Guest tier management and points program</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {tiers.map((t) => (
          <div key={t.name} className="bg-white rounded-xl p-5 shadow-sm border border-sand/30 text-center">
            <div className={`w-12 h-12 rounded-full ${t.color} flex items-center justify-center mx-auto mb-3`}><Crown size={20} className="text-white" /></div>
            <p className="font-semibold text-avocado-dark">{t.name}</p>
            <p className="text-xs text-text-muted">NPR {t.minSpent.toLocaleString()}+</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-sand/50 bg-cream/50">
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Guest</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Visits</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Total Spent</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Tier</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-text-muted uppercase">Points</th>
          </tr></thead>
          <tbody className="divide-y divide-sand/30">
            {guests.map((g) => (
              <tr key={g.id} className="hover:bg-cream/30">
                <td className="px-6 py-4 font-medium text-avocado-dark">{g.name}</td>
                <td className="px-6 py-4 text-text-muted">{g.visits}</td>
                <td className="px-6 py-4 text-avocado-dark">NPR {g.totalSpent.toLocaleString()}</td>
                <td className="px-6 py-4"><span className="text-[11px] px-2 py-0.5 rounded-full font-medium bg-gold/20 text-amber-700">{g.tier}</span></td>
                <td className="px-6 py-4 font-semibold text-gold">{g.points.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
