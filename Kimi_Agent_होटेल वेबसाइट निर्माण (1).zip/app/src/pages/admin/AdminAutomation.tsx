import { useApp } from '@/contexts/AppContext'
import { Bot, Power } from 'lucide-react'

export default function AdminAutomation() {
  const { automations, toggleAutomation } = useApp()

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Automation</h1>
      <p className="text-text-muted mb-6">Manage automatic messages and workflows</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {automations.map((a) => (
          <div key={a.id} className="bg-white rounded-xl p-6 shadow-sm border border-sand/30 hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center"><Bot size={18} className="text-avocado" /></div>
                <div><h3 className="font-semibold text-avocado-dark">{a.name}</h3><p className="text-xs text-text-muted">{a.trigger}</p></div>
              </div>
              <button onClick={() => toggleAutomation(a.id)}
                className={`w-12 h-7 rounded-full transition-colors relative ${a.status === 'active' ? 'bg-avocado' : 'bg-sand'}`}>
                <div className={`w-5 h-5 rounded-full bg-white shadow absolute top-1 transition-all ${a.status === 'active' ? 'left-6' : 'left-1'}`} />
              </button>
            </div>
            <p className="text-sm text-text-muted mb-3">{a.desc}</p>
            <span className={`text-[11px] px-2.5 py-1 rounded-full font-medium ${a.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>{a.status}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
