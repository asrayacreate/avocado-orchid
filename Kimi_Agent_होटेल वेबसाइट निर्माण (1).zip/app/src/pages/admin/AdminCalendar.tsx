import { useState } from 'react'
import { useApp } from '@/contexts/AppContext'
import { CalendarDays, ChevronLeft, ChevronRight, BedDouble } from 'lucide-react'

export default function AdminCalendar() {
  const { bookings } = useApp()
  const [currentDate, setCurrentDate] = useState(new Date(2025, 5, 1))

  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate()
  const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay()

  const getBookingsForDay = (day: number) => {
    const dateStr = `2025-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
    return bookings.filter((b) => b.checkIn <= dateStr && b.checkOut >= dateStr)
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-semibold text-3xl text-avocado-dark">Multi-Calendar</h1>
          <p className="text-text-muted mt-1">Room availability overview</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1))} className="p-2 rounded-lg bg-white border border-sand/50 hover:shadow-sm"><ChevronLeft size={18} /></button>
          <span className="font-display font-semibold text-lg">{monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}</span>
          <button onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1))} className="p-2 rounded-lg bg-white border border-sand/50 hover:shadow-sm"><ChevronRight size={18} /></button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-6">
        <div className="grid grid-cols-7 gap-1 mb-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
            <div key={d} className="text-center text-xs font-semibold text-text-muted uppercase py-2">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: firstDay }, (_, i) => <div key={`e${i}`} className="aspect-square" />)}
          {Array.from({ length: daysInMonth }, (_, i) => {
            const day = i + 1
            const dayBookings = getBookingsForDay(day)
            return (
              <div key={day} className="aspect-square border border-sand/30 rounded-lg p-1.5 hover:bg-cream/50 transition-colors relative min-h-[80px]">
                <span className="text-sm font-medium text-avocado-dark">{day}</span>
                {dayBookings.length > 0 && (
                  <div className="mt-1 space-y-0.5">
                    {dayBookings.slice(0, 2).map((b) => (
                      <div key={b.id} className="flex items-center gap-0.5 bg-avocado/10 rounded px-1 py-0.5">
                        <BedDouble size={8} className="text-avocado shrink-0" />
                        <span className="text-[8px] text-avocado-dark truncate">{b.guestName.split(' ')[0]}</span>
                      </div>
                    ))}
                    {dayBookings.length > 2 && <span className="text-[8px] text-text-muted">+{dayBookings.length - 2} more</span>}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
