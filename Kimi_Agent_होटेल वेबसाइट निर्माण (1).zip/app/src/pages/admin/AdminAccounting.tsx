import { useState } from 'react'
import { useApp } from '@/contexts/AppContext'
import { TrendingUp, TrendingDown, Wallet, Plus, X } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const chartData = [
  { month: 'Jan', revenue: 58000, expenses: 35000 },
  { month: 'Feb', revenue: 72000, expenses: 38000 },
  { month: 'Mar', revenue: 85000, expenses: 42000 },
  { month: 'Apr', revenue: 98000, expenses: 45000 },
  { month: 'May', revenue: 115000, expenses: 48000 },
  { month: 'Jun', revenue: 92000, expenses: 44000 },
]

export default function AdminAccounting() {
  const { bookings, expenses, addExpense, setExpenses } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ title: '', category: 'Utilities', amount: '', paidTo: '', date: '' })

  const totalRevenue = bookings.reduce((a, b) => a + (b.paymentStatus === 'Paid' ? b.totalAmount : 0), 0)
  const totalExpenses = expenses.reduce((a, e) => a + e.amount, 0)
  const vatAmount = totalRevenue * 0.13

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    addExpense({ title: form.title, category: form.category, amount: Number(form.amount) || 0, paidTo: form.paidTo, date: form.date || new Date().toISOString().split('T')[0] })
    setForm({ title: '', category: 'Utilities', amount: '', paidTo: '', date: '' })
    setShowForm(false)
  }

  const deleteExpense = (id: number) => { if (confirm('Delete?')) setExpenses((prev) => prev.filter((e) => e.id !== id)) }

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Accounting & Expenses</h1>
      <p className="text-text-muted mb-6">Financial overview with 13% VAT calculation</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30">
          <div className="flex items-start justify-between"><div><p className="text-sm text-text-muted">Total Revenue</p><p className="text-2xl font-display font-bold text-green-600">NPR {totalRevenue.toLocaleString()}</p></div><div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center"><TrendingUp size={18} className="text-green-600" /></div></div>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30">
          <div className="flex items-start justify-between"><div><p className="text-sm text-text-muted">Total Expenses</p><p className="text-2xl font-display font-bold text-red-600">NPR {totalExpenses.toLocaleString()}</p></div><div className="w-10 h-10 rounded-lg bg-red-50 flex items-center justify-center"><TrendingDown size={18} className="text-red-600" /></div></div>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30">
          <div className="flex items-start justify-between"><div><p className="text-sm text-text-muted">Net Profit</p><p className="text-2xl font-display font-bold text-avocado-dark">NPR {(totalRevenue - totalExpenses).toLocaleString()}</p></div><div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center"><Wallet size={18} className="text-blue-600" /></div></div>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30">
          <div className="flex items-start justify-between"><div><p className="text-sm text-text-muted">13% VAT</p><p className="text-2xl font-display font-bold text-amber-600">NPR {Math.round(vatAmount).toLocaleString()}</p></div><div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center"><span className="text-amber-600 text-xs font-bold">VAT</span></div></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-sand/30 p-6">
          <h3 className="font-semibold text-lg text-avocado-dark mb-4">Revenue vs Expenses</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}><CartesianGrid strokeDasharray="3 3" stroke="#f0ece4" /><XAxis dataKey="month" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 12 }} /><Tooltip formatter={(v: number) => `NPR ${v.toLocaleString()}`} /><Bar dataKey="revenue" fill="#2d5a2d" radius={[4, 4, 0, 0]} /><Bar dataKey="expenses" fill="#d4c9b8" radius={[4, 4, 0, 0]} /></BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-6">
          <h3 className="font-semibold text-lg text-avocado-dark mb-4">VAT Report (13%)</h3>
          <div className="space-y-3">
            <div className="flex justify-between text-sm"><span className="text-text-muted">Gross Revenue</span><span className="font-medium">NPR {totalRevenue.toLocaleString()}</span></div>
            <div className="flex justify-between text-sm"><span className="text-text-muted">VAT (13%)</span><span className="font-medium text-amber-600">NPR {Math.round(vatAmount).toLocaleString()}</span></div>
            <div className="border-t border-sand pt-2 flex justify-between font-semibold"><span>Net After VAT</span><span>NPR {(totalRevenue - vatAmount).toLocaleString()}</span></div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-lg text-avocado-dark">Expense Log</h3>
        <button onClick={() => setShowForm(true)} className="flex items-center gap-2 px-4 py-2 bg-avocado text-white text-sm rounded-lg hover:bg-avocado-light"><Plus size={16} /> Add Expense</button>
      </div>

      {showForm && (
        <form onSubmit={handleAdd} className="bg-white rounded-xl p-5 shadow-sm border border-sand/30 mb-4 grid grid-cols-1 sm:grid-cols-5 gap-3">
          <input required placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="px-3 py-2 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="px-3 py-2 border border-sand rounded-lg text-sm bg-white focus:border-avocado focus:outline-none">
            {['Food & Beverage', 'Staff Salary', 'Utilities', 'Maintenance', 'Other'].map((c) => <option key={c}>{c}</option>)}
          </select>
          <input required type="number" placeholder="Amount" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} className="px-3 py-2 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <input placeholder="Paid to" value={form.paidTo} onChange={(e) => setForm({ ...form, paidTo: e.target.value })} className="px-3 py-2 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <div className="flex gap-2">
            <button type="submit" className="px-4 py-2 bg-avocado text-white text-sm rounded-lg hover:bg-avocado-light">Add</button>
            <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 text-text-muted"><X size={16} /></button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-sand/50 bg-cream/50">
            <th className="px-4 py-3 text-left text-xs font-semibold text-text-muted uppercase">Title</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-text-muted uppercase">Category</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-text-muted uppercase">Amount</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-text-muted uppercase">Paid To</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-text-muted uppercase">Date</th>
          </tr></thead>
          <tbody className="divide-y divide-sand/30">
            {expenses.map((e) => (
              <tr key={e.id} className="hover:bg-cream/30 cursor-pointer" onClick={() => deleteExpense(e.id)}>
                <td className="px-4 py-3 font-medium text-avocado-dark">{e.title}</td>
                <td className="px-4 py-3 text-text-muted">{e.category}</td>
                <td className="px-4 py-3 text-red-600 font-medium">NPR {e.amount.toLocaleString()}</td>
                <td className="px-4 py-3 text-text-muted">{e.paidTo}</td>
                <td className="px-4 py-3 text-text-muted">{new Date(e.date).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
