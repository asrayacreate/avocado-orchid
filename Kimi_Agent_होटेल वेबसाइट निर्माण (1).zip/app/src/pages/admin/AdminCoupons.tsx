import { useState } from 'react'
import { useApp } from '@/contexts/AppContext'
import { Tag, Plus, Copy, Check, X } from 'lucide-react'

export default function AdminCoupons() {
  const { coupons, addCoupon, setCoupons } = useApp()
  const [copied, setCopied] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ code: '', discount: '', type: 'percentage' as const, maxUses: '100', expires: '' })

  const copyCode = (code: string) => {
    navigator.clipboard?.writeText(code)
    setCopied(code)
    setTimeout(() => setCopied(''), 2000)
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    addCoupon({ code: form.code.toUpperCase(), discount: Number(form.discount) || 0, type: form.type, maxUses: Number(form.maxUses) || 100, used: 0, expires: form.expires || '2025-12-31', status: 'active' })
    setForm({ code: '', discount: '', type: 'percentage', maxUses: '100', expires: '' })
    setShowForm(false)
  }

  const deleteCoupon = (id: number) => { if (confirm('Delete?')) setCoupons((prev) => prev.filter((c) => c.id !== id)) }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="font-display font-semibold text-3xl text-avocado-dark">Coupons & Promos</h1><p className="text-text-muted mt-1">Manage discount codes</p></div>
        <button onClick={() => setShowForm(true)} className="flex items-center gap-2 px-4 py-2.5 bg-avocado text-white text-sm font-medium rounded-lg hover:bg-avocado-light"><Plus size={16} /> Create</button>
      </div>

      {showForm && (
        <form onSubmit={handleAdd} className="bg-white rounded-xl p-5 shadow-sm border border-sand/30 mb-6 grid grid-cols-1 sm:grid-cols-5 gap-3">
          <input required placeholder="CODE2026" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} className="px-3 py-2 border border-sand rounded-lg text-sm font-mono focus:border-avocado focus:outline-none" />
          <input required type="number" placeholder="Discount" value={form.discount} onChange={(e) => setForm({ ...form, discount: e.target.value })} className="px-3 py-2 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as any })} className="px-3 py-2 border border-sand rounded-lg text-sm bg-white focus:border-avocado focus:outline-none">
            <option value="percentage">% Off</option><option value="fixed">NPR Off</option>
          </select>
          <input type="date" value={form.expires} onChange={(e) => setForm({ ...form, expires: e.target.value })} className="px-3 py-2 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <div className="flex gap-2">
            <button type="submit" className="px-4 py-2 bg-avocado text-white text-sm rounded-lg hover:bg-avocado-light">Add</button>
            <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 text-text-muted"><X size={16} /></button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30"><p className="text-sm text-text-muted">Active</p><p className="text-3xl font-display font-bold text-green-600">{coupons.filter((c) => c.status === 'active').length}</p></div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30"><p className="text-sm text-text-muted">Scheduled</p><p className="text-3xl font-display font-bold text-amber-600">{coupons.filter((c) => c.status === 'scheduled').length}</p></div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30"><p className="text-sm text-text-muted">Expired</p><p className="text-3xl font-display font-bold text-red-600">{coupons.filter((c) => c.status === 'expired').length}</p></div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30"><p className="text-sm text-text-muted">Total Used</p><p className="text-3xl font-display font-bold text-avocado">{coupons.reduce((a, c) => a + c.used, 0)}</p></div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden divide-y divide-sand/30">
        {coupons.map((c) => (
          <div key={c.id} className="p-5 hover:bg-cream/30 flex items-center gap-4 cursor-pointer" onClick={() => deleteCoupon(c.id)}>
            <div className="w-10 h-10 rounded-full bg-gold/15 flex items-center justify-center shrink-0"><Tag size={18} className="text-avocado" /></div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <p className="font-mono font-semibold text-avocado-dark bg-cream px-2 py-0.5 rounded text-sm">{c.code}</p>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${c.status === 'active' ? 'bg-green-100 text-green-700' : c.status === 'scheduled' ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-600'}`}>{c.status}</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-text-muted">
                <span>{c.type === 'percentage' ? `${c.discount}% off` : `NPR ${c.discount} off`}</span>
                <span>{c.used}/{c.maxUses} used</span>
                <span>Exp: {new Date(c.expires).toLocaleDateString()}</span>
              </div>
            </div>
            <button onClick={(e) => { e.stopPropagation(); copyCode(c.code) }} className="shrink-0 w-9 h-9 rounded-lg bg-cream flex items-center justify-center hover:bg-avocado/10">
              {copied === c.code ? <Check size={16} className="text-green-600" /> : <Copy size={16} className="text-text-muted" />}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
