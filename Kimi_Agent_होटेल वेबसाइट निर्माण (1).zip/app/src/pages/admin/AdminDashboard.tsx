import { Link } from 'react-router-dom'
import { Users, CalendarDays, Mail, TrendingUp, BedDouble, Bell, AlertCircle, CheckCircle2 } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { useApp } from '@/contexts/AppContext'

const COLORS = ['#2d5a2d', '#c8a55c', '#9b6b9b']

const monthlyData = [
  { month: 'Jan', bookings: 12, revenue: 58000 },
  { month: 'Feb', bookings: 15, revenue: 72000 },
  { month: 'Mar', bookings: 18, revenue: 85000 },
  { month: 'Apr', bookings: 22, revenue: 98000 },
  { month: 'May', bookings: 25, revenue: 115000 },
  { month: 'Jun', bookings: 20, revenue: 92000 },
]

const StatCard = ({ title, value, icon: Icon, color, subtitle, to }: any) => (
  <Link to={to || '#'} className={`bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-sand/30 ${to ? 'cursor-pointer' : ''}`}>
    <div className="flex items-start justify-between">
      <div>
        <p className="text-sm text-text-muted mb-1">{title}</p>
        <p className="text-3xl font-display font-bold text-avocado-dark">{value}</p>
        {subtitle && <p className="text-xs text-text-muted mt-1">{subtitle}</p>}
      </div>
      <div className={`w-11 h-11 rounded-lg flex items-center justify-center ${color}`}><Icon size={20} /></div>
    </div>
  </Link>
)

export default function AdminDashboard() {
  const { bookings, messages } = useApp()

  const totalRevenue = bookings.reduce((a, b) => a + b.totalAmount, 0)
  const paidRevenue = bookings.filter((b) => b.paymentStatus === 'Paid').reduce((a, b) => a + b.totalAmount, 0)
  const pendingCount = bookings.filter((b) => b.status === 'pending').length
  const unreadMessages = messages.filter((m) => m.isRead === 'unread').length

  const statusData = [
    { name: 'Pending', value: bookings.filter((b) => b.status === 'pending').length },
    { name: 'Confirmed', value: bookings.filter((b) => b.status === 'confirmed').length },
    { name: 'Completed', value: bookings.filter((b) => b.status === 'completed').length },
  ].filter((d) => d.value > 0)

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display font-semibold text-3xl text-avocado-dark">Dashboard</h1>
          <p className="text-text-muted mt-1">Welcome back! Here is what is happening at your resort.</p>
        </div>
        <button onClick={() => alert('Reminder notifications sent!')} className="flex items-center gap-2 px-4 py-2.5 bg-avocado text-white text-sm font-medium rounded-lg hover:bg-avocado-light transition-colors">
          <Bell size={16} /> Send Reminders
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard title="Total Bookings" value={bookings.length} icon={CalendarDays} color="bg-blue-50 text-blue-600" subtitle={`${pendingCount} pending`} to="/admin/bookings" />
        <StatCard title="Revenue (NPR)" value={totalRevenue.toLocaleString()} icon={TrendingUp} color="bg-green-50 text-green-600" subtitle={`${paidRevenue.toLocaleString()} collected`} />
        <StatCard title="Messages" value={messages.length} icon={Mail} color="bg-purple-50 text-purple-600" subtitle={`${unreadMessages} unread`} to="/admin/messages" />
        <StatCard title="Occupancy" value="72%" icon={BedDouble} color="bg-amber-50 text-amber-600" subtitle="Current rate" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-sand/30 p-6">
          <h3 className="font-semibold text-lg text-avocado-dark mb-4">Monthly Revenue (NPR)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0ece4" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(v: number) => `NPR ${v.toLocaleString()}`} />
              <Bar dataKey="revenue" fill="#c8a55c" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-6">
          <h3 className="font-semibold text-lg text-avocado-dark mb-4">Booking Status</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={statusData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }: any) => `${name}: ${value}`}>
                {statusData.map((_: any, i: number) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden">
          <div className="px-6 py-4 border-b border-sand/50 flex items-center justify-between">
            <h2 className="font-semibold text-lg text-avocado-dark">Recent Bookings</h2>
            <Link to="/admin/bookings" className="text-xs text-avocado hover:underline">View All</Link>
          </div>
          <div className="divide-y divide-sand/30">
            {bookings.slice(0, 5).map((b) => (
              <div key={b.id} className="px-6 py-4 flex items-center justify-between hover:bg-cream/50">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-avocado/10 flex items-center justify-center"><BedDouble size={16} className="text-avocado" /></div>
                  <div>
                    <p className="text-sm font-medium text-avocado-dark">{b.guestName}</p>
                    <p className="text-xs text-text-muted">{b.roomName} &middot; {new Date(b.checkIn).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-avocado-dark">NPR {b.totalAmount.toLocaleString()}</p>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${b.paymentStatus === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>{b.paymentStatus}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden">
          <div className="px-6 py-4 border-b border-sand/50 flex items-center justify-between">
            <h2 className="font-semibold text-lg text-avocado-dark">Recent Messages</h2>
            <Link to="/admin/messages" className="text-xs text-avocado hover:underline">View All</Link>
          </div>
          <div className="divide-y divide-sand/30">
            {messages.slice(0, 4).map((m) => (
              <div key={m.id} className="px-6 py-4 hover:bg-cream/50">
                <div className="flex items-center gap-2 mb-1">
                  {m.isRead === 'unread' ? <AlertCircle size={12} className="text-amber-500" /> : <CheckCircle2 size={12} className="text-green-500" />}
                  <p className="text-sm font-medium text-avocado-dark">{m.name}</p>
                  <span className="text-[10px] text-text-muted ml-auto">{new Date(m.createdAt).toLocaleDateString()}</span>
                </div>
                <p className="text-sm text-text-muted line-clamp-1">{m.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
