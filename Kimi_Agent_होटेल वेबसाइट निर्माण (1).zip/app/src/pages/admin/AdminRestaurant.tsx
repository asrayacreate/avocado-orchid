import { useState } from 'react'
import { useApp } from '@/contexts/AppContext'
import { ChefHat, Plus, X } from 'lucide-react'

const statusColors: Record<string, string> = { pending: 'bg-amber-100 text-amber-700', 'in-progress': 'bg-blue-100 text-blue-700', completed: 'bg-green-100 text-green-700', cancelled: 'bg-red-100 text-red-700' }
const typeLabels: Record<string, string> = { 'room-service': 'Room Service', restaurant: 'Restaurant', cafe: 'Cafe', banquet: 'Banquet' }

export default function AdminRestaurant() {
  const { orders, setOrders, addOrder } = useApp()
  const [filter, setFilter] = useState('all')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ guestName: '', items: '', total: '', type: 'restaurant' as const, roomNumber: '' })

  const filtered = filter === 'all' ? orders : orders.filter((o) => o.type === filter)

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    addOrder({ guestName: form.guestName || 'Walk-in', items: form.items, total: Number(form.total) || 0, type: form.type, roomNumber: form.roomNumber || null, status: 'pending' })
    setForm({ guestName: '', items: '', total: '', type: 'restaurant', roomNumber: '' })
    setShowForm(false)
  }

  const todayTotal = orders.reduce((a, o) => a + o.total, 0)

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="font-display font-semibold text-3xl text-avocado-dark">Restaurant & Orders</h1><p className="text-text-muted mt-1">Manage food and beverage orders</p></div>
        <button onClick={() => setShowForm(true)} className="flex items-center gap-2 px-4 py-2.5 bg-avocado text-white text-sm font-medium rounded-lg hover:bg-avocado-light"><Plus size={16} /> New Order</button>
      </div>

      {showForm && (
        <form onSubmit={handleAdd} className="bg-white rounded-xl p-6 shadow-sm border border-sand/30 mb-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <input placeholder="Guest name" value={form.guestName} onChange={(e) => setForm({ ...form, guestName: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <input placeholder="Room number (optional)" value={form.roomNumber} onChange={(e) => setForm({ ...form, roomNumber: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as any })} className="px-4 py-2.5 border border-sand rounded-lg text-sm bg-white focus:border-avocado focus:outline-none">
            {Object.entries(typeLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <input required placeholder="Items (e.g. Momo x2, Rice x1)" value={form.items} onChange={(e) => setForm({ ...form, items: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none sm:col-span-2" />
          <input required type="number" placeholder="Total (NPR)" value={form.total} onChange={(e) => setForm({ ...form, total: e.target.value })} className="px-4 py-2.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none" />
          <div className="flex gap-2 sm:col-span-3">
            <button type="submit" className="px-6 py-2.5 bg-avocado text-white text-sm rounded-lg hover:bg-avocado-light">Add Order</button>
            <button type="button" onClick={() => setShowForm(false)} className="px-6 py-2.5 text-text-muted text-sm hover:text-charcoal"><X size={16} /></button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30"><p className="text-sm text-text-muted">Today&apos;s Orders</p><p className="text-3xl font-display font-bold text-avocado-dark">{orders.length}</p></div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30"><p className="text-sm text-text-muted">Pending</p><p className="text-3xl font-display font-bold text-amber-600">{orders.filter((o) => o.status === 'pending').length}</p></div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30"><p className="text-sm text-text-muted">Revenue</p><p className="text-3xl font-display font-bold text-gold">NPR {todayTotal.toLocaleString()}</p></div>
      </div>

      <div className="flex gap-2 mb-6">
        {['all', 'restaurant', 'room-service', 'cafe', 'banquet'].map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === f ? 'bg-avocado text-white' : 'bg-white text-charcoal hover:bg-avocado/10 border border-sand/30'}`}>
            {f === 'all' ? 'All' : typeLabels[f] || f}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-sand/30 overflow-hidden divide-y divide-sand/30">
        {filtered.map((o) => (
          <div key={o.id} className="p-5 hover:bg-cream/30 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center shrink-0"><ChefHat size={18} className="text-avocado" /></div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <p className="font-medium text-avocado-dark">{o.guestName}</p>
                {o.roomNumber && <span className="text-xs text-text-muted">Room {o.roomNumber}</span>}
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cream text-text-muted">{typeLabels[o.type]}</span>
              </div>
              <p className="text-xs text-text-muted">{o.items}</p>
            </div>
            <div className="text-right shrink-0">
              <p className="font-semibold text-avocado-dark">NPR {o.total.toLocaleString()}</p>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${statusColors[o.status]}`}>{o.status}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
