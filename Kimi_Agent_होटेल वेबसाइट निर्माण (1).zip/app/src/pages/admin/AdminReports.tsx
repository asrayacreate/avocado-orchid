import { useApp } from '@/contexts/AppContext'
import { Download, FileSpreadsheet, FileText, BarChart3 } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'

const occupancyData = [
  { day: 'Mon', rate: 65 }, { day: 'Tue', rate: 72 }, { day: 'Wed', rate: 80 },
  { day: 'Thu', rate: 75 }, { day: 'Fri', rate: 88 }, { day: 'Sat', rate: 95 }, { day: 'Sun', rate: 85 },
]

const revenueByRoom = [
  { room: 'Deluxe', revenue: 125000 }, { room: 'Super Deluxe', revenue: 180000 },
  { room: 'Semi Suite', revenue: 95000 }, { room: 'Suite', revenue: 140000 },
]

export default function AdminReports() {
  const { bookings, expenses } = useApp()
  const totalRev = bookings.filter((b) => b.paymentStatus === 'Paid').reduce((a, b) => a + b.totalAmount, 0)
  const totalExp = expenses.reduce((a, e) => a + e.amount, 0)

  const downloadCSV = (filename: string, data: any[]) => {
    if (!data.length) return
    const headers = Object.keys(data[0]).join(',')
    const rows = data.map((r) => Object.values(r).map((v) => `"${v}"`).join(','))
    const csv = [headers, ...rows].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url)
  }

  return (
    <div>
      <h1 className="font-display font-semibold text-3xl text-avocado-dark mb-1">Analytics & Reports</h1>
      <p className="text-text-muted mb-6">Download monthly statistics and view analytics</p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <button onClick={() => downloadCSV('bookings-report.csv', bookings)} className="bg-white rounded-xl p-5 shadow-sm border border-sand/30 hover:shadow-md transition-all text-left group">
          <div className="flex items-center justify-between mb-3"><FileSpreadsheet size={24} className="text-green-600" /><Download size={16} className="text-text-muted group-hover:text-avocado" /></div>
          <p className="font-semibold text-avocado-dark">Export Bookings</p><p className="text-xs text-text-muted">{bookings.length} records as CSV</p>
        </button>
        <button onClick={() => downloadCSV('expenses-report.csv', expenses)} className="bg-white rounded-xl p-5 shadow-sm border border-sand/30 hover:shadow-md transition-all text-left group">
          <div className="flex items-center justify-between mb-3"><FileText size={24} className="text-red-600" /><Download size={16} className="text-text-muted group-hover:text-avocado" /></div>
          <p className="font-semibold text-avocado-dark">Export Expenses</p><p className="text-xs text-text-muted">{expenses.length} records as CSV</p>
        </button>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-sand/30">
          <div className="flex items-center justify-between mb-3"><BarChart3 size={24} className="text-avocado" /></div>
          <p className="font-semibold text-avocado-dark">Net Summary</p>
          <p className="text-xs text-text-muted">Revenue: NPR {totalRev.toLocaleString()}</p>
          <p className="text-xs text-text-muted">Expenses: NPR {totalExp.toLocaleString()}</p>
          <p className="text-sm font-semibold text-green-600 mt-1">Profit: NPR {(totalRev - totalExp).toLocaleString()}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-6">
          <h3 className="font-semibold text-lg text-avocado-dark mb-4">Weekly Occupancy Rate (%)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={occupancyData}><CartesianGrid strokeDasharray="3 3" stroke="#f0ece4" /><XAxis dataKey="day" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 12 }} domain={[0, 100]} /><Tooltip formatter={(v: number) => `${v}%`} /><Line type="monotone" dataKey="rate" stroke="#2d5a2d" strokeWidth={2} dot={{ fill: '#c8a55c' }} /></LineChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-sand/30 p-6">
          <h3 className="font-semibold text-lg text-avocado-dark mb-4">Revenue by Room Type</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={revenueByRoom}><CartesianGrid strokeDasharray="3 3" stroke="#f0ece4" /><XAxis dataKey="room" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 12 }} /><Tooltip formatter={(v: number) => `NPR ${v.toLocaleString()}`} /><Bar dataKey="revenue" fill="#c8a55c" radius={[4, 4, 0, 0]} /></BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}
