import { useState, useRef } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useLanguage } from '@/contexts/LanguageContext'
import Lightbox from '../components/Lightbox'

gsap.registerPlugin(ScrollTrigger)

const allImages = [
  { src: '/images/hero-exterior-night.jpg', alt: 'Hotel exterior at night', category: 'hotel' },
  { src: '/images/room-deluxe.jpg', alt: 'Deluxe Room', category: 'rooms' },
  { src: '/images/room-super-deluxe.jpg', alt: 'Super Deluxe Room', category: 'rooms' },
  { src: '/images/room-semi-suite.jpg', alt: 'Semi Suite', category: 'rooms' },
  { src: '/images/room-suite.jpg', alt: 'Suite Room', category: 'rooms' },
  { src: '/images/orchid-garden.jpg', alt: 'Orchid Garden', category: 'garden' },
  { src: '/images/avocado-orchard.jpg', alt: 'Avocado Orchard', category: 'garden' },
  { src: '/images/restaurant-dining.jpg', alt: 'Restaurant Dining', category: 'dining' },
  { src: '/images/cafe-interior.jpg', alt: 'Crust Cafe', category: 'dining' },
  { src: '/images/food-platter.jpg', alt: 'Multi-cuisine Food', category: 'dining' },
  { src: '/images/bar-lounge.jpg', alt: 'Bar & Lounge', category: 'dining' },
  { src: '/images/hotel-lobby.jpg', alt: 'Hotel Lobby', category: 'hotel' },
  { src: '/images/hero-exterior-day.jpg', alt: 'Hotel exterior daytime', category: 'hotel' },
]

const Gallery = () => {
  const { _ } = useLanguage()
  const [activeFilter, setActiveFilter] = useState('all')
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const [currentImage, setCurrentImage] = useState(0)
  const sectionRef = useRef<HTMLDivElement>(null)

  const categories = [
    { id: 'all', label: _('all') },
    { id: 'rooms', label: _('rooms') },
    { id: 'dining', label: _('dining') },
    { id: 'garden', label: _('garden') },
    { id: 'hotel', label: _('hotelLabel') },
  ]

  const filteredImages = activeFilter === 'all'
    ? allImages
    : allImages.filter((img) => img.category === activeFilter)

  const openLightbox = (index: number) => {
    setCurrentImage(index)
    setLightboxOpen(true)
  }

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.gallery-hero > *', {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.15,
      ease: 'power3.out',
    })
  }, { scope: sectionRef })

  return (
    <div ref={sectionRef}>
      {/* Hero */}
      <section className="relative h-[40vh] min-h-[280px] flex items-center justify-center overflow-hidden">
        <img
          src="/images/orchid-garden.jpg"
          alt="Orchid Garden"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-forest/65" />
        <div className="relative z-10 text-center px-6">
          <p className="gallery-hero text-xs tracking-[0.2em] font-semibold text-gold uppercase mb-4">
            {_('galleryLabel')}
          </p>
          <h1 className="gallery-hero font-display font-bold text-4xl sm:text-5xl lg:text-[56px] text-white leading-tight">
            {_('visualJourney')}
          </h1>
        </div>
      </section>

      {/* Photo Gallery */}
      <section className="bg-white py-20 lg:py-28">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveFilter(cat.id)}
                className={`px-6 py-2.5 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeFilter === cat.id
                    ? 'bg-avocado text-white'
                    : 'bg-cream text-charcoal hover:bg-avocado/10'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Masonry Grid */}
          <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
            {filteredImages.map((img, i) => (
              <div
                key={`${img.src}-${activeFilter}`}
                className="break-inside-avoid relative overflow-hidden rounded-lg cursor-pointer group"
                onClick={() => openLightbox(i)}
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-avocado/0 group-hover:bg-avocado/40 transition-colors duration-300 flex items-center justify-center">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                    <line x1="11" y1="8" x2="11" y2="14" />
                    <line x1="8" y1="11" x2="14" y2="11" />
                  </svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightboxOpen && (
        <Lightbox
          images={filteredImages}
          currentIndex={currentImage}
          onClose={() => setLightboxOpen(false)}
          onNavigate={setCurrentImage}
        />
      )}
    </div>
  )
}

export default Gallery