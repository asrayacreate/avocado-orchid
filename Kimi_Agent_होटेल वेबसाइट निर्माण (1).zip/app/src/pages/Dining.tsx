import { useRef } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Clock, Utensils, Coffee, Wine } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

gsap.registerPlugin(ScrollTrigger)

const Dining = () => {
  const { _ } = useLanguage()
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.dining-hero > *', {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.15,
      ease: 'power3.out',
    })

    gsap.from('.restaurant-card', {
      opacity: 0,
      y: 50,
      duration: 0.9,
      stagger: 0.2,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.restaurants-section',
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <div ref={sectionRef}>
      {/* Hero */}
      <section className="relative h-[50vh] min-h-[350px] flex items-center justify-center overflow-hidden">
        <img
          src="/images/restaurant-dining.jpg"
          alt="Avocado Restaurant"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-forest/65" />
        <div className="relative z-10 text-center px-6">
          <p className="dining-hero text-xs tracking-[0.2em] font-semibold text-gold uppercase mb-4">
            {_('dining')}
          </p>
          <h1 className="dining-hero font-display font-bold text-4xl sm:text-5xl lg:text-[56px] text-white leading-tight mb-4">
            {_('feastSenses')}
          </h1>
          <p className="dining-hero text-lg text-white/70 max-w-[600px] mx-auto">
            {_('diningCuisineDesc')}
          </p>
        </div>
      </section>

      {/* Restaurant Details */}
      <section className="restaurants-section bg-cream py-20 lg:py-28">
        <div className="max-w-[1100px] mx-auto px-6 lg:px-10 space-y-16">
          {/* Avocado Restaurant */}
          <div className="restaurant-card bg-white rounded-2xl overflow-hidden shadow-card">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-8 lg:p-12">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-12 h-12 rounded-full bg-avocado/10 flex items-center justify-center">
                    <Utensils size={22} className="text-avocado" />
                  </div>
                  <div>
                    <h2 className="font-display font-semibold text-3xl text-avocado-dark">{_('avocadoRestaurant')}</h2>
                  </div>
                </div>
                <p className="text-charcoal leading-relaxed mb-6">
                  {_('restaurantDesc')}
                </p>
                <div className="flex items-center gap-2 text-sm text-avocado mb-5">
                  <Clock size={15} />
                  <span>{_('openDaily')}</span>
                </div>
                <div className="flex flex-wrap gap-2 mb-6">
                  {_('cuisines').split(' • ').map((c) => (
                    <span key={c} className="bg-avocado/10 text-avocado text-xs font-medium px-3 py-1.5 rounded-full">
                      {c}
                    </span>
                  ))}
                </div>
                <a
                  href="tel:+9779801804340"
                  className="inline-block px-8 py-3.5 bg-avocado text-white font-semibold text-sm rounded-full hover:bg-avocado-light transition-all duration-300 shadow-button"
                >
                  {_('makeReservation')}
                </a>
              </div>
              <div className="relative">
                <img
                  src="/images/restaurant-dining.jpg"
                  alt="Avocado Restaurant interior"
                  className="w-full h-full object-cover min-h-[300px]"
                  loading="lazy"
                />
              </div>
            </div>
          </div>

          {/* Crust Cafe */}
          <div className="restaurant-card bg-white rounded-2xl overflow-hidden shadow-card">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="relative lg:order-1">
                <img
                  src="/images/cafe-interior.jpg"
                  alt="Crust Cafe interior"
                  className="w-full h-full object-cover min-h-[300px]"
                  loading="lazy"
                />
              </div>
              <div className="p-8 lg:p-12 lg:order-2">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-12 h-12 rounded-full bg-avocado/10 flex items-center justify-center">
                    <Coffee size={22} className="text-avocado" />
                  </div>
                  <div>
                    <h2 className="font-display font-semibold text-3xl text-avocado-dark">{_('crustCafe')}</h2>
                  </div>
                </div>
                <p className="text-charcoal leading-relaxed mb-6">
                  {_('cafeDesc')}
                </p>
                <div className="flex items-center gap-2 text-sm text-avocado mb-5">
                  <Clock size={15} />
                  <span>{_('openDaily')}</span>
                </div>
                <a
                  href="tel:+9779801804340"
                  className="inline-block px-8 py-3.5 bg-avocado text-white font-semibold text-sm rounded-full hover:bg-avocado-light transition-all duration-300 shadow-button"
                >
                  {_('visitCafe')}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bar & Lounge */}
      <section className="bg-forest py-20 lg:py-28">
        <div className="max-w-[800px] mx-auto px-6 lg:px-10 text-center">
          <div className="w-16 h-16 rounded-full bg-gold/20 flex items-center justify-center mx-auto mb-6">
            <Wine size={28} className="text-gold" />
          </div>
          <p className="text-xs tracking-[0.2em] font-semibold text-gold uppercase mb-4">
            {_('relaxUnwind')}
          </p>
          <h2 className="font-display font-semibold text-4xl lg:text-[52px] text-white leading-[1.1] mb-5">
            {_('barLounge')}
          </h2>
          <p className="text-lg text-white/80 leading-relaxed mb-4">
            {_('barDescPage')}
          </p>
          <p className="text-gold font-medium mb-10">{_('barHours')}</p>
          <img
            src="/images/bar-lounge.jpg"
            alt="Bar and Lounge"
            className="rounded-2xl w-full aspect-[21/9] object-cover shadow-image"
            loading="lazy"
          />
        </div>
      </section>
    </div>
  )
}

export default Dining
