import { useState } from 'react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { Link } from 'react-router-dom'
import {
  User, CalendarDays, BedDouble, DollarSign, ArrowLeft,
  CheckCircle2, XCircle, Receipt, Download,
} from 'lucide-react'

const currencyRates: Record<string, number> = { USD: 0.0075, EUR: 0.0069, INR: 0.625, GBP: 0.0059 }

const GuestPortal = () => {
  const { user, isAuthenticated, isLoading } = useAuth()
  const [currency, setCurrency] = useState('NPR')
  const { data: allBookings } = trpc.booking.list.useQuery(undefined, { enabled: isAuthenticated })

  const rate = currency === 'NPR' ? 1 : (currencyRates[currency] || 1)
  const formatAmount = (npr: number) => {
    if (currency === 'NPR') return `NPR ${npr.toLocaleString()}`
    return `${currency} ${(npr * rate).toFixed(2)}`
  }

  if (isLoading) {
    return <div className="min-h-screen bg-cream flex items-center justify-center"><div className="animate-spin w-8 h-8 border-2 border-avocado border-t-transparent rounded-full" /></div>
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <User size={48} className="text-sand mx-auto mb-4" />
          <h2 className="font-display font-semibold text-2xl text-avocado-dark mb-2">Guest Portal</h2>
          <p className="text-text-muted mb-6">Please login to view your bookings and profile.</p>
          <Link to="/login" className="px-8 py-3 bg-avocado text-white font-semibold rounded-full hover:bg-avocado-light transition-colors">Login</Link>
        </div>
      </div>
    )
  }

  const myBookings = allBookings || []
  const upcoming = myBookings.filter((b) => new Date(b.checkIn) >= new Date() && b.status !== 'cancelled')
  const past = myBookings.filter((b) => new Date(b.checkOut) < new Date() || b.status === 'completed')

  return (
    <div className="min-h-screen bg-cream">
      <div className="max-w-[1100px] mx-auto px-6 lg:px-10 py-10">
        <Link to="/" className="flex items-center gap-2 text-sm text-avocado hover:underline mb-6">
          <ArrowLeft size={16} /> Back to Home
        </Link>

        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display font-semibold text-3xl text-avocado-dark">My Account</h1>
            <p className="text-text-muted mt-1">Welcome back, {user?.name}!</p>
          </div>
          <select value={currency} onChange={(e) => setCurrency(e.target.value)}
            className="px-4 py-2 border border-sand rounded-lg text-sm bg-white focus:border-avocado focus:outline-none">
            <option value="NPR">NPR (Rs)</option>
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (&euro;)</option>
            <option value="GBP">GBP (&pound;)</option>
            <option value="INR">INR (&#8377;)</option>
          </select>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow-card p-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-avocado/10 flex items-center justify-center"><CalendarDays size={20} className="text-avocado" /></div>
              <div><p className="text-sm text-text-muted">Upcoming</p><p className="text-2xl font-display font-bold text-avocado-dark">{upcoming.length}</p></div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-card p-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gold/20 flex items-center justify-center"><DollarSign size={20} className="text-amber-700" /></div>
              <div><p className="text-sm text-text-muted">Total Spent</p><p className="text-2xl font-display font-bold text-avocado-dark">{formatAmount(myBookings.reduce((s, b) => s + (b.totalAmount || 0), 0))}</p></div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-card p-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center"><BedDouble size={20} className="text-purple-600" /></div>
              <div><p className="text-sm text-text-muted">Total Stays</p><p className="text-2xl font-display font-bold text-avocado-dark">{myBookings.length}</p></div>
            </div>
          </div>
        </div>

        {/* Upcoming Bookings */}
        <div className="bg-white rounded-xl shadow-card overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-sand/50"><h2 className="font-sans font-semibold text-lg text-avocado-dark">Upcoming Stays</h2></div>
          <div className="divide-y divide-sand/30">
            {upcoming.length ? upcoming.map((b) => (
              <div key={b.id} className="px-6 py-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-avocado/10 flex items-center justify-center shrink-0">
                      <BedDouble size={22} className="text-avocado" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-avocado-dark">Room #{b.roomId}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                          b.status === 'confirmed' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                        }`}>{b.status}</span>
                      </div>
                      <p className="text-sm text-text-muted">{new Date(b.checkIn).toLocaleDateString()} - {new Date(b.checkOut).toLocaleDateString()} | {b.totalNights} nights</p>
                      <div className="flex items-center gap-3 mt-2">
                        <span className="text-sm font-semibold text-avocado-dark">{formatAmount(b.totalAmount)}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                          b.paymentStatus === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                        }`}>{b.paymentStatus}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {b.invoiceUrl && (
                      <a href={b.invoiceUrl} target="_blank" rel="noopener noreferrer"
                        className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-avocado border border-avocado/20 rounded-lg hover:bg-avocado/5 transition-colors">
                        <Receipt size={14} /> Invoice
                      </a>
                    )}
                  </div>
                </div>
              </div>
            )) : <div className="px-6 py-8 text-center text-text-muted text-sm">No upcoming bookings</div>}
          </div>
        </div>

        {/* Past Bookings */}
        <div className="bg-white rounded-xl shadow-card overflow-hidden">
          <div className="px-6 py-4 border-b border-sand/50"><h2 className="font-sans font-semibold text-lg text-avocado-dark">Booking History</h2></div>
          <div className="divide-y divide-sand/30">
            {past.length ? past.map((b) => (
              <div key={b.id} className="px-6 py-4 flex items-center justify-between hover:bg-cream/50">
                <div className="flex items-center gap-3">
                  {b.status === 'completed' ? <CheckCircle2 size={16} className="text-green-500" /> : <XCircle size={16} className="text-red-400" />}
                  <div>
                    <p className="text-sm font-medium text-avocado-dark">Room #{b.roomId}</p>
                    <p className="text-xs text-text-muted">{new Date(b.checkIn).toLocaleDateString()} - {new Date(b.checkOut).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium text-avocado-dark">{formatAmount(b.totalAmount)}</span>
                  <button className="p-1.5 text-text-muted hover:text-avocado transition-colors" title="Download Receipt">
                    <Download size={14} />
                  </button>
                </div>
              </div>
            )) : <div className="px-6 py-8 text-center text-text-muted text-sm">No past bookings</div>}
          </div>
        </div>
      </div>
    </div>
  )
}

export default GuestPortal
