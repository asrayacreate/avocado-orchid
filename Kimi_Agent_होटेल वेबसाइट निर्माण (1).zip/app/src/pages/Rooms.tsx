import { useState, useRef } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Users, Maximize, Wind, Bath, Check, BedDouble, Wifi, Tv, Refrigerator, Coffee, Phone, Star, Zap, Droplets, CheckCircle2 } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

gsap.registerPlugin(ScrollTrigger)

type TabType = 'room' | 'bathroom' | 'amenities'

interface RoomData {
  id: string
  name: string
  nameNp: string
  guests: string
  size: string
  beds: string
  bedsNp: string
  desc: string
  descNp: string
  price: string
  image: string
  bathroom: string
  amenities: string[]
  features: string[]
  featuresNp: string[]
  amenityIcons: string[]
}

const roomsData: RoomData[] = [
  {
    id: 'deluxe', name: 'Deluxe A/C Room', nameNp: 'डिलक्स ए/सी कोठा', guests: '2-3', size: '251',
    beds: '1 Twin Bed + 1 Double Bed', bedsNp: '१ ट्विन बेड + १ डबल बेड',
    desc: 'Comfortable accommodation with 1 Twin Bed and 1 Double Bed option. Perfect for families or small groups seeking a cozy retreat with all essential amenities. Features garden views and modern furnishings.',
    descNp: 'ट्विन बेड र डबल बेड विकल्प भएको आरामदायक आवास। परिवार वा सानो समूहको लागि उत्तम। बगैंचाको दृश्य र आधुनिक सजावट।',
    price: '3,500', image: '/images/room-deluxe.jpg', bathroom: '/images/bathroom-deluxe.jpg',
    amenities: ['Free Wi-Fi', 'Flat-screen TV', 'Air Conditioning', 'Private Bathroom', 'Daily Housekeeping', 'Garden View', 'Desk', 'Electric Kettle', 'Wardrobe'],
    features: ['Garden View', 'Smoke-Free', 'Family Friendly', 'Soundproof Windows'],
    featuresNp: ['बगैंचा दृश्य', 'धुवाँमुक्त', 'परिवार अनुकूल', 'साउन्डप्रुफ झ्याल'],
    amenityIcons: ['wifi', 'tv', 'ac', 'bath', 'clean', 'view', 'desk', 'kettle', 'wardrobe'],
  },
  {
    id: 'super-deluxe', name: 'Super Deluxe A/C Room', nameNp: 'सुपर डिलक्स ए/सी कोठा', guests: '2', size: '287',
    beds: '1 Double Bed or 2 Single Beds', bedsNp: '१ डबल बेड वा २ सिंगल बेड',
    desc: 'Spacious room with 1 Double Bed or 2 Single Bed options. Enjoy premium comfort with enhanced furnishings, large windows with garden views, and a relaxing atmosphere designed for discerning travelers.',
    descNp: 'डबल बेड वा सिंगल बेड विकल्प भएको विशाल कोठा। प्रीमियम आराम, बगैंचा दृश्य र शान्त वातावरण।',
    price: '4,500', image: '/images/room-super-deluxe.jpg', bathroom: '/images/bathroom-super-deluxe.jpg',
    amenities: ['Free Wi-Fi', 'Flat-screen TV', 'Minibar', 'Air Conditioning', 'Private Bathroom', 'Daily Housekeeping', 'Garden View', 'Desk', 'Room Service'],
    features: ['Garden View', 'Premium Bedding', 'Rain Shower', 'Mini Bar'],
    featuresNp: ['बगैंचा दृश्य', 'प्रीमियम बेडिङ', 'रेिन शावर', 'मिनी बार'],
    amenityIcons: ['wifi', 'tv', 'minibar', 'ac', 'bath', 'clean', 'view', 'desk', 'service'],
  },
  {
    id: 'semi-suite', name: 'Semi Suite', nameNp: 'सेमी सुइट', guests: '2', size: '287',
    beds: '1 Double Bed', bedsNp: '१ डबल बेड',
    desc: 'Elegant semi-suite featuring 1 Double Bed with a separate seating area. Enhanced amenities for a more luxurious experience, including garden views and refined decor that reflects the natural beauty of our resort.',
    descNp: 'छुट्टै बस्ने क्षेत्र भएको सुन्दर सेमी-सुइट। बगैंचा दृश्य र उन्नत सुविधाहरू।',
    price: '5,500', image: '/images/room-semi-suite.jpg', bathroom: '/images/bathroom-semi-suite.jpg',
    amenities: ['Free Wi-Fi', 'Flat-screen TV', 'Minibar', 'Air Conditioning', 'Private Bathroom', 'Daily Housekeeping', 'Garden View', 'Seating Area', 'Room Service', 'Slippers'],
    features: ['Separate Living Area', 'Premium Toiletries', 'Bathrobe', 'Coffee Maker'],
    featuresNp: ['छुट्टै बस्ने क्षेत्र', 'प्रीमियम ट्वाइलेट्रीज', 'बाथरोब', 'कफी मेकर'],
    amenityIcons: ['wifi', 'tv', 'minibar', 'ac', 'bath', 'clean', 'view', 'sofa', 'service', 'slippers'],
  },
  {
    id: 'suite', name: 'Suite Room', nameNp: 'सुइट कोठा', guests: '2-4', size: '538',
    beds: '1 Double Bed + 2 Single Beds', bedsNp: '१ डबल बेड + २ सिंगल बेड',
    desc: 'Our most luxurious accommodation featuring 1 Double Bed and 2 Single Beds. The suite includes a minibar, refrigerator, and separate living area. Maximum space and comfort for families or guests seeking the ultimate resort experience.',
    descNp: 'हाम्रो सबैभन्दा भव्य आवास। मिनिबार, रेफ्रिजरेटर र छुट्टै बस्ने क्षेत्र। परिवारको लागि उत्तम।',
    price: '7,500', image: '/images/room-suite.jpg', bathroom: '/images/bathroom-suite.jpg',
    amenities: ['Free Wi-Fi', 'Flat-screen TV', 'Minibar', 'Refrigerator', 'Air Conditioning', 'Private Bathroom', 'Daily Housekeeping', 'Living Area', 'Room Service', 'Premium Toiletries'],
    features: ['Living Room', 'Refrigerator', 'Mountain View', 'Luxury Bathroom'],
    featuresNp: ['बस्ने कोठा', 'रेफ्रिजरेटर', 'पहाड दृश्य', 'भव्य बाथरूम'],
    amenityIcons: ['wifi', 'tv', 'minibar', 'fridge', 'ac', 'bath', 'clean', 'sofa', 'service', 'toiletries'],
  },
]

const iconMap: Record<string, React.ElementType> = {
  wifi: Wifi, tv: Tv, ac: Wind, bath: Bath, clean: Star, view: Maximize,
  desk: Check, kettle: Coffee, wardrobe: Check, minibar: Refrigerator,
  service: Phone, sofa: BedDouble, slippers: Check, fridge: Refrigerator,
  toiletries: Droplets,
}

const tabLabels = { room: { en: 'Room View', np: 'कोठा' }, bathroom: { en: 'Bathroom', np: 'बाथरूम' }, amenities: { en: 'Amenities', np: 'सुविधाहरू' } }

export default function Rooms() {
  const { _, isNepali } = useLanguage()
  const [activeFilter, setActiveFilter] = useState('all')
  const [photoTabs, setPhotoTabs] = useState<Record<string, TabType>>({
    deluxe: 'room', 'super-deluxe': 'room', 'semi-suite': 'room', suite: 'room',
  })
  const sectionRef = useRef<HTMLDivElement>(null)

  const setTab = (roomId: string, tab: TabType) => {
    setPhotoTabs((prev) => ({ ...prev, [roomId]: tab }))
  }

  const filtered = activeFilter === 'all' ? roomsData : roomsData.filter((r) => r.id === activeFilter)

  const filterTabs = [
    { id: 'all', label: isNepali ? 'सबै' : 'All' },
    { id: 'deluxe', label: 'Deluxe A/C' },
    { id: 'super-deluxe', label: 'Super Deluxe A/C' },
    { id: 'semi-suite', label: 'Semi Suite' },
    { id: 'suite', label: 'Suite' },
  ]

  useGSAP(() => {
    if (!sectionRef.current) return
    gsap.from('.rooms-hero > *', { opacity: 0, y: 30, duration: 0.8, stagger: 0.15, ease: 'power3.out' })
  }, { scope: sectionRef })

  return (
    <div ref={sectionRef}>
      {/* Hero */}
      <section className="relative h-[50vh] min-h-[350px] flex items-center justify-center overflow-hidden">
        <img src="/images/room-suite.jpg" alt="Luxury room" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-forest/65" />
        <div className="relative z-10 text-center px-6">
          <p className="rooms-hero text-xs tracking-[0.2em] font-semibold text-gold uppercase mb-4">{isNepali ? 'हाम्रो कोठाहरू' : 'OUR ROOMS'}</p>
          <h1 className="rooms-hero font-display font-bold text-4xl sm:text-5xl lg:text-[56px] text-white leading-tight mb-4">{isNepali ? 'आफ्नो उत्तम बसाइ खोज्नुहोस्' : 'Find Your Perfect Stay'}</h1>
          <p className="rooms-hero text-lg text-white/70 max-w-[600px] mx-auto">{isNepali ? 'आराम र विश्रामको लागि डिजाइन गरिएका ५८ कोठाहरू' : '58 air-conditioned rooms designed for comfort and relaxation'}</p>
        </div>
      </section>

      {/* Filter Bar */}
      <section className="sticky top-[72px] z-30 bg-cream/95 backdrop-blur-sm border-b border-sand/50">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-10 py-4">
          <div className="flex flex-wrap gap-2 justify-center">
            {filterTabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveFilter(tab.id)}
                className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 ${activeFilter === tab.id ? 'bg-avocado text-white' : 'bg-white text-charcoal hover:bg-avocado/10 border border-sand'}`}>
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Room Listings */}
      <section className="bg-cream py-12 lg:py-20">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
          <div className="space-y-16">
            {filtered.map((room, index) => {
              const currentTab = photoTabs[room.id] || 'room'
              const isEven = index % 2 === 0
              return (
                <div key={room.id} className="bg-white rounded-2xl overflow-hidden shadow-card hover:shadow-card-hover transition-shadow duration-500">
                  <div className="grid grid-cols-1 lg:grid-cols-2">
                    {/* Photo Gallery with 3 Tabs */}
                    <div className={`relative ${isEven ? '' : 'lg:order-2'}`}>
                      <div className="relative aspect-[4/3] lg:aspect-auto lg:h-full min-h-[350px]">
                        {/* Room Image */}
                        {currentTab === 'room' && (
                          <img src={room.image} alt={`${room.name} bedroom`} className="w-full h-full object-cover animate-in" />
                        )}
                        {/* Bathroom Image */}
                        {currentTab === 'bathroom' && (
                          <img src={room.bathroom} alt={`${room.name} bathroom`} className="w-full h-full object-cover animate-in" />
                        )}
                        {/* Amenities Grid */}
                        {currentTab === 'amenities' && (
                          <div className="w-full h-full bg-forest p-6 flex flex-col justify-center">
                            <h4 className="text-white font-semibold text-lg mb-4 text-center">{isNepali ? 'सुविधाहरू' : 'Room Amenities'}</h4>
                            <div className="grid grid-cols-3 gap-3">
                              {room.amenities.map((amenity, i) => {
                                const Icon = iconMap[room.amenityIcons[i]] || CheckCircle2
                                return (
                                  <div key={amenity} className="bg-white/10 rounded-lg p-3 text-center backdrop-blur-sm">
                                    <Icon size={20} className="text-gold mx-auto mb-1.5" />
                                    <p className="text-white text-[10px] leading-tight">{amenity}</p>
                                  </div>
                                )
                              })}
                            </div>
                          </div>
                        )}

                        {/* 3-Tab Switcher */}
                        <div className="absolute bottom-4 left-4 right-4 flex gap-2">
                          {(['room', 'bathroom', 'amenities'] as const).map((tab) => (
                            <button key={tab} onClick={() => setTab(room.id, tab)}
                              className={`flex-1 px-3 py-2 rounded-full text-xs font-medium backdrop-blur-md transition-all text-center ${
                                currentTab === tab ? 'bg-gold text-forest' : 'bg-black/50 text-white hover:bg-black/70'
                              }`}>
                              {isNepali ? tabLabels[tab].np : tabLabels[tab].en}
                            </button>
                          ))}
                        </div>

                        {/* Price Tag */}
                        <div className="absolute top-4 right-4 bg-gold text-forest px-4 py-2 rounded-full shadow-lg">
                          <span className="font-display font-bold text-lg">NPR {room.price}</span>
                          <span className="text-xs font-medium">{isNepali ? '/रात' : '/night'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Details */}
                    <div className={`p-8 lg:p-10 ${isEven ? '' : 'lg:order-1'}`}>
                      <h2 className="font-display font-semibold text-3xl text-avocado-dark mb-2">{isNepali ? room.nameNp : room.name}</h2>
                      <p className="text-sm text-gold font-medium mb-5">{isNepali ? room.bedsNp : room.beds}</p>

                      <div className="flex flex-wrap gap-3 mb-6 pb-6 border-b border-sand/50">
                        <span className="flex items-center gap-1.5 text-sm text-charcoal bg-cream px-3 py-1.5 rounded-full"><Users size={14} className="text-avocado" /> {room.guests} {isNepali ? 'पाहुना' : 'guests'}</span>
                        <span className="flex items-center gap-1.5 text-sm text-charcoal bg-cream px-3 py-1.5 rounded-full"><Maximize size={14} className="text-avocado" /> {room.size} {isNepali ? 'sq ft' : 'sq ft'}</span>
                        <span className="flex items-center gap-1.5 text-sm text-charcoal bg-cream px-3 py-1.5 rounded-full"><Wind size={14} className="text-avocado" /> {isNepali ? 'एयर कन्डिसन्ड' : 'A/C'}</span>
                        <span className="flex items-center gap-1.5 text-sm text-charcoal bg-cream px-3 py-1.5 rounded-full"><Bath size={14} className="text-avocado" /> {isNepali ? 'निजी बाथरूम' : 'Private Bath'}</span>
                      </div>

                      <p className="text-charcoal leading-relaxed mb-6">{isNepali ? room.descNp : room.desc}</p>

                      <div className="mb-6">
                        <h4 className="text-sm font-semibold text-avocado-dark mb-3">{isNepali ? 'विशेषताहरू' : 'Key Features'}</h4>
                        <div className="grid grid-cols-2 gap-2">
                          {(isNepali ? room.featuresNp : room.features).map((f, i) => (
                            <div key={i} className="flex items-center gap-2 text-sm text-charcoal"><Check size={14} className="text-gold shrink-0" /> {f}</div>
                          ))}
                        </div>
                      </div>

                      <a href="https://avocadoresort.com/result.php?hotel_code=U3q5qz" target="_blank" rel="noopener noreferrer"
                        className="inline-block px-10 py-4 bg-gold text-forest font-semibold text-sm rounded-full hover:bg-gold-light transition-all duration-300 shadow-button">
                        {isNepali ? 'यो कोठा बुक गर्नुहोस्' : 'Book This Room'}
                      </a>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Comparison */}
      <section className="bg-forest py-16 lg:py-24">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
          <div className="text-center mb-12">
            <p className="text-xs tracking-[0.2em] font-semibold text-gold uppercase mb-3">{isNepali ? 'तुलना' : 'COMPARE'}</p>
            <h2 className="font-display font-semibold text-3xl lg:text-4xl text-white">{isNepali ? 'आफ्नो कोठा छनोट गर्नुहोस्' : 'Choose Your Room'}</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {roomsData.map((room) => (
              <div key={room.id} className="bg-white/[0.05] border border-white/[0.08] rounded-xl p-6 text-center hover:-translate-y-1 hover:border-gold/30 transition-all duration-300">
                <img src={room.image} alt={room.name} className="w-full aspect-[4/3] object-cover rounded-lg mb-4" loading="lazy" />
                <h3 className="font-display font-semibold text-lg text-white mb-2">{isNepali ? room.nameNp : room.name}</h3>
                <p className="text-white/50 text-sm mb-3">{room.guests} {isNepali ? 'पाहुना' : 'guests'} &middot; {room.size} sq ft</p>
                <div className="font-display font-bold text-2xl text-gold mb-4">NPR {room.price}<span className="text-xs text-white/40 font-normal">{isNepali ? '/रात' : '/night'}</span></div>
                <a href="https://avocadoresort.com/result.php?hotel_code=U3q5qz" target="_blank" rel="noopener noreferrer" className="inline-block w-full py-2.5 bg-gold text-forest font-semibold text-sm rounded-full hover:bg-gold-light transition-colors">{isNepali ? 'बुक गर्नुहोस्' : 'Book Now'}</a>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
