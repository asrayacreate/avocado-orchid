import HeroSection from '../sections/HeroSection'
import AboutSection from '../sections/AboutSection'
import RoomShowcaseSection from '../sections/RoomShowcaseSection'
import WhyChooseUsSection from '../sections/WhyChooseUsSection'
import DiningSection from '../sections/DiningSection'
import GallerySection from '../sections/GallerySection'
import TestimonialsSection from '../sections/TestimonialsSection'
import NearbyAttractionsSection from '../sections/NearbyAttractionsSection'
import ContactCTASection from '../sections/ContactCTASection'

const Home = () => {
  return (
    <>
      <HeroSection />
      <AboutSection />
      <RoomShowcaseSection />
      <WhyChooseUsSection />
      <DiningSection />
      <GallerySection />
      <TestimonialsSection />
      <NearbyAttractionsSection />
      <ContactCTASection />
    </>
  )
}

export default Home
