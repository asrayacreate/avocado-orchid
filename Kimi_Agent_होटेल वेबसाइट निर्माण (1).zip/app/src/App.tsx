import { Routes, Route } from 'react-router-dom'
import { useEffect } from 'react'
import Layout from './components/Layout'
import Home from './pages/Home'
import Rooms from './pages/Rooms'
import Dining from './pages/Dining'
import Gallery from './pages/Gallery'
import Login from './pages/Login'
import NotFound from './pages/NotFound'
import GuestPortal from './pages/GuestPortal'
import AdminLayout from './components/AdminLayout'
import AdminDashboard from './pages/admin/AdminDashboard'
import AdminBookings from './pages/admin/AdminBookings'
import AdminMessages from './pages/admin/AdminMessages'
import AdminCoupons from './pages/admin/AdminCoupons'
import AdminCalendar from './pages/admin/AdminCalendar'
import AdminTasks from './pages/admin/AdminTasks'
import AdminInbox from './pages/admin/AdminInbox'
import AdminRestaurant from './pages/admin/AdminRestaurant'
import AdminStaff from './pages/admin/AdminStaff'
import AdminHousekeeping from './pages/admin/AdminHousekeeping'
import AdminAccounting from './pages/admin/AdminAccounting'
import AdminLoyalty from './pages/admin/AdminLoyalty'
import AdminAutomation from './pages/admin/AdminAutomation'
import AdminReports from './pages/admin/AdminReports'
import AdminBanners from './pages/admin/AdminBanners'
import AdminSettings from './pages/admin/AdminSettings'
import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

function App() {
  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.08, smoothWheel: true })
    lenis.on('scroll', ScrollTrigger.update)
    gsap.ticker.add((time) => { lenis.raf(time * 1000) })
    gsap.ticker.lagSmoothing(0)
    return () => { lenis.destroy() }
  }, [])

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/rooms" element={<Rooms />} />
        <Route path="/dining" element={<Dining />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/portal" element={<GuestPortal />} />
      </Route>
      <Route path="/login" element={<Login />} />
      <Route element={<AdminLayout />}>
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/calendar" element={<AdminCalendar />} />
        <Route path="/admin/bookings" element={<AdminBookings />} />
        <Route path="/admin/messages" element={<AdminMessages />} />
        <Route path="/admin/tasks" element={<AdminTasks />} />
        <Route path="/admin/restaurant" element={<AdminRestaurant />} />
        <Route path="/admin/staff" element={<AdminStaff />} />
        <Route path="/admin/housekeeping" element={<AdminHousekeeping />} />
        <Route path="/admin/accounting" element={<AdminAccounting />} />
        <Route path="/admin/loyalty" element={<AdminLoyalty />} />
        <Route path="/admin/automation" element={<AdminAutomation />} />
        <Route path="/admin/inbox" element={<AdminInbox />} />
        <Route path="/admin/coupons" element={<AdminCoupons />} />
        <Route path="/admin/reports" element={<AdminReports />} />
        <Route path="/admin/banners" element={<AdminBanners />} />
        <Route path="/admin/settings" element={<AdminSettings />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}

export default App
