import { useRef } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useLanguage } from '@/contexts/LanguageContext'

gsap.registerPlugin(ScrollTrigger)

const attractions = [
  {
    name: 'Chitwan National Park',
    nameNp: 'चितवन राष्ट्रिय निकुञ्ज',
    distance: '40 km',
    desc: 'A UNESCO World Heritage Site famous for one-horned rhinoceros, Bengal tigers, and elephant safaris. A must-visit for wildlife enthusiasts.',
    descNp: 'एकसिङ्गे गैंडा, बङ्गाल बाघ र हात्ती सफारी प्रसिद्ध UNESCO विश्व सम्पदा स्थल। वन्यजीव प्रेमीहरूको लागi अवश्य भ्रमण गर्नुपर्ने स्थान।',
    image: '/images/chitwan-park.jpg',
  },
  {
    name: 'Hetauda View Tower',
    nameNp: 'हेटौडा भ्यू टावर',
    distance: '6.7 km',
    desc: 'Panoramic views of Hetauda city and surrounding hills. Perfect for photography and sunset watching.',
    descNp: 'हेटौडा शहर र वरिपरिका पहाडहरूको प्यानोरामिक दृश्य। फोटोग्राफी र सूर्यास्त हेर्नको लागि उत्तम।',
    image: '/images/hetauda-view.jpg',
  },
  {
    name: 'Triveni Dham',
    nameNp: 'त्रिवेणी धाम',
    distance: '5 km',
    desc: 'A sacred religious site and popular pilgrimage destination. Experience spiritual tranquility.',
    descNp: 'एक पवित्र धार्मिक स्थल र लोकप्रिय तीर्थ स्थल। आध्यात्मिक शान्ति अनुभव गर्नुहोस्।',
    image: '/images/triveni-dham.jpg',
  },
  {
    name: 'Shahid Smarak Park',
    nameNp: 'शहीद स्मारक पार्क',
    distance: '4 km',
    desc: 'A beautiful memorial park dedicated to martyrs. Ideal for morning walks and peaceful relaxation.',
    descNp: 'शहीदहरूको लागि समर्पित सुन्दर स्मारक पार्क। बिहानको हिँड्डका र शान्तिपूर्ण आरामको लागि उत्तम।',
    image: '/images/shahid-park.jpg',
  },
]

const NearbyAttractionsSection = () => {
  const { _, isNepali } = useLanguage()
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.attraction-header > *', {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.attraction-header',
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.attraction-card', {
      opacity: 0,
      y: 40,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.attraction-grid',
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} className="bg-cream py-24 lg:py-32">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="attraction-header text-center mb-14">
          <p className="text-xs tracking-[0.12em] font-semibold text-avocado uppercase mb-4">
            {_('exploreHetauda')}
          </p>
          <h2 className="font-display font-semibold text-4xl lg:text-[52px] leading-[1.1] text-avocado-dark">
            {_('discoverBeauty')}
          </h2>
        </div>

        {/* Attractions Grid */}
        <div className="attraction-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-7">
          {attractions.map((attraction) => (
            <div
              key={attraction.name}
              className="attraction-card bg-white rounded-xl overflow-hidden shadow-card hover:-translate-y-1.5 hover:shadow-card-hover transition-all duration-300"
            >
              <div className="aspect-[16/10] overflow-hidden">
                <img
                  src={attraction.image}
                  alt={isNepali ? attraction.nameNp : attraction.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
              </div>
              <div className="p-5">
                <span className="inline-block bg-avocado/10 text-avocado text-[11px] tracking-wider font-medium px-3 py-1 rounded-full mb-3">
                  {attraction.distance}
                </span>
                <h3 className="font-display font-semibold text-lg text-avocado-dark mb-2">
                  {isNepali ? attraction.nameNp : attraction.name}
                </h3>
                <p className="text-sm text-text-muted leading-relaxed">
                  {isNepali ? attraction.descNp : attraction.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default NearbyAttractionsSection
