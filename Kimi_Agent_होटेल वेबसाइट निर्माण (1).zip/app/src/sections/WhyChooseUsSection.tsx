import { useRef } from 'react'
import { Link } from 'react-router-dom'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Flower2, TreePine, MapPin, Utensils, Wifi, Star, Shield, Car, Waves, Heart, Award, Clock } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

gsap.registerPlugin(ScrollTrigger)

const WhyChooseUsSection = () => {
  const { _ } = useLanguage()

  const mainFeatures = [
    {
      icon: Flower2,
      title: _('orchidGarden'),
      desc: _('featureOrchid'),
    },
    {
      icon: TreePine,
      title: _('freshAvocado'),
      desc: _('featureAvocado'),
    },
    {
      icon: MapPin,
      title: _('centralLocation'),
      desc: _('featureLocation'),
    },
    {
      icon: Utensils,
      title: _('multiCuisine'),
      desc: _('featureDining'),
    },
    {
      icon: Wifi,
      title: _('modernAmenities'),
      desc: _('featureAmenities'),
    },
    {
      icon: Star,
      title: _('awardWinning'),
      desc: _('featureService'),
    },
  ]

  const extraFeatures = [
    { icon: Shield, title: '24/7 Security', titleNp: '२४/७ सुरक्षा', desc: 'CCTV surveillance and trained security staff ensure your safety round the clock.', descNp: 'सीसीटিভी निगरानी र प्रशिक्षित सुरक्षाकर्मीले दिनरात सुरक्षा सुनिश्चित गर्छन्।' },
    { icon: Car, title: 'Free Parking', titleNp: 'निःशुल्क पार्किङ', desc: 'Ample secure parking space for cars, buses, and two-wheelers at no extra charge.', descNp: 'कार, बस र दुई पाङ्ग्रेका लागि प्रशस्त सुरक्षित पार्किङ स्थल निःशुल्क।' },
    { icon: Waves, title: 'Hot & Cold Water', titleNp: 'तातो र चिसो पानी', desc: '24-hour hot and cold running water in all rooms with solar backup system.', descNp: 'सबै कोठामा २४-घण्टा तातो र चिसो पानी, सोलर ब्याकअप प्रणालीसहित।' },
    { icon: Heart, title: 'Orchid Spa', titleNp: 'ऑर्किड स्पा', desc: 'Relax and rejuvenate with our traditional Nepali massage and wellness treatments.', descNp: 'पारम्परिक नेपाली मसाज र वेलनेस उपचारसँग आराम र ताजगी पाउनुहोस्।' },
    { icon: Award, title: 'Conference Hall', titleNp: 'कन्फरेन्स हल', desc: 'Fully-equipped conference hall for meetings, seminars, and events up to 100 guests.', descNp: '१०० पाहुनासम्मको बैठक, सेमिनार र कार्यक्रमको लागि पूर्ण सुसज्जित हल।' },
    { icon: Clock, title: '24-Hour Service', titleNp: '२४-घण्टा सेवा', desc: 'Round-the-clock front desk, room service, and concierge at your service.', descNp: 'दिनरात फ्रन्ट डेस्क, रुम सेवा र कन्सियर्ज तपाईंको सेवामा।' },
  ]

  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.why-header > *', {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.why-header',
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.feature-card', {
      opacity: 0,
      y: 40,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.feature-grid',
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.extra-feature-card', {
      opacity: 0,
      y: 30,
      duration: 0.7,
      stagger: 0.1,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.extra-grid',
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.trust-badge', {
      opacity: 0,
      scale: 0.9,
      duration: 0.6,
      stagger: 0.1,
      ease: 'back.out(1.5)',
      scrollTrigger: {
        trigger: '.trust-section',
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} className="bg-cream py-24 lg:py-32">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="why-header text-center mb-16">
          <p className="text-xs tracking-[0.12em] font-semibold text-avocado uppercase mb-4">
            {_('whyChooseUs')}
          </p>
          <h2 className="font-display font-semibold text-4xl lg:text-[52px] leading-[1.1] text-avocado-dark">
            {_('whyTitle')}
          </h2>
        </div>

        {/* Main Feature Grid */}
        <div className="feature-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {mainFeatures.map((feature) => {
            const Icon = feature.icon
            return (
              <div
                key={feature.title}
                className="feature-card bg-white rounded-xl p-8 lg:p-10 shadow-card hover:-translate-y-1 hover:shadow-card-hover transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-full bg-avocado/10 flex items-center justify-center mb-5">
                  <Icon size={23} className="text-avocado" />
                </div>
                <h3 className="font-sans font-semibold text-xl text-avocado-dark mb-3">
                  {feature.title}
                </h3>
                <p className="text-text-muted leading-relaxed">
                  {feature.desc}
                </p>
              </div>
            )
          })}
        </div>

        {/* Additional Features - Compact Cards */}
        <div className="mb-16">
          <h3 className="font-display font-semibold text-2xl text-avocado-dark text-center mb-10">
            More Reasons to Choose Us
          </h3>
          <div className="extra-grid grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-5">
            {extraFeatures.map((f) => {
              const Icon = f.icon
              return (
                <div
                  key={f.title}
                  className="extra-feature-card bg-white rounded-xl p-5 shadow-card hover:-translate-y-1 hover:shadow-card-hover transition-all duration-300 text-center"
                >
                  <div className="w-10 h-10 rounded-full bg-gold/15 flex items-center justify-center mx-auto mb-3">
                    <Icon size={18} className="text-avocado" />
                  </div>
                  <h4 className="font-sans font-semibold text-sm text-avocado-dark mb-1.5">
                    {f.title}
                  </h4>
                  <p className="text-[11px] text-text-muted leading-relaxed">
                    {f.desc}
                  </p>
                </div>
              )
            })}
          </div>
        </div>

        {/* Trust Badges / Certifications */}
        <div className="trust-section bg-white rounded-2xl p-8 lg:p-12 shadow-card">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="trust-badge">
              <div className="font-display font-bold text-4xl text-avocado mb-1">9.6<span className="text-lg text-gold">/10</span></div>
              <p className="text-xs text-text-muted">Hotels.com Rating</p>
              <p className="text-[10px] text-gold mt-0.5">Exceptional</p>
            </div>
            <div className="trust-badge">
              <div className="font-display font-bold text-4xl text-avocado mb-1">8.5<span className="text-lg text-gold">/10</span></div>
              <p className="text-xs text-text-muted">Trip.com Rating</p>
              <p className="text-[10px] text-gold mt-0.5">Very Good</p>
            </div>
            <div className="trust-badge">
              <div className="font-display font-bold text-4xl text-avocado mb-1">58+</div>
              <p className="text-xs text-text-muted">Air-Conditioned Rooms</p>
              <p className="text-[10px] text-gold mt-0.5">All with modern amenities</p>
            </div>
            <div className="trust-badge">
              <div className="font-display font-bold text-4xl text-avocado mb-1">40+</div>
              <p className="text-xs text-text-muted">Years of Excellence</p>
              <p className="text-[10px] text-gold mt-0.5">Since 1980s</p>
            </div>
          </div>

          {/* CTA */}
          <div className="text-center mt-10 pt-8 border-t border-sand/50">
            <p className="text-charcoal mb-5 max-w-[600px] mx-auto">
              Experience the perfect blend of nature, comfort, and Nepali hospitality. Book your stay today and create memories that last a lifetime.
            </p>
            <Link
              to="/rooms"
              className="inline-block px-10 py-4 bg-avocado text-white font-semibold text-sm rounded-full hover:bg-avocado-light transition-all duration-300 shadow-button"
            >
              Explore Our Rooms
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export default WhyChooseUsSection
