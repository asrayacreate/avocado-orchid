import { useRef } from 'react'
import { Link } from 'react-router-dom'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { Star, Calendar, Users, ChevronDown } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import HeroSlideshow from '@/components/HeroSlideshow'

const HeroSection = () => {
  const { _ } = useLanguage()
  const heroRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!heroRef.current) return

    // Entrance animations
    const tl = gsap.timeline({ delay: 0.3 })
    tl.from('.hero-tagline', { opacity: 0, y: 20, duration: 0.8, ease: 'power3.out' })
      .from('.hero-headline', { opacity: 0, y: 30, duration: 0.9, ease: 'power3.out' }, '-=0.5')
      .from('.hero-sub', { opacity: 0, y: 20, duration: 0.8, ease: 'power3.out' }, '-=0.5')
      .from('.hero-ctas', { opacity: 0, y: 20, duration: 0.8, ease: 'power3.out' }, '-=0.4')
      .from('.hero-rating', { opacity: 0, x: -20, duration: 0.8, ease: 'power3.out' }, '-=0.3')
      .from('.hero-booking', { opacity: 0, y: 30, duration: 0.8, ease: 'power3.out' }, '-=0.3')
      .from('.hero-scroll', { opacity: 0, duration: 0.6 }, '-=0.2')
  }, { scope: heroRef })

  return (
    <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden group">
      {/* Background Slideshow - Auto-rotating resort & room images */}
      <HeroSlideshow />

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-[900px] mx-auto pt-20 pb-40">
        <p className="hero-tagline text-xs tracking-[0.2em] font-semibold text-gold uppercase mb-6">
          {_('heroTagline')}
        </p>

        <h1 className="hero-headline font-display font-bold text-5xl sm:text-6xl lg:text-7xl text-white leading-[1.05] mb-6 drop-shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
          {_('heroTitle')}
        </h1>

        <p className="hero-sub text-lg text-white/85 max-w-[640px] mx-auto mb-10 leading-relaxed">
          {_('heroSubtitle')}
        </p>

        <div className="hero-ctas flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/rooms"
            className="px-10 py-4 bg-gold text-forest font-semibold text-sm tracking-wide rounded-full hover:bg-gold-light hover:-translate-y-1 transition-all duration-300 shadow-button"
          >
            {_('bookYourStay')}
          </Link>
          <Link
            to="/rooms"
            className="px-10 py-4 border-[1.5px] border-white/50 text-white font-semibold text-sm tracking-wide rounded-full hover:border-gold hover:text-gold transition-all duration-300"
          >
            {_('exploreRooms')}
          </Link>
        </div>
      </div>

      {/* Rating Badge */}
      <div className="hero-rating absolute bottom-32 left-6 lg:left-10 z-10">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl px-5 py-4 border border-white/10">
          <div className="flex items-center gap-1.5 mb-1.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={14} className="fill-gold text-gold" />
            ))}
          </div>
          <div className="font-display font-bold text-2xl text-white">9.6/10</div>
          <div className="text-[10px] tracking-wider text-white/60 uppercase">{_('ratingLabel')}</div>
        </div>
      </div>

      {/* Booking Bar */}
      <div className="hero-booking absolute bottom-0 left-0 right-0 z-10">
        <div className="bg-white/[0.08] backdrop-blur-xl border-t border-white/10 px-6 lg:px-10 py-5">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              const form = e.currentTarget
              const checkIn = (form.elements.namedItem('checkin') as HTMLInputElement)?.value
              const checkOut = (form.elements.namedItem('checkout') as HTMLInputElement)?.value
              const guests = (form.elements.namedItem('guests') as HTMLSelectElement)?.value
              window.open(
                `https://avocadoresort.com/result.php?hotel_code=U3q5qz&check_in=${checkIn}&check_out=${checkOut}&adults=${guests}`,
                '_blank'
              )
            }}
            className="max-w-[1280px] mx-auto flex flex-col sm:flex-row items-center gap-4"
          >
            <div className="flex-1 w-full sm:w-auto grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="relative">
                <Calendar size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/50" />
                <input
                  name="checkin"
                  type="date"
                  className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white text-sm placeholder:text-white/50 focus:outline-none focus:border-gold"
                  required
                />
              </div>
              <div className="relative">
                <Calendar size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/50" />
                <input
                  name="checkout"
                  type="date"
                  className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white text-sm placeholder:text-white/50 focus:outline-none focus:border-gold"
                  required
                />
              </div>
              <div className="relative">
                <Users size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/50" />
                <select
                  name="guests"
                  className="w-full pl-10 pr-8 py-3 bg-white/10 border border-white/20 rounded-lg text-white text-sm appearance-none focus:outline-none focus:border-gold"
                >
                  <option value="2" className="text-forest">{_('guest2')}</option>
                  <option value="1" className="text-forest">{_('guest1')}</option>
                  <option value="3" className="text-forest">{_('guest3')}</option>
                  <option value="4" className="text-forest">{_('guest4')}</option>
                </select>
              </div>
            </div>
            <button
              type="submit"
              className="w-full sm:w-auto px-8 py-3 bg-gold text-forest font-semibold text-sm rounded-lg hover:bg-gold-light transition-colors whitespace-nowrap"
            >
              {_('checkAvailability')}
            </button>
          </form>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="hero-scroll absolute bottom-36 sm:bottom-36 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center">
        <div className="w-px h-10 bg-white/40 relative overflow-hidden">
          <div className="w-2 h-2 rounded-full bg-white absolute left-1/2 -translate-x-1/2 animate-scroll-indicator" />
        </div>
        <ChevronDown size={14} className="text-white/40 mt-1" />
      </div>
    </section>
  )
}

export default HeroSection
