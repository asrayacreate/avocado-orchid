import { useRef } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useLanguage } from '@/contexts/LanguageContext'

gsap.registerPlugin(ScrollTrigger)

const AboutSection = () => {
  const { _ } = useLanguage()
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.about-text > *', {
      opacity: 0,
      y: 40,
      duration: 0.8,
      stagger: 0.15,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.about-image', {
      opacity: 0,
      x: 60,
      scale: 0.95,
      duration: 1,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 75%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.about-badge', {
      opacity: 0,
      scale: 0,
      duration: 0.6,
      delay: 0.4,
      ease: 'back.out(1.7)',
      scrollTrigger: {
        trigger: '.about-image',
        start: 'top 70%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} id="about" className="bg-cream py-24 lg:py-32">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-[55%_45%] gap-12 lg:gap-16 items-center">
          {/* Left Column - Text */}
          <div className="about-text space-y-6">
            <p className="text-xs tracking-[0.12em] font-semibold text-avocado uppercase">
              {_('welcomeLabel')}
            </p>
            <h2 className="font-display font-semibold text-4xl lg:text-[52px] leading-[1.1] text-avocado-dark">
              {_('aboutTitle')}
            </h2>
            <p className="text-lg text-charcoal leading-relaxed">
              {_('aboutDesc')}
            </p>

            {/* Highlight Box */}
            <div className="bg-orchid/[0.06] border-l-[3px] border-orchid pl-6 py-5 pr-5 rounded-r-xl">
              <p className="text-avocado-dark italic">
                &ldquo;{_('aboutHighlight')}&rdquo;
              </p>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-4">
              <div>
                <div className="font-display font-bold text-4xl text-avocado">58</div>
                <div className="text-xs tracking-wider text-text-muted uppercase mt-1">{_('luxuryRooms')}</div>
              </div>
              <div>
                <div className="font-display font-bold text-4xl text-gold">9.6</div>
                <div className="text-xs tracking-wider text-text-muted uppercase mt-1">{_('guestRating')}</div>
              </div>
              <div>
                <div className="font-display font-bold text-4xl text-avocado">40+</div>
                <div className="text-xs tracking-wider text-text-muted uppercase mt-1">{_('yearsOfService')}</div>
              </div>
            </div>
          </div>

          {/* Right Column - Image */}
          <div className="relative">
            <div className="about-image">
              <img
                src="/images/hero-exterior-day.jpg"
                alt="Avocado & Orchid Resort exterior"
                className="rounded-2xl shadow-image w-full aspect-[4/5] object-cover lg:-mt-10"
                loading="lazy"
              />
            </div>
            {/* Floating Badge */}
            <div className="about-badge absolute -bottom-6 -left-6 w-36 h-36 lg:w-40 lg:h-40 rounded-full overflow-hidden border-4 border-cream shadow-card">
              <img
                src="/images/orchid-garden.jpg"
                alt="Orchid Garden"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default AboutSection
