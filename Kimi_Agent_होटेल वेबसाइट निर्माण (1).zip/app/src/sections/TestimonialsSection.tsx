import { useState, useEffect, useRef, useCallback } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Star, ChevronLeft, ChevronRight } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

gsap.registerPlugin(ScrollTrigger)

const reviews = [
  {
    quote: 'The room is clean. The surrounding is quiet and full of Avocado trees. This was my third times staying in this hotel.',
    name: 'Anonymous',
    location: 'Nepal',
  },
  {
    quote: 'The hotel as it should be: clean rooms, great food, superb service, and they even make real coffee — latte, cappuccino, and so on. I will definitely stay there again!',
    name: 'Pablo',
    location: 'Russia',
  },
  {
    quote: 'Staff super friendly. Room and bathroom is clean and bed is comfortable. The garden has some beautiful trees. The food at the restaurant is delicious.',
    name: 'Gieg',
    location: 'Portugal',
  },
  {
    quote: 'My very favourite place in Hetauda. The hotel offers a very wide range of rooms and your stay will be extremely comfortable.',
    name: 'Stomio H',
    location: 'Athens, Greece',
  },
  {
    quote: 'Everything was good. Great location, comfortable rooms, and the orchid garden is simply beautiful. A hidden gem in Hetauda.',
    name: 'Kapka',
    location: 'Thailand',
  },
]

const TestimonialsSection = () => {
  const { _ } = useLanguage()
  const [current, setCurrent] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const next = useCallback(() => {
    setCurrent((prev) => (prev + 1) % reviews.length)
  }, [])

  const prev = () => {
    setCurrent((p) => (p - 1 + reviews.length) % reviews.length)
  }

  useEffect(() => {
    if (!isPaused) {
      timerRef.current = setInterval(next, 5000)
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [isPaused, next])

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.testimonial-header > *', {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.testimonial-header',
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} className="bg-forest py-24 lg:py-36">
      <div className="max-w-[1100px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="testimonial-header text-center mb-14">
          <p className="text-xs tracking-[0.12em] font-semibold text-gold uppercase mb-4">
            {_('guestReviews')}
          </p>
          <h2 className="font-display font-semibold text-4xl lg:text-[52px] text-white leading-[1.1] mb-4">
            {_('whatGuestsSay')}
          </h2>
          <div className="flex items-center justify-center gap-1.5 mb-2">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={18} className="fill-gold text-gold" />
            ))}
          </div>
          <p className="text-lg text-white/80">{_('ratedExceptional')}</p>
        </div>

        {/* Carousel */}
        <div
          className="relative"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${current * 100}%)` }}
            >
              {reviews.map((review, i) => (
                <div
                  key={i}
                  className="w-full flex-shrink-0 px-0 md:px-16"
                >
                  <div className="bg-white/[0.05] border border-white/[0.08] rounded-xl p-8 lg:p-10 text-center">
                    <div className="font-display text-6xl text-gold/15 mb-4 leading-none">&ldquo;</div>
                    <p className="text-lg text-white/85 italic leading-relaxed mb-6 max-w-[700px] mx-auto">
                      {review.quote}
                    </p>
                    <div className="w-10 h-px bg-gold mx-auto mb-5" />
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center mb-2">
                        <span className="font-display font-semibold text-gold text-lg">
                          {review.name.charAt(0)}
                        </span>
                      </div>
                      <div className="font-sans font-semibold text-white">{review.name}</div>
                      <div className="text-xs text-white/50 tracking-wider">{review.location}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white hover:border-gold hover:text-gold transition-colors hidden md:flex"
          >
            <ChevronLeft size={18} />
          </button>
          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white hover:border-gold hover:text-gold transition-colors hidden md:flex"
          >
            <ChevronRight size={18} />
          </button>

          {/* Dots */}
          <div className="flex items-center justify-center gap-2 mt-8">
            {reviews.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-2.5 h-2.5 rounded-full transition-colors ${
                  i === current ? 'bg-gold' : 'bg-white/20'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default TestimonialsSection
