import { useState, useRef } from 'react'
import { Link } from 'react-router-dom'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useLanguage } from '@/contexts/LanguageContext'
import Lightbox from '../components/Lightbox'

gsap.registerPlugin(ScrollTrigger)

const galleryImages = [
  { src: '/images/hero-exterior-night.jpg', alt: 'Hotel exterior at night', span: 'col-span-2 row-span-2' },
  { src: '/images/room-super-deluxe.jpg', alt: 'Super Deluxe Room', span: 'col-span-1 row-span-1' },
  { src: '/images/restaurant-dining.jpg', alt: 'Restaurant dining', span: 'col-span-1 row-span-1' },
  { src: '/images/orchid-garden.jpg', alt: 'Orchid Garden', span: 'col-span-1 row-span-1' },
  { src: '/images/hotel-lobby.jpg', alt: 'Hotel Lobby', span: 'col-span-1 row-span-1' },
  { src: '/images/hero-exterior-day.jpg', alt: 'Hotel panoramic view', span: 'col-span-2 md:col-span-4 row-span-1' },
]

const GallerySection = () => {
  const { _ } = useLanguage()
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const [currentImage, setCurrentImage] = useState(0)
  const sectionRef = useRef<HTMLDivElement>(null)

  const openLightbox = (index: number) => {
    setCurrentImage(index)
    setLightboxOpen(true)
  }

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.gallery-header > *', {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.gallery-header',
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.gallery-item', {
      opacity: 0,
      scale: 0.9,
      duration: 0.6,
      stagger: 0.08,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.gallery-grid',
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} className="bg-white py-24 lg:py-32">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="gallery-header text-center mb-12">
          <p className="text-xs tracking-[0.12em] font-semibold text-avocado uppercase mb-4">
            {_('galleryLabel')}
          </p>
          <h2 className="font-display font-semibold text-4xl lg:text-[52px] leading-[1.1] text-avocado-dark">
            {_('galleryTitle')}
          </h2>
        </div>

        {/* Gallery Grid */}
        <div className="gallery-grid grid grid-cols-2 md:grid-cols-4 gap-4">
          {galleryImages.map((img, i) => (
            <div
              key={i}
              className={`gallery-item relative overflow-hidden rounded-lg cursor-pointer group ${img.span}`}
              onClick={() => openLightbox(i)}
            >
              <img
                src={img.src}
                alt={img.alt}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-avocado/0 group-hover:bg-avocado/30 transition-colors duration-300 flex items-center justify-center">
                <span className="text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  {_('view')}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* View All */}
        <div className="text-center mt-10">
          <Link
            to="/gallery"
            className="inline-block px-9 py-3.5 border-[1.5px] border-avocado text-avocado font-semibold text-sm rounded-full hover:bg-avocado hover:text-white transition-all duration-300"
          >
            {_('viewFullGallery')}
          </Link>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && (
        <Lightbox
          images={galleryImages}
          currentIndex={currentImage}
          onClose={() => setLightboxOpen(false)}
          onNavigate={setCurrentImage}
        />
      )}
    </section>
  )
}

export default GallerySection
