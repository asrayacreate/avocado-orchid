import { useRef } from 'react'
import { Link } from 'react-router-dom'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Utensils, Coffee, Wine } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

gsap.registerPlugin(ScrollTrigger)

const DiningSection = () => {
  const { _ } = useLanguage()
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.dining-image', {
      opacity: 0,
      x: -60,
      duration: 1,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 75%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.dining-card', {
      opacity: 0,
      y: 30,
      duration: 0.6,
      delay: 0.5,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.dining-image',
        start: 'top 70%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.dining-content > *', {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.dining-content',
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} className="bg-cream-dark py-24 lg:py-36">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left - Image */}
          <div className="relative">
            <div className="dining-image">
              <img
                src="/images/food-platter.jpg"
                alt="Avocado Restaurant dining"
                className="rounded-2xl shadow-image w-full aspect-[4/3] object-cover"
                loading="lazy"
              />
            </div>
            {/* Floating Card */}
            <div className="dining-card absolute -bottom-6 -right-2 lg:right-6 bg-white rounded-xl p-5 shadow-card max-w-[240px]">
              <h4 className="font-sans font-semibold text-base text-avocado-dark mb-1.5">{_('avocadoRestaurant')}</h4>
              <p className="text-xs text-text-muted mb-2">{_('openDaily')}</p>
              <p className="text-[11px] tracking-wider text-avocado uppercase">{_('cuisines')}</p>
            </div>
          </div>

          {/* Right - Content */}
          <div className="dining-content space-y-5 pt-8 lg:pt-0">
            <p className="text-xs tracking-[0.12em] font-semibold text-avocado uppercase">
              {_('diningLabel')}
            </p>
            <h2 className="font-display font-semibold text-4xl lg:text-[52px] leading-[1.1] text-avocado-dark">
              {_('diningTitle')}
            </h2>
            <p className="text-lg text-charcoal leading-relaxed">
              {_('diningDesc')}
            </p>

            {/* Dining Options */}
            <div className="space-y-4 pt-2">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center shrink-0">
                  <Utensils size={18} className="text-avocado" />
                </div>
                <div>
                  <h4 className="font-sans font-semibold text-base text-avocado-dark">{_('avocadoRestaurant')}</h4>
                  <p className="text-sm text-text-muted">{_('restaurantDesc')}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center shrink-0">
                  <Coffee size={18} className="text-avocado" />
                </div>
                <div>
                  <h4 className="font-sans font-semibold text-base text-avocado-dark">{_('crustCafe')}</h4>
                  <p className="text-sm text-text-muted">{_('cafeDesc')}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-avocado/10 flex items-center justify-center shrink-0">
                  <Wine size={18} className="text-avocado" />
                </div>
                <div>
                  <h4 className="font-sans font-semibold text-base text-avocado-dark">{_('barLounge')}</h4>
                  <p className="text-sm text-text-muted">{_('barDesc')}</p>
                </div>
              </div>
            </div>

            {/* Quote */}
            <blockquote className="border-l-[3px] border-orchid pl-5 py-1">
              <p className="text-orchid italic">&ldquo;{_('diningQuote')}&rdquo;</p>
              <cite className="text-xs text-text-muted not-italic mt-2 block">{_('diningQuoteAuthor')}</cite>
            </blockquote>

            <Link
              to="/dining"
              className="inline-block px-8 py-3.5 bg-avocado text-white font-semibold text-sm rounded-full hover:bg-avocado-light transition-all duration-300 shadow-button"
            >
              {_('exploreMenu')}
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export default DiningSection
