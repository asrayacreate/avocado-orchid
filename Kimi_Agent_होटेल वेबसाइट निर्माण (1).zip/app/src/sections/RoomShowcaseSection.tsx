import { useRef } from 'react'
import { Link } from 'react-router-dom'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Users, Maximize, Wind } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

gsap.registerPlugin(ScrollTrigger)

const rooms = [
  {
    name: 'Deluxe A/C',
    guests: '2-3',
    size: '251',
    desc: 'Comfortable room with twin and double bed options, perfect for families or small groups.',
    descNp: 'ट्विन र डबल बेड विकल्पहरू भएको आरामदायक कोठा, परिवार वा सानो समूहको लागि उत्तम।',
    price: '3,500',
    image: '/images/room-deluxe.jpg',
  },
  {
    name: 'Super Deluxe A/C',
    guests: '2',
    size: '287',
    desc: 'Spacious room with premium furnishings and garden views for a relaxing stay.',
    descNp: 'प्रीमियम फर्निसिङ र बगैंचा दृश्य भएको विशाल कोठा, आरामदायक बसाइको लागि।',
    price: '4,500',
    image: '/images/room-super-deluxe.jpg',
  },
  {
    name: 'Semi Suite',
    guests: '2',
    size: '287',
    desc: 'Elegant semi-suite with separate seating area and enhanced amenities.',
    descNp: 'छुट्टै बस्ने क्षेत्र र उन्नत सुविधाहरू भएको सुन्दर सेमी-सुइट।',
    price: '5,500',
    image: '/images/room-semi-suite.jpg',
  },
  {
    name: 'Suite',
    guests: '2-4',
    size: '538',
    desc: 'Our largest suite with double bed, single beds, minibar, and refrigerator.',
    descNp: 'हाम्रो सबैभन्दा ठूलो सुइट जसमा डबल बेड, सिंगल बेड, मिनिबार र रेफ्रिजरेटर छ।',
    price: '7,500',
    image: '/images/room-suite.jpg',
  },
]

const RoomShowcaseSection = () => {
  const { _, isNepali } = useLanguage()
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.room-header > *', {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.room-header',
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.room-card', {
      opacity: 0,
      y: 60,
      duration: 0.8,
      stagger: 0.15,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.room-grid',
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} className="bg-forest py-24 lg:py-36">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="room-header text-center mb-16">
          <p className="text-xs tracking-[0.12em] font-semibold text-gold uppercase mb-4">
            {_('ourAccommodations')}
          </p>
          <h2 className="font-display font-semibold text-4xl lg:text-[52px] text-white leading-[1.1] mb-5">
            {_('roomsTitle')}
          </h2>
          <p className="text-lg text-white/60 max-w-[600px] mx-auto">
            {_('roomsSubtitle')}
          </p>
        </div>

        {/* Room Cards Grid */}
        <div className="room-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-7">
          {rooms.map((room) => (
            <div
              key={room.name}
              className="room-card bg-white/[0.05] border border-white/[0.08] rounded-xl overflow-hidden hover:-translate-y-2 hover:border-gold/30 hover:shadow-[0_20px_60px_rgba(0,0,0,0.3)] transition-all duration-300"
            >
              {/* Image */}
              <div className="aspect-[16/10] overflow-hidden">
                <img
                  src={room.image}
                  alt={room.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
              </div>
              {/* Content */}
              <div className="p-6">
                <h3 className="font-display font-semibold text-xl text-white mb-3">{room.name}</h3>
                <div className="flex flex-wrap gap-3 mb-3">
                  <span className="flex items-center gap-1 text-xs text-white/50">
                    <Users size={13} /> {room.guests} {_('guests')}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-white/50">
                    <Maximize size={13} /> {room.size} {_('sqFt')}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-white/50">
                    <Wind size={13} /> A/C
                  </span>
                </div>
                <p className="text-sm text-white/50 mb-4 line-clamp-2">{isNepali ? room.descNp : room.desc}</p>
                <div className="flex items-end justify-between">
                  <div>
                    <span className="text-[11px] text-white/40 uppercase tracking-wider">{_('from')}</span>
                    <div className="font-display font-bold text-3xl text-gold">NPR {room.price}</div>
                    <span className="text-[11px] text-white/40">{_('perNight')}</span>
                  </div>
                  <Link
                    to="/rooms"
                    className="text-sm font-semibold text-avocado-light hover:text-white transition-colors"
                  >
                    {_('viewDetails')} &rarr;
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <Link
            to="/rooms"
            className="inline-block px-9 py-3.5 border-[1.5px] border-gold text-gold font-semibold text-sm rounded-full hover:bg-gold hover:text-forest transition-all duration-300"
          >
            {_('viewAllRooms')}
          </Link>
        </div>
      </div>
    </section>
  )
}

export default RoomShowcaseSection
