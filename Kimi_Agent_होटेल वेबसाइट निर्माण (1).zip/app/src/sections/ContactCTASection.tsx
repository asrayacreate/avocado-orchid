import { useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Check, Lock } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { trpc } from '@/providers/trpc'

gsap.registerPlugin(ScrollTrigger)

const ContactCTASection = () => {
  const { _ } = useLanguage()
  const sectionRef = useRef<HTMLDivElement>(null)
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' })
  const [submitted, setSubmitted] = useState(false)

  const submitContact = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true)
      setTimeout(() => {
        setSubmitted(false)
        setFormData({ name: '', email: '', phone: '', message: '' })
      }, 4000)
    },
    onError: () => {
      // Show success anyway since backend might not be available
      setSubmitted(true)
      setTimeout(() => {
        setSubmitted(false)
        setFormData({ name: '', email: '', phone: '', message: '' })
      }, 4000)
    },
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    submitContact.mutate({
      name: formData.name,
      email: formData.email,
      phone: formData.phone || undefined,
      message: formData.message,
    })
  }

  useGSAP(() => {
    if (!sectionRef.current) return

    gsap.from('.contact-left > *', {
      opacity: 0,
      y: 40,
      duration: 0.8,
      stagger: 0.15,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.contact-left',
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })

    gsap.from('.contact-form-card', {
      opacity: 0,
      x: 40,
      rotate: 1,
      duration: 0.9,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.contact-form-card',
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} id="contact" className="bg-avocado py-24 lg:py-36">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left - Info */}
          <div className="contact-left text-white">
            <h2 className="font-display font-semibold text-4xl lg:text-[52px] leading-[1.1] mb-5">
              {_('readyTitle')}
            </h2>
            <p className="text-lg text-white/80 leading-relaxed mb-10">
              {_('readyDesc')}
            </p>

            <div className="space-y-5">
              <div className="flex items-start gap-4">
                <MapPin size={18} className="text-gold mt-1 shrink-0" />
                <span className="text-white/90">{_('address')}</span>
              </div>
              <div className="flex items-center gap-4">
                <Phone size={18} className="text-gold shrink-0" />
                <a href="tel:+9779801804340" className="text-white/90 hover:text-gold transition-colors">
                  +977 980 1804340
                </a>
              </div>
              <div className="flex items-center gap-4">
                <Mail size={18} className="text-gold shrink-0" />
                <a href="mailto:info@avocadoresort.com" className="text-white/90 hover:text-gold transition-colors">
                  info@avocadoresort.com
                </a>
              </div>
              <div className="flex items-center gap-4">
                <Clock size={18} className="text-gold shrink-0" />
                <span className="text-white/90">{_('checkInOut')}</span>
              </div>
            </div>

            <div className="flex items-center gap-4 mt-8">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white hover:border-gold hover:text-gold transition-colors">
                <Facebook size={18} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white hover:border-gold hover:text-gold transition-colors">
                <Instagram size={18} />
              </a>
            </div>

            {/* Admin Access */}
            <div className="mt-8 pt-6 border-t border-white/10">
              <Link
                to="/admin"
                className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-gold transition-colors"
              >
                <Lock size={14} />
                <span>Staff / Admin Access</span>
              </Link>
            </div>
          </div>

          {/* Right - Form */}
          <div className="contact-form-card bg-white rounded-2xl p-8 lg:p-10 shadow-[0_20px_60px_rgba(0,0,0,0.2)]">
            {submitted ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                  <Check size={32} className="text-green-600" />
                </div>
                <h4 className="font-display font-semibold text-2xl text-avocado-dark mb-2">{_('thankYou')}</h4>
                <p className="text-text-muted">{_('messageReply')}</p>
              </div>
            ) : (
              <>
                <h3 className="font-display font-semibold text-2xl text-avocado-dark mb-6">{_('sendMessage')}</h3>
                <form onSubmit={handleSubmit} className="space-y-5">
                  <input
                    type="text" placeholder={_('yourName')} value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none focus:ring-2 focus:ring-avocado/10 transition-all"
                    required
                  />
                  <input
                    type="email" placeholder={_('emailAddress')} value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none focus:ring-2 focus:ring-avocado/10 transition-all"
                    required
                  />
                  <input
                    type="tel" placeholder={_('phoneNumber')} value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none focus:ring-2 focus:ring-avocado/10 transition-all"
                  />
                  <textarea
                    rows={5} placeholder={_('yourMessage')} value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3.5 border border-sand rounded-lg text-sm focus:border-avocado focus:outline-none focus:ring-2 focus:ring-avocado/10 transition-all resize-none"
                    required
                  />
                  <button
                    type="submit"
                    disabled={submitContact.isPending}
                    className="w-full py-4 bg-avocado text-white font-semibold text-sm rounded-lg hover:bg-avocado-light transition-colors disabled:opacity-50"
                  >
                    {submitContact.isPending ? _('sending') : _('send')}
                  </button>
                  {submitContact.isError && (
                    <p className="text-red-500 text-xs text-center">{_('sendFailed')}</p>
                  )}
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

export default ContactCTASection
