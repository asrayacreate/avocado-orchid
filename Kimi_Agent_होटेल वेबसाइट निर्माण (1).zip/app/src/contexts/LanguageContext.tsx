import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react'
import type { Lang, TranslationKey } from '@/translations'
import { t } from '@/translations'

interface LanguageContextType {
  lang: Lang
  setLang: (lang: Lang) => void
  toggleLang: () => void
  _: (key: TranslationKey) => string
  isNepali: boolean
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('hotel-lang') as Lang) || 'en'
    }
    return 'en'
  })

  const setLang = useCallback((newLang: Lang) => {
    setLangState(newLang)
    localStorage.setItem('hotel-lang', newLang)
    document.documentElement.lang = newLang === 'np' ? 'ne' : 'en'
  }, [])

  const toggleLang = useCallback(() => {
    setLang(prev => prev === 'en' ? 'np' : 'en')
  }, [setLang])

  useEffect(() => {
    document.documentElement.lang = lang === 'np' ? 'ne' : 'en'
  }, [lang])

  const _ = useCallback((key: TranslationKey) => t(key, lang), [lang])

  const value: LanguageContextType = {
    lang,
    setLang,
    toggleLang,
    _,
    isNepali: lang === 'np',
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) throw new Error('useLanguage must be used within LanguageProvider')
  return context
}
