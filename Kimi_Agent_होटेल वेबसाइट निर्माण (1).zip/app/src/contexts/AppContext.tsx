import { createContext, useContext, useState, useCallback, type ReactNode } from 'react'

// ─── Types ───────────────────────────────────────────────
export interface Booking {
  id: number
  guestName: string
  guestEmail: string
  guestPhone: string
  checkIn: string
  checkOut: string
  adults: number
  children: number
  totalNights: number
  totalAmount: number
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed'
  paymentStatus: 'Pending' | 'Paid' | 'Failed'
  paymentMethod: string | null
  roomName: string
  createdAt: string
}

export interface Message {
  id: number
  name: string
  email: string
  phone?: string
  message: string
  isRead: 'unread' | 'read'
  createdAt: string
}

export interface StaffMember {
  id: number
  name: string
  role: string
  department: string
  phone: string
  status: 'active' | 'on-leave' | 'inactive'
  joined: string
}

export interface Task {
  id: number
  title: string
  type: 'cleaning' | 'maintenance' | 'inspection'
  priority: 'high' | 'medium' | 'low'
  status: 'pending' | 'in-progress' | 'completed'
  roomNumber: string | null
  assignedTo: string
  dueDate: string
}

export interface RoomUnit {
  id: number
  name: string
  number: string
  floor: number
  price: number
  status: 'clean' | 'occupied' | 'cleaning' | 'repairing' | 'dirty'
}

export interface Order {
  id: number
  roomNumber: string | null
  guestName: string
  items: string
  total: number
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled'
  type: 'room-service' | 'restaurant' | 'cafe' | 'banquet'
  createdAt: string
}

export interface Expense {
  id: number
  title: string
  category: string
  amount: number
  date: string
  paidTo: string
}

export interface Coupon {
  id: number
  code: string
  discount: number
  type: 'percentage' | 'fixed'
  maxUses: number
  used: number
  expires: string
  status: 'active' | 'scheduled' | 'expired'
}

export interface AutomationRule {
  id: number
  name: string
  trigger: string
  status: 'active' | 'paused'
  desc: string
}

// ─── Initial Mock Data ───────────────────────────────────
const initialBookings: Booking[] = [
  { id: 1001, guestName: 'Ram Sharma', guestEmail: 'ram@email.com', guestPhone: '+977 9801234567', checkIn: '2025-06-15', checkOut: '2025-06-18', adults: 2, children: 1, totalNights: 3, totalAmount: 10500, status: 'confirmed', paymentStatus: 'Paid', paymentMethod: 'Khalti', roomName: 'Super Deluxe A/C', createdAt: '2025-06-01T10:30:00' },
  { id: 1002, guestName: 'Sita Devi', guestEmail: 'sita@email.com', guestPhone: '+977 9812345678', checkIn: '2025-06-20', checkOut: '2025-06-22', adults: 2, children: 0, totalNights: 2, totalAmount: 7000, status: 'pending', paymentStatus: 'Pending', paymentMethod: null, roomName: 'Deluxe A/C', createdAt: '2025-06-02T14:15:00' },
  { id: 1003, guestName: 'Pablo Morales', guestEmail: 'pablo@email.com', guestPhone: '+7 9998887776', checkIn: '2025-06-25', checkOut: '2025-06-28', adults: 2, children: 2, totalNights: 3, totalAmount: 22500, status: 'confirmed', paymentStatus: 'Paid', paymentMethod: 'eSewa', roomName: 'Suite', createdAt: '2025-06-03T09:00:00' },
  { id: 1004, guestName: 'John Smith', guestEmail: 'john@email.com', guestPhone: '+1 5554443333', checkIn: '2025-07-01', checkOut: '2025-07-05', adults: 2, children: 0, totalNights: 4, totalAmount: 18000, status: 'confirmed', paymentStatus: 'Paid', paymentMethod: 'Stripe', roomName: 'Semi Suite', createdAt: '2025-06-04T16:45:00' },
  { id: 1005, guestName: 'Anita Gurung', guestEmail: 'anita@email.com', guestPhone: '+977 9823456789', checkIn: '2025-07-10', checkOut: '2025-07-12', adults: 3, children: 0, totalNights: 2, totalAmount: 7000, status: 'pending', paymentStatus: 'Pending', paymentMethod: null, roomName: 'Deluxe A/C', createdAt: '2025-06-05T11:20:00' },
  { id: 1006, guestName: 'David Chen', guestEmail: 'david@email.com', guestPhone: '+86 13800138000', checkIn: '2025-07-15', checkOut: '2025-07-18', adults: 2, children: 1, totalNights: 3, totalAmount: 13500, status: 'confirmed', paymentStatus: 'Paid', paymentMethod: 'Khalti', roomName: 'Super Deluxe A/C', createdAt: '2025-06-06T08:30:00' },
]

const initialMessages: Message[] = [
  { id: 1, name: 'Ram Sharma', email: 'ram@email.com', phone: '+977 9801234567', message: 'Do you provide airport pickup service from Kathmandu?', isRead: 'unread', createdAt: '2025-06-08T10:30:00' },
  { id: 2, name: 'Pablo Morales', email: 'pablo@email.com', message: 'Thank you for the wonderful stay! The orchid garden was breathtaking. Will definitely come back next year.', isRead: 'read', createdAt: '2025-06-07T14:15:00' },
  { id: 3, name: 'Sita Devi', email: 'sita@email.com', phone: '+977 9812345678', message: 'Can I get a room with orchid garden view? Also, do you have wheelchair accessibility?', isRead: 'unread', createdAt: '2025-06-06T09:45:00' },
  { id: 4, name: 'John Smith', email: 'john@email.com', message: 'Is there a conference hall available for 50 people? We need it for 2 days with projector and Wi-Fi.', isRead: 'read', createdAt: '2025-06-05T16:20:00' },
  { id: 5, name: 'Priya Patel', email: 'priya@email.com', phone: '+91 9876543210', message: 'We are a group of 15 people visiting in July. Can you arrange a group discount and package?', isRead: 'unread', createdAt: '2025-06-04T11:00:00' },
]

const initialStaff: StaffMember[] = [
  { id: 1, name: 'Hari Bahadur', role: 'Manager', department: 'Front Desk', phone: '+977 9801112222', status: 'active', joined: '2018-03-15' },
  { id: 2, name: 'Gita Kumari', role: 'Receptionist', department: 'Front Desk', phone: '+977 9802223333', status: 'active', joined: '2020-06-01' },
  { id: 3, name: 'Ram Prasad', role: 'Head Chef', department: 'Kitchen', phone: '+977 9803334444', status: 'active', joined: '2019-01-10' },
  { id: 4, name: 'Sunita Devi', role: 'Housekeeping', department: 'Housekeeping', phone: '+977 9804445555', status: 'active', joined: '2021-04-20' },
  { id: 5, name: 'Bikash Thapa', role: 'Security', department: 'Security', phone: '+977 9805556666', status: 'on-leave', joined: '2020-09-05' },
  { id: 6, name: 'Maya Gurung', role: 'Waitress', department: 'Restaurant', phone: '+977 9806667777', status: 'active', joined: '2022-02-14' },
]

const initialTasks: Task[] = [
  { id: 1, title: 'Clean Room 101', type: 'cleaning', priority: 'high', status: 'pending', roomNumber: '101', assignedTo: 'Sunita Devi', dueDate: '2025-06-08' },
  { id: 2, title: 'Fix AC in Room 205', type: 'maintenance', priority: 'high', status: 'in-progress', roomNumber: '205', assignedTo: 'Ram Prasad', dueDate: '2025-06-08' },
  { id: 3, title: 'Garden watering', type: 'maintenance', priority: 'low', status: 'completed', roomNumber: null, assignedTo: 'Bikash Thapa', dueDate: '2025-06-07' },
  { id: 4, title: 'Inspect Room 302', type: 'inspection', priority: 'medium', status: 'pending', roomNumber: '302', assignedTo: 'Hari Bahadur', dueDate: '2025-06-09' },
  { id: 5, title: 'Restaurant deep clean', type: 'cleaning', priority: 'medium', status: 'in-progress', roomNumber: null, assignedTo: 'Sunita Devi', dueDate: '2025-06-08' },
]

const initialRoomUnits: RoomUnit[] = [
  { id: 1, name: 'Deluxe A/C', number: '101-120', floor: 1, price: 3500, status: 'clean' },
  { id: 2, name: 'Super Deluxe A/C', number: '201-215', floor: 2, price: 4500, status: 'occupied' },
  { id: 3, name: 'Semi Suite', number: '301-310', floor: 3, price: 5500, status: 'cleaning' },
  { id: 4, name: 'Suite', number: '401-405', floor: 4, price: 7500, status: 'occupied' },
  { id: 5, name: 'Deluxe A/C', number: '102-110', floor: 1, price: 3500, status: 'dirty' },
  { id: 6, name: 'Super Deluxe A/C', number: '202-208', floor: 2, price: 4500, status: 'clean' },
  { id: 7, name: 'Semi Suite', number: '303-306', floor: 3, price: 5500, status: 'repairing' },
  { id: 8, name: 'Suite', number: '402-403', floor: 4, price: 7500, status: 'dirty' },
]

const initialOrders: Order[] = [
  { id: 1, roomNumber: '205', guestName: 'Pablo Morales', items: 'Chicken Momo x2, Fried Rice, Beer x2', total: 2800, status: 'completed', type: 'room-service', createdAt: '2025-06-07T19:30:00' },
  { id: 2, roomNumber: '102', guestName: 'John Smith', items: 'Breakfast Buffet x2, Cappuccino x2', total: 1600, status: 'in-progress', type: 'restaurant', createdAt: '2025-06-08T08:15:00' },
  { id: 3, roomNumber: null, guestName: 'Walk-in', items: 'Dal Bhat x4, Coke x4', total: 2400, status: 'pending', type: 'restaurant', createdAt: '2025-06-08T12:45:00' },
  { id: 4, roomNumber: '301', guestName: 'Anita Gurung', items: 'Sandwich, Latte, Fruit Salad', total: 950, status: 'completed', type: 'cafe', createdAt: '2025-06-08T15:20:00' },
]

const initialExpenses: Expense[] = [
  { id: 1, title: 'Food Supplies - June', category: 'Food & Beverage', amount: 85000, date: '2025-06-01', paidTo: 'Local Market Suppliers' },
  { id: 2, title: 'Staff Salary - June', category: 'Staff Salary', amount: 320000, date: '2025-06-01', paidTo: 'All Staff' },
  { id: 3, title: 'Electricity Bill', category: 'Utilities', amount: 45000, date: '2025-06-05', paidTo: 'Nepal Electricity Authority' },
  { id: 4, title: 'Garden Maintenance', category: 'Maintenance', amount: 15000, date: '2025-06-03', paidTo: 'Green Thumb Services' },
  { id: 5, title: 'AC Repair Parts', category: 'Maintenance', amount: 22000, date: '2025-06-06', paidTo: 'HVAC Solutions' },
]

const initialCoupons: Coupon[] = [
  { id: 1, code: 'ORCHID20', discount: 20, type: 'percentage', maxUses: 100, used: 34, expires: '2025-12-31', status: 'active' },
  { id: 2, code: 'WELCOME500', discount: 500, type: 'fixed', maxUses: 200, used: 89, expires: '2025-09-30', status: 'active' },
  { id: 3, code: 'FESTIVAL15', discount: 15, type: 'percentage', maxUses: 500, used: 0, expires: '2025-10-15', status: 'scheduled' },
  { id: 4, code: 'SUMMER10', discount: 10, type: 'percentage', maxUses: 50, used: 50, expires: '2025-06-30', status: 'expired' },
  { id: 5, code: 'AVOCADO2026', discount: 25, type: 'percentage', maxUses: 1000, used: 0, expires: '2026-12-31', status: 'scheduled' },
]

const initialAutomations: AutomationRule[] = [
  { id: 1, name: 'Welcome Message', trigger: 'After check-in', status: 'active', desc: 'Send welcome message 1 hour after guest checks in' },
  { id: 2, name: 'Review Request', trigger: 'After checkout', status: 'active', desc: 'Request review 24 hours after guest departure' },
  { id: 3, name: 'Birthday Greeting', trigger: 'Guest birthday', status: 'paused', desc: 'Send birthday discount code to repeat guests' },
  { id: 4, name: 'Abandoned Booking', trigger: 'Incomplete booking', status: 'active', desc: 'Follow up email after 2 hours of abandoned cart' },
]

// ─── Context Type ────────────────────────────────────────
interface AppContextType {
  // Admin session
  isAdminActive: boolean
  setAdminActive: (v: boolean) => void

  // Data
  bookings: Booking[]
  setBookings: React.Dispatch<React.SetStateAction<Booking[]>>
  messages: Message[]
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>
  staff: StaffMember[]
  setStaff: React.Dispatch<React.SetStateAction<StaffMember[]>>
  tasks: Task[]
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>
  roomUnits: RoomUnit[]
  setRoomUnits: React.Dispatch<React.SetStateAction<RoomUnit[]>>
  orders: Order[]
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>
  expenses: Expense[]
  setExpenses: React.Dispatch<React.SetStateAction<Expense[]>>
  coupons: Coupon[]
  setCoupons: React.Dispatch<React.SetStateAction<Coupon[]>>
  automations: AutomationRule[]
  setAutomations: React.Dispatch<React.SetStateAction<AutomationRule[]>>

  // Actions
  addBooking: (b: Omit<Booking, 'id' | 'createdAt'>) => void
  updateBookingStatus: (id: number, status: Booking['status']) => void
  markMessageRead: (id: number) => void
  addTask: (t: Omit<Task, 'id'>) => void
  updateTaskStatus: (id: number, status: Task['status']) => void
  updateRoomStatus: (id: number, status: RoomUnit['status']) => void
  addExpense: (e: Omit<Expense, 'id'>) => void
  addCoupon: (c: Omit<Coupon, 'id'>) => void
  toggleAutomation: (id: number) => void
  addOrder: (o: Omit<Order, 'id' | 'createdAt'>) => void
  addStaff: (s: Omit<StaffMember, 'id'>) => void

  // Sidebar
  sidebarCollapsed: boolean
  setSidebarCollapsed: (v: boolean) => void
}

const AppContext = createContext<AppContextType | null>(null)

// ─── Provider ────────────────────────────────────────────
export function AppProvider({ children }: { children: ReactNode }) {
  const [isAdminActive, setAdminActive] = useState(() => {
    if (typeof window === 'undefined') return false
    return localStorage.getItem('admin-session') === 'true'
  })

  const [bookings, setBookings] = useState<Booking[]>(initialBookings)
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [staff, setStaff] = useState<StaffMember[]>(initialStaff)
  const [tasks, setTasks] = useState<Task[]>(initialTasks)
  const [roomUnits, setRoomUnits] = useState<RoomUnit[]>(initialRoomUnits)
  const [orders, setOrders] = useState<Order[]>(initialOrders)
  const [expenses, setExpenses] = useState<Expense[]>(initialExpenses)
  const [coupons, setCoupons] = useState<Coupon[]>(initialCoupons)
  const [automations, setAutomations] = useState<AutomationRule[]>(initialAutomations)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  const addBooking = useCallback((b: Omit<Booking, 'id' | 'createdAt'>) => {
    const newBooking: Booking = {
      ...b,
      id: Math.max(...bookings.map((x) => x.id), 1000) + 1,
      createdAt: new Date().toISOString(),
    }
    setBookings((prev) => [newBooking, ...prev])
  }, [bookings])

  const updateBookingStatus = useCallback((id: number, status: Booking['status']) => {
    setBookings((prev) => prev.map((b) => b.id === id ? { ...b, status } : b))
  }, [])

  const markMessageRead = useCallback((id: number) => {
    setMessages((prev) => prev.map((m) => m.id === id ? { ...m, isRead: 'read' as const } : m))
  }, [])

  const addTask = useCallback((t: Omit<Task, 'id'>) => {
    const newTask: Task = { ...t, id: Math.max(...tasks.map((x) => x.id), 0) + 1 }
    setTasks((prev) => [...prev, newTask])
  }, [tasks])

  const updateTaskStatus = useCallback((id: number, status: Task['status']) => {
    setTasks((prev) => prev.map((t) => t.id === id ? { ...t, status } : t))
  }, [])

  const updateRoomStatus = useCallback((id: number, status: RoomUnit['status']) => {
    setRoomUnits((prev) => prev.map((r) => r.id === id ? { ...r, status } : r))
  }, [])

  const addExpense = useCallback((e: Omit<Expense, 'id'>) => {
    const newExpense: Expense = { ...e, id: Math.max(...expenses.map((x) => x.id), 0) + 1 }
    setExpenses((prev) => [...prev, newExpense])
  }, [expenses])

  const addCoupon = useCallback((c: Omit<Coupon, 'id'>) => {
    const newCoupon: Coupon = { ...c, id: Math.max(...coupons.map((x) => x.id), 0) + 1 }
    setCoupons((prev) => [...prev, newCoupon])
  }, [coupons])

  const toggleAutomation = useCallback((id: number) => {
    setAutomations((prev) => prev.map((a) => a.id === id ? { ...a, status: a.status === 'active' ? ('paused' as const) : ('active' as const) } : a))
  }, [])

  const addOrder = useCallback((o: Omit<Order, 'id' | 'createdAt'>) => {
    const newOrder: Order = { ...o, id: Math.max(...orders.map((x) => x.id), 0) + 1, createdAt: new Date().toISOString() }
    setOrders((prev) => [newOrder, ...prev])
  }, [orders])

  const addStaff = useCallback((s: Omit<StaffMember, 'id'>) => {
    const newStaff: StaffMember = { ...s, id: Math.max(...staff.map((x) => x.id), 0) + 1 }
    setStaff((prev) => [...prev, newStaff])
  }, [staff])

  return (
    <AppContext.Provider value={{
      isAdminActive, setAdminActive,
      bookings, setBookings,
      messages, setMessages,
      staff, setStaff,
      tasks, setTasks,
      roomUnits, setRoomUnits,
      orders, setOrders,
      expenses, setExpenses,
      coupons, setCoupons,
      automations, setAutomations,
      addBooking, updateBookingStatus, markMessageRead,
      addTask, updateTaskStatus, updateRoomStatus,
      addExpense, addCoupon, toggleAutomation,
      addOrder, addStaff,
      sidebarCollapsed, setSidebarCollapsed,
    }}>
      {children}
    </AppContext.Provider>
  )
}

// ─── Hook ────────────────────────────────────────────────
export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
