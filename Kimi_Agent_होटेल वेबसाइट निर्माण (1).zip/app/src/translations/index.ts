export type Lang = 'en' | 'np'

export const translations = {
  // Navigation
  home: { en: 'Home', np: 'गृहपृष्ठ' },
  rooms: { en: 'Rooms', np: 'कोठाहरू' },
  dining: { en: 'Dining', np: 'भोजन' },
  gallery: { en: 'Gallery', np: 'ग्यालरी' },
  contact: { en: 'Contact', np: 'सम्पर्क' },
  bookNow: { en: 'Book Now', np: 'अहिले बुक गर्नुहोस्' },
  myAccount: { en: 'My Account', np: 'मेरो खाता' },
  admin: { en: 'Admin', np: 'प्रशासन' },
  login: { en: 'Login', np: 'लगइन' },
  logout: { en: 'Logout', np: 'लगआउट' },

  // Hero
  heroTagline: {
    en: "Nepal's Only Avocado & Orchid Resort",
    np: 'नेपालको एकमात्र एभोकाडो र ओर्किड रिसोर्ट'
  },
  heroTitle: { en: 'Where Nature Meets Luxury', np: 'जहाँ प्रकृति र भव्यता भेटिन्छ' },
  heroSubtitle: {
    en: 'Nestled in the heart of Hetauda, surrounded by lush avocado orchards and vibrant orchid gardens. Experience tranquility, comfort, and authentic Nepali hospitality.',
    np: 'हेटौडाको मुटुमा रहेको, हरियाली एभोकाडो बगैंचा र रंगीन ओर्किड बगैंचाले घेरिएको। शान्ति, आराम र असली नेपाली Hospitality अनुभव गर्नुहोस्।'
  },
  exploreRooms: { en: 'Explore Rooms', np: 'कोठाहरू हेर्नुहोस्' },
  bookYourStay: { en: 'Book Your Stay', np: 'आफ्नो बसाइ बुक गर्नुहोस्' },
  checkAvailability: { en: 'Check Availability', np: 'उपलब्धता जाँच गर्नुहोस्' },
  ratingLabel: { en: 'Exceptional — Hotels.com', np: 'उत्कृष्ट — Hotels.com' },
  scrollExplore: { en: 'Scroll to explore', np: 'अन्वेषण गर्न स्क्रोल गर्नुहोस्' },

  // About
  welcomeLabel: { en: 'WELCOME TO PARADISE', np: 'स्वर्गमा स्वागत छ' },
  aboutTitle: {
    en: 'A Legacy of Hospitality in the Heart of Hetauda',
    np: 'हेटौडाको मुटुमा Hospitality को विरासत'
  },
  aboutDesc: {
    en: 'Welcome to the serene and enchanting Avocado and Orchid Resort, nestled amidst the breathtaking landscapes of Hetauda, Nepal. This exquisite resort is a true paradise for nature lovers, offering a perfect blend of tranquillity, luxury, and natural beauty.',
    np: 'हेटौडाको मनमोहक दृश्यहरूको बीचमा रहेको शान्त र मनमोहक एभोकाडो एन्ड ओर्किड रिसोर्टमा स्वागत छ। यस उत्कृष्ट रिसोर्ट प्रकृति प्रेमीहरूको लागि वास्तविक स्वर्ग हो, जसले शान्ति, भव्यता र प्राकृतिक सौन्दर्यको उत्तम मिश्रण प्रदान गर्छ।'
  },
  aboutHighlight: {
    en: 'This is the only place in Nepal where you can enjoy fresh Avocado Fruit, and the only Resort with an Orchid Garden with over 80 species of orchids in cultivation.',
    np: 'नेपालमा ताजा एभोकाडो फल खान पाउने एक मात्र स्थान, र ८०+ प्रजातिका ओर्किडहरू रोपिएको एक मात्र रिसोर्ट।'
  },
  luxuryRooms: { en: 'Luxury Rooms', np: 'भव्य कोठाहरू' },
  guestRating: { en: 'Guest Rating', np: 'पाहुनाको मूल्यांकन' },
  yearsOfService: { en: 'Years of Service', np: 'सेवाको वर्ष' },

  // Room Showcase
  ourAccommodations: { en: 'OUR ACCOMMODATIONS', np: 'हाम्रो आवास' },
  roomsTitle: { en: 'Rooms Designed for Your Comfort', np: 'तपाईंको आरामको लागि डिजाइन गरिएका कोठाहरू' },
  roomsSubtitle: {
    en: 'Choose from our selection of 58 air-conditioned rooms, each thoughtfully appointed with modern amenities and garden views.',
    np: 'हाम्रो ५८ एयर-कन्डिसन्ड कोठाहरूबाट छनोट गर्नुहोस्, प्रत्येक आधुनिक सुविधाहरू र बगैंचा दृश्यसहित सुसज्जित।'
  },
  perNight: { en: 'per night', np: 'प्रति रात' },
  from: { en: 'From', np: 'देखि' },
  viewDetails: { en: 'View Details', np: 'विवरण हेर्नुहोस्' },
  viewAllRooms: { en: 'View All Rooms', np: 'सबै कोठाहरू हेर्नुहोस्' },
  guests: { en: 'guests', np: 'पाहुनाहरू' },
  sqFt: { en: 'sq ft', np: 'वर्ग फिट' },

  // Why Choose Us
  whyChooseUs: { en: 'WHY CHOOSE US', np: 'हामीलाई किन छनोट गर्ने' },
  whyTitle: { en: 'Experience the Avocado & Orchid Difference', np: 'एभोकाडो र ओर्किडको अनुभव गर्नुहोस्' },
  featureOrchid: {
    en: 'The only resort in Nepal featuring a stunning Orchid Garden with over 80 species in cultivation.',
    np: '८०+ प्रजातिका ओर्किडहरू रोपिएको नेपालको एक मात्र रिसोर्ट।'
  },
  featureAvocado: {
    en: 'The only place in Nepal where you can enjoy fresh Avocado fruit, picked from our own orchards.',
    np: 'हाम्रै बगैंचाबाट टिपिएका ताजा एभोकाडो फल खान पाउने एक मात्र स्थान।'
  },
  featureLocation: {
    en: "Centrally located just minutes from Hetauda's business center. Easy access to Chitwan National Park.",
    np: 'हेटौडाको व्यापारिक केन्द्रबाट केही मिनेटको दूरीमा। चितवन राष्ट्रिय निकुञ्जमा सजिलो पहुँच।'
  },
  featureDining: {
    en: 'Savor Continental, Chinese, Indian, and authentic Nepalese cuisine at our restaurants.',
    np: 'हाम्रो रेस्टुरेन्टमा कन्टिनेन्टल, चाइनिज, इन्डियन र असली नेपाली cuisine को आनन्द लिनुहोस्।'
  },
  featureAmenities: {
    en: 'Free high-speed Wi-Fi, 24-hour front desk, daily housekeeping, laundry, and secure parking.',
    np: 'निःशुल्क वाइ-फाइ, २४-घण्टा रिसेप्सन, दैनिक हाउसकिपिङ, लन्ड्री र सुरक्षित पार्किङ।'
  },
  featureService: {
    en: 'Rated 9.6/10 Exceptional on Hotels.com. Our friendly staff ensures a memorable stay.',
    np: 'Hotels.com मा ९.६/१० उत्कृष्ट रेटिङ। हाम्रो मैत्रीपूर्ण स्टाफले अविस्मरणीय बसाइ सुनिश्चित गर्छ।'
  },
  orchidGarden: { en: 'Unique Orchid Garden', np: 'अद्वितीय ओर्किड बगैंचा' },
  freshAvocado: { en: 'Fresh Avocado Experience', np: 'ताजा एभोकाडो अनुभव' },
  centralLocation: { en: 'Central Location', np: 'केन्द्रीय स्थान' },
  multiCuisine: { en: 'Multi-Cuisine Dining', np: 'बहु-भोजन' },
  modernAmenities: { en: 'Modern Amenities', np: 'आधुनिक सुविधाहरू' },
  awardWinning: { en: 'Award-Winning Service', np: 'पुरस्कृत सेवा' },

  // Dining
  diningLabel: { en: 'DINING EXPERIENCE', np: 'भोजन अनुभव' },
  diningTitle: { en: 'Culinary Delights Await', np: 'पाक कला आनन्द तपाईंको पर्खाइमा' },
  diningDesc: {
    en: "Culinary delights await you at Avocado and Orchid Resort's restaurants, where our local chefs blend local flavours with international cuisine.",
    np: 'हाम्रो स्थानीय सेफहरूले स्थानीय स्वादलाई अन्तर्राष्ट्रिय cuisine सँग मिश्रण गर्ने रेस्टुरेन्टमा पाक कला आनन्दको प्रतीक्षा गरिरहेको छ।'
  },
  avocadoRestaurant: { en: 'Avocado Restaurant', np: 'एभोकाडो रेस्टुरेन्ट' },
  crustCafe: { en: 'Crust Cafe', np: 'क्रस्ट क्याफे' },
  barLounge: { en: 'Bar & Lounge', np: 'बार र लाउन्ज' },
  exploreMenu: { en: 'Explore Our Menu', np: 'हाम्रो मेनु हेर्नुहोस्' },

  // Gallery
  galleryLabel: { en: 'GALLERY', np: 'ग्यालरी' },
  galleryTitle: { en: 'Glimpses of Your Stay', np: 'तपाईंको बसाइको झलकहरू' },
  viewFullGallery: { en: 'View Full Gallery', np: 'पूर्ण ग्यालरी हेर्नुहोस्' },

  // Testimonials
  guestReviews: { en: 'GUEST REVIEWS', np: 'पाहुनाको समीक्षा' },
  whatGuestsSay: { en: 'What Our Guests Say', np: 'हाम्रो पाहुनाले के भन्छन्' },
  ratedExceptional: { en: 'Rated 9.6/10 — Exceptional', np: '९.६/१० रेटिङ — उत्कृष्ट' },

  // Nearby Attractions
  exploreHetauda: { en: 'EXPLORE HETAUDA', np: 'हेटौडा अन्वेषण गर्नुहोस्' },
  discoverBeauty: { en: 'Discover the Beauty Around Us', np: 'हाम्रो वरिपरिको सौन्दर्य खोज्नुहोस्' },
  chitwanTitle: { en: 'Chitwan National Park', np: 'चितवन राष्ट्रिय निकुञ्ज' },
  chitwanDesc: {
    en: 'A UNESCO World Heritage Site famous for one-horned rhinoceros, Bengal tigers, and elephant safaris.',
    np: 'एकसिङ्गे गैंडा, बङ्गाल बाघ र हात्ती सफारी प्रसिद्ध UNESCO विश्व सम्पदा स्थल।'
  },
  viewTowerTitle: { en: 'Hetauda View Tower', np: 'हेटौडा भ्यू टावर' },
  viewTowerDesc: { en: 'Panoramic views of Hetauda city and surrounding hills. Perfect for sunset watching.', np: 'हेटौडा शहर र वरिपरिका पहाडहरूको प्यानोरामिक दृश्य। सूर्यास्त हेर्न उत्तम।' },
  triveniTitle: { en: 'Triveni Dham', np: 'त्रिवेणी धाम' },
  triveniDesc: { en: 'A sacred religious site and popular pilgrimage destination.', np: 'एक पवित्र धार्मिक स्थल र लोकप्रिय तीर्थ स्थल।' },
  shahidTitle: { en: 'Shahid Smarak Park', np: 'शहीद स्मारक पार्क' },
  shahidDesc: { en: 'A beautiful memorial park dedicated to martyrs. Ideal for morning walks.', np: 'शहीदहरूको लागि समर्पित सुन्दर स्मारक पार्क। बिहानको हिँड्डका लागि उत्तम।' },

  // Contact
  readyTitle: { en: 'Ready to Experience Tranquility?', np: 'शान्ति अनुभव गर्न तयार हुनुहुन्छ?' },
  readyDesc: {
    en: 'Book your stay today and immerse yourself in the natural beauty of Hetauda.',
    np: 'आजै आफ्नो बसाइ बुक गर्नुहोस् र हेटौडाको प्राकृतिक सौन्दर्यमा डुब्नुहोस्।'
  },
  ourLocation: { en: 'Our Location', np: 'हाम्रो स्थान' },
  address: { en: 'Chaukitol 2, Tribhuvan Rajpath, Hetauda 44107, Nepal', np: 'चौकीतोल २, त्रिभुवन राजपथ, हेटौडा ४४१०७, नेपाल' },
  phone: { en: 'Phone', np: 'फोन' },
  email: { en: 'Email', np: 'इमेल' },
  checkInOut: { en: 'Check-in: 12:00 PM | Check-out: 11:00 AM', np: 'चेक-इन: बिहान १२:०० | चेक-आउट: बिहान ११:००' },
  sendMessage: { en: 'Send Us a Message', np: 'हामीलाई सन्देश पठाउनुहोस्' },
  yourName: { en: 'Your Name', np: 'तपाईंको नाम' },
  emailAddress: { en: 'Email Address', np: 'इमेल ठेगाना' },
  phoneNumber: { en: 'Phone Number', np: 'फोन नम्बर' },
  yourMessage: { en: 'Your Message', np: 'तपाईंको सन्देश' },
  send: { en: 'Send Message', np: 'सन्देश पठाउनुहोस्' },
  thankYou: { en: 'Thank You!', np: 'धन्यवाद!' },
  messageReply: { en: "We'll get back to you soon.", np: 'हामी चाँडै नै सम्पर्क गर्नेछौं।' },
  bookingConfirmed: { en: 'Booking Confirmed!', np: 'बुकिङ पुष्टि भयो!' },
  confirmationEmail: { en: 'A confirmation email will be sent shortly.', np: 'पुष्टिकरण इमेल चाँडै पठाइनेछ।' },
  bookAnother: { en: 'Book Another Room', np: 'अर्को कोठा बुक गर्नुहोस्' },

  // Footer
  exclusiveAccommodation: {
    en: 'The Most Exclusive Accommodation in Hetauda, Nepal. Only resort with fresh Avocado and Orchid Garden.',
    np: 'हेटौडाको सबैभन्दा विशेष आवास। ताजा एभोकाडो र ओर्किड बगैंचासहितको एक मात्र रिसोर्ट।'
  },
  quickLinks: { en: 'Quick Links', np: 'द्रुत लिङ्कहरू' },
  contactUs: { en: 'Contact Us', np: 'हामीलाई सम्पर्क गर्नुहोस्' },
  allRightsReserved: { en: 'All rights reserved.', np: 'सबै अधिकार सुरक्षित।' },
  proudlyServing: { en: 'Proudly serving guests since the 1980s.', np: '१९८० देखि पाहुनाहरूलाई सेवा गर्दै आएका छौं।' },

  // Booking Widget
  roomType: { en: 'Room Type', np: 'कोठाको प्रकार' },
  checkIn: { en: 'Check-in', np: 'चेक-इन' },
  checkOut: { en: 'Check-out', np: 'चेक-आउट' },
  adults: { en: 'Adults', np: 'वयस्क' },
  children: { en: 'Children', np: 'बालबालिका' },
  fullName: { en: 'Full Name', np: 'पूरा नाम' },
  couponCode: { en: 'Coupon Code', np: 'कुपन कोड' },
  total: { en: 'Total', np: 'जम्मा' },
  submitBooking: { en: 'Submit Booking Request', np: 'बुकिङ अनुरोध पठाउनुहोस्' },
  secureCheckout: { en: 'Secure Checkout', np: 'सुरक्षित चेकआउट' },
  pay: { en: 'Pay', np: 'तिर्नुहोस्' },
  nights: { en: 'nights', np: 'रातहरू' },
  discount: { en: 'Discount', np: 'छूट' },
  simulatedPayment: { en: '* Simulated payment gateway. In production, redirects to actual Khalti/eSewa/Stripe.', np: '* अनुकरण भुक्तानी गेटवे। प्रोडक्सनमा वास्तविक Khalti/eSewa/Stripe मा जान्छ।' },

  // Dining Details
  openDaily: { en: 'Open Daily: 6:30 AM — 11:00 PM', np: 'दैनिक: बिहान ६:३० — राति ११:००' },
  cuisines: { en: 'Continental • Chinese • Indian • Nepalese', np: 'कन्टिनेन्टल • चाइनिज • इन्डियन • नेपाली' },
  restaurantDesc: {
    en: 'Signature restaurant serving breakfast, lunch, and dinner. A la carte and buffet options available.',
    np: 'हस्ताक्षर रेस्टुरेन्ट जसले ब्रेकफास्ट, लन्च र डिनर सेवा गर्छ। ए ला कार्ट र बफे विकल्प उपलब्ध।'
  },
  cafeDesc: {
    en: 'A cozy cafe perfect for coffee, snacks, and light meals. Freshly brewed espresso, latte, and cappuccino.',
    np: 'कफी, स्न्याक्स र हल्का भोजनको लागि उत्तम सहज क्याफे। ताजा एस्प्रेसो, लatte र क्यापुचिनो।'
  },
  barDesc: {
    en: 'Unwind with your favorite drink at our bar lounge. Perfect for evening relaxation and social gatherings.',
    np: 'हाम्रो बार लाउन्जमा आफ्नो मनपर्ने पेय पदार्थसँग आराम गर्नुहोस्। साँझको आराम र सामाजिक भेलाको लागि उत्तम।'
  },
  diningQuote: {
    en: 'They even make real coffee — latte, cappuccino, and so on. I will definitely stay there again!',
    np: 'उनीहरूले वास्तविक कफी पनि बनाउँछन् — लatte, क्यापुचिनो, आदि। म निश्चय पनि फेरि बस्नेछु!'
  },
  diningQuoteAuthor: { en: '— Pablo, Russia', np: '— पाब्लो, रुस' },

  // Gallery
  view: { en: 'View', np: 'हेर्नुहोस्' },

  // Contact Form
  sending: { en: 'Sending...', np: 'पठाउँदै...' },
  sendFailed: { en: 'Failed to send. Please try again.', np: 'पठाउन असफल। कृपया पुन: प्रयास गर्नुहोस्।' },

  // Rooms Page
  ourRooms: { en: 'OUR ROOMS', np: 'हाम्रो कोठाहरू' },
  findYourStay: { en: 'Find Your Perfect Stay', np: 'आफ्नो उत्तम बसाइ खोज्नुहोस्' },
  roomsCountDesc: {
    en: '58 air-conditioned rooms designed for comfort and relaxation',
    np: 'आराम र विश्रामको लागि डिजाइन गरिएका ५८ एयर-कन्डिसन्ड कोठाहरू'
  },
  allRooms: { en: 'All Rooms', np: 'सबै कोठाहरू' },
  bookThisRoom: { en: 'Book This Room', np: 'यो कोठा बुक गर्नुहोस्' },
  night: { en: '/night', np: '/रात' },
  airConditioned: { en: 'Air Conditioned', np: 'एयर कन्डिसन्ड' },
  privateBathroom: { en: 'Private Bathroom', np: 'निजी बाथरूम' },

  // Dining Page
  feastSenses: { en: 'A Feast for the Senses', np: 'इन्द्रियहरूको भोज' },
  diningCuisineDesc: {
    en: 'Continental, Chinese, Indian & Nepalese cuisine crafted by our expert chefs',
    np: 'हाम्रा विशेषज्ञ सेफहरूद्वारा तयार गरिएको कन्टिनेन्टल, चाइनिज, इन्डियन र नेपाली cuisine'
  },
  makeReservation: { en: 'Make a Reservation', np: 'सुरक्षित गर्नुहोस्' },
  visitCafe: { en: 'Visit Crust Cafe', np: 'क्रस्ट क्याफे भ्रमण गर्नुहोस्' },
  relaxUnwind: { en: 'RELAX & UNWIND', np: 'आराम गर्नुहोस्' },
  barHours: { en: 'Open Daily: 12:00 PM — 11:00 PM', np: 'दैनिक: दिउँसो १२:०० — राति ११:००' },
  barDescPage: {
    en: "Quench your thirst with your favorite drink at our bar lounge. Whether you're unwinding after a day of exploration or celebrating a special occasion, our bar offers the perfect ambiance.",
    np: 'हाम्रो बार लाउन्जमा आफ्नो मनपर्ने पेय पदार्थसँग तिर्खा मेट्नुहोस्। अन्वेषणको दिनपछि आराम गर्दै वा विशेष अवसर मनाउँदै, हाम्रो बारले उत्तम वातावरण प्रदान गर्छ।'
  },

  // Gallery Page
  visualJourney: { en: 'Visual Journey', np: 'दृश्य यात्रा' },
  all: { en: 'All', np: 'सबै' },
  garden: { en: 'Garden', np: 'बगैंचा' },
  hotelLabel: { en: 'Hotel', np: 'होटल' },

  // Guests
  guest1: { en: '1 Guest', np: '१ जना पाहुना' },
  guest2: { en: '2 Guests', np: '२ जना पाहुना' },
  guest3: { en: '3 Guests', np: '३ जना पाहुना' },
  guest4: { en: '4 Guests', np: '४ जना पाहुना' },

  // Misc
  loading: { en: 'Loading...', np: 'लोड हुँदैछ...' },
  close: { en: 'Close', np: 'बन्द गर्नुहोस्' },
  more: { en: 'more', np: 'थप' },
} as const

export type TranslationKey = keyof typeof translations

export function t(key: TranslationKey, lang: Lang): string {
  return translations[key]?.[lang] || translations[key]?.['en'] || key
}
