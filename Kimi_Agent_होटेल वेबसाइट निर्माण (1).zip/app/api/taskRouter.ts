import { z } from "zod";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { tasks } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const taskRouter = createRouter({
  list: adminQuery.query(async () => {
    return getDb().select().from(tasks).orderBy(desc(tasks.createdAt));
  }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ count: count() }).from(tasks);
    const todo = await db.select({ count: count() }).from(tasks).where(eq(tasks.status, "todo"));
    const inProgress = await db.select({ count: count() }).from(tasks).where(eq(tasks.status, "in_progress"));
    const done = await db.select({ count: count() }).from(tasks).where(eq(tasks.status, "done"));
    return { total: total[0].count, todo: todo[0].count, inProgress: inProgress[0].count, done: done[0].count };
  }),

  create: adminQuery
    .input(z.object({
      roomId: z.number().optional(),
      title: z.string().min(1),
      description: z.string().optional(),
      type: z.enum(["cleaning", "maintenance", "inspection", "service", "other"]),
      priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
      assignedTo: z.string().optional(),
      dueDate: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const id = await getDb().insert(tasks).values({
        roomId: input.roomId || null,
        title: input.title,
        description: input.description || null,
        type: input.type,
        priority: input.priority,
        assignedTo: input.assignedTo || null,
        dueDate: input.dueDate ? new Date(input.dueDate) : null,
        createdBy: ctx.user?.name || "admin",
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  updateStatus: adminQuery
    .input(z.object({ id: z.number(), status: z.enum(["todo", "in_progress", "done", "cancelled"]) }))
    .mutation(async ({ input }) => {
      const updateData: any = { status: input.status };
      if (input.status === "done") updateData.completedAt = new Date();
      await getDb().update(tasks).set(updateData).where(eq(tasks.id, input.id));
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(tasks).where(eq(tasks.id, input.id));
      return { success: true };
    }),
});
