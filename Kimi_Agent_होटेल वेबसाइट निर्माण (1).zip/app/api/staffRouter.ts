import { z } from "zod";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { staff } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const staffRouter = createRouter({
  list: adminQuery.query(async () => {
    return getDb().select().from(staff).orderBy(desc(staff.createdAt));
  }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ count: count() }).from(staff);
    const active = await db.select({ count: count() }).from(staff).where(eq(staff.isActive, "active"));
    return { total: total[0].count, active: active[0].count };
  }),

  create: adminQuery
    .input(z.object({
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      position: z.enum(["manager", "receptionist", "housekeeping", "chef", "waiter", "maintenance", "security"]),
      department: z.string().optional(),
      salary: z.number().optional(),
      joinedDate: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(staff).values({
        name: input.name,
        email: input.email,
        phone: input.phone || null,
        position: input.position,
        department: input.department || null,
        salary: input.salary || null,
        joinedDate: input.joinedDate ? new Date(input.joinedDate) : null,
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  updateStatus: adminQuery
    .input(z.object({ id: z.number(), isActive: z.enum(["active", "inactive"]) }))
    .mutation(async ({ input }) => {
      await getDb().update(staff).set({ isActive: input.isActive }).where(eq(staff.id, input.id));
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(staff).where(eq(staff.id, input.id));
      return { success: true };
    }),
});
