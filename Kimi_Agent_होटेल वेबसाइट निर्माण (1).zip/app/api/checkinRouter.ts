import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { checkIns } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const checkinRouter = createRouter({
  // Public: Submit online check-in
  submit: publicQuery
    .input(z.object({
      bookingId: z.number(),
      guestName: z.string().min(1),
      guestEmail: z.string().email(),
      guestPhone: z.string().optional(),
      arrivalTime: z.string().optional(),
      numberOfGuests: z.number().min(1).default(1),
      vehicleNumber: z.string().optional(),
      specialRequests: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(checkIns).values({
        bookingId: input.bookingId,
        guestName: input.guestName,
        guestEmail: input.guestEmail,
        guestPhone: input.guestPhone || null,
        arrivalTime: input.arrivalTime || null,
        numberOfGuests: input.numberOfGuests,
        vehicleNumber: input.vehicleNumber || null,
        specialRequests: input.specialRequests || null,
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  // Admin: List all check-ins
  list: adminQuery.query(async () => {
    return getDb().select().from(checkIns).orderBy(desc(checkIns.createdAt));
  }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ count: count() }).from(checkIns);
    const pending = await db.select({ count: count() }).from(checkIns).where(eq(checkIns.status, "pending"));
    const today = await db.select({ count: count() }).from(checkIns)
      .where(eq(checkIns.status, "pending"));
    return { total: total[0].count, pending: pending[0].count, todayArrivals: today[0].count };
  }),

  updateStatus: adminQuery
    .input(z.object({ id: z.number(), status: z.enum(["pending", "completed"]) }))
    .mutation(async ({ input }) => {
      await getDb().update(checkIns).set({ status: input.status }).where(eq(checkIns.id, input.id));
      return { success: true };
    }),
});
