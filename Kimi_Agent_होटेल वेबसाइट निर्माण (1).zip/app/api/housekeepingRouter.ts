import { z } from "zod";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { roomStatuses, maintenanceSchedules, lostAndFound } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const housekeepingRouter = createRouter({
  // ─── Room Status ───
  roomStatusList: adminQuery.query(async () => {
    return getDb().select().from(roomStatuses).orderBy(desc(roomStatuses.updatedAt));
  }),

  updateRoomStatus: adminQuery
    .input(z.object({
      roomId: z.number(),
      status: z.enum(["clean", "dirty", "inspected", "out_of_order", "repairing"]),
      housekeeperName: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(roomStatuses).where(eq(roomStatuses.roomId, input.roomId));
      const updateData: any = { status: input.status, updatedAt: new Date() };
      if (input.housekeeperName) updateData.housekeeperName = input.housekeeperName;
      if (input.notes) updateData.notes = input.notes;
      if (input.status === "clean") updateData.cleanedAt = new Date();

      if (existing.length > 0) {
        await db.update(roomStatuses).set(updateData).where(eq(roomStatuses.roomId, input.roomId));
      } else {
        await db.insert(roomStatuses).values({ roomId: input.roomId, ...updateData });
      }
      return { success: true };
    }),

  roomStatusStats: adminQuery.query(async () => {
    const db = getDb();
    const clean = await db.select({ count: count() }).from(roomStatuses).where(eq(roomStatuses.status, "clean"));
    const dirty = await db.select({ count: count() }).from(roomStatuses).where(eq(roomStatuses.status, "dirty"));
    const inspected = await db.select({ count: count() }).from(roomStatuses).where(eq(roomStatuses.status, "inspected"));
    const ooo = await db.select({ count: count() }).from(roomStatuses).where(eq(roomStatuses.status, "out_of_order"));
    return { clean: clean[0].count, dirty: dirty[0].count, inspected: inspected[0].count, outOfOrder: ooo[0].count };
  }),

  // ─── Maintenance ───
  maintenanceList: adminQuery.query(async () => {
    return getDb().select().from(maintenanceSchedules).orderBy(desc(maintenanceSchedules.createdAt));
  }),

  createMaintenance: adminQuery
    .input(z.object({
      roomId: z.number().optional(),
      title: z.string().min(1),
      description: z.string().optional(),
      equipment: z.string().optional(),
      frequency: z.enum(["daily", "weekly", "monthly", "quarterly", "yearly"]),
      nextDue: z.string(),
      assignedTo: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(maintenanceSchedules).values({
        roomId: input.roomId || null,
        title: input.title,
        description: input.description || null,
        equipment: input.equipment || null,
        frequency: input.frequency,
        nextDue: new Date(input.nextDue),
        assignedTo: input.assignedTo || null,
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  completeMaintenance: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().update(maintenanceSchedules).set({
        lastDone: new Date(),
      }).where(eq(maintenanceSchedules.id, input.id));
      return { success: true };
    }),

  // ─── Lost & Found ───
  lostFoundList: adminQuery.query(async () => {
    return getDb().select().from(lostAndFound).orderBy(desc(lostAndFound.createdAt));
  }),

  createLostFound: adminQuery
    .input(z.object({
      bookingId: z.number().optional(),
      guestName: z.string().optional(),
      itemName: z.string().min(1),
      description: z.string().optional(),
      foundDate: z.string(),
      foundLocation: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(lostAndFound).values({
        bookingId: input.bookingId || null,
        guestName: input.guestName || null,
        itemName: input.itemName,
        description: input.description || null,
        foundDate: new Date(input.foundDate),
        foundLocation: input.foundLocation || null,
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  updateLostFoundStatus: adminQuery
    .input(z.object({ id: z.number(), status: z.enum(["found", "claimed", "returned", "disposed"]) }))
    .mutation(async ({ input }) => {
      await getDb().update(lostAndFound).set({ status: input.status }).where(eq(lostAndFound.id, input.id));
      return { success: true };
    }),
});
