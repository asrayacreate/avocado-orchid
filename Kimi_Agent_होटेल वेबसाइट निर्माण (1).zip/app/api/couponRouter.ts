import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { coupons, seasonalRates } from "@db/schema";
import { eq, and, gte, lte, desc } from "drizzle-orm";
import { rooms } from "@db/schema";

export const couponRouter = createRouter({
  // Public: Validate coupon code
  validate: publicQuery
    .input(z.object({ code: z.string(), totalAmount: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const coupon = await db.query.coupons.findFirst({
        where: eq(coupons.code, input.code.toUpperCase()),
      });

      if (!coupon || coupon.isActive !== "active") {
        return { valid: false, message: "Invalid coupon code" };
      }

      const now = new Date();
      if (new Date(coupon.validFrom) > now || new Date(coupon.validUntil) < now) {
        return { valid: false, message: "Coupon expired" };
      }

      if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) {
        return { valid: false, message: "Coupon usage limit reached" };
      }

      const discount =
        coupon.discountType === "percentage"
          ? Math.round((input.totalAmount * coupon.discountValue) / 100)
          : coupon.discountValue;

      return {
        valid: true,
        discount,
        finalAmount: Math.max(0, input.totalAmount - discount),
        coupon: {
          code: coupon.code,
          description: coupon.description,
          discountType: coupon.discountType,
          discountValue: coupon.discountValue,
        },
      };
    }),

  // Public: Calculate dynamic price (room + seasonal + coupon)
  calculatePrice: publicQuery
    .input(
      z.object({
        roomId: z.number(),
        checkIn: z.string(),
        checkOut: z.string(),
        couponCode: z.string().optional(),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const room = await db.query.rooms.findFirst({
        where: eq(rooms.id, input.roomId),
      });
      if (!room) return { error: "Room not found" };

      const checkIn = new Date(input.checkIn);
      const checkOut = new Date(input.checkOut);
      const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));

      // Apply seasonal rate
      const seasonalRate = await db.query.seasonalRates.findFirst({
        where: and(
          eq(seasonalRates.roomId, input.roomId),
          eq(seasonalRates.isActive, "active"),
          lte(seasonalRates.startDate, checkIn),
          gte(seasonalRates.endDate, checkIn),
        ),
      });

      const multiplier = seasonalRate ? parseFloat(seasonalRate.multiplier as unknown as string) : 1;
      const basePrice = Math.round(room.pricePerNight * multiplier);
      let totalAmount = basePrice * nights;

      // Apply coupon
      let discount = 0;
      if (input.couponCode) {
        const couponResult = await db.query.coupons.findFirst({
          where: eq(coupons.code, input.couponCode.toUpperCase()),
        });
        if (couponResult && couponResult.isActive === "active") {
          discount =
            couponResult.discountType === "percentage"
              ? Math.round((totalAmount * couponResult.discountValue) / 100)
              : Math.min(couponResult.discountValue, totalAmount);
          totalAmount -= discount;
        }
      }

      return {
        nights,
        basePricePerNight: room.pricePerNight,
        seasonalMultiplier: multiplier,
        adjustedPricePerNight: basePrice,
        discount,
        totalAmount: Math.max(0, totalAmount),
        seasonalName: seasonalRate?.name || null,
      };
    }),

  // Admin: CRUD coupons
  list: adminQuery.query(async () => {
    return getDb().select().from(coupons).orderBy(desc(coupons.createdAt));
  }),

  create: adminQuery
    .input(
      z.object({
        code: z.string().min(3),
        description: z.string().optional(),
        discountType: z.enum(["percentage", "fixed"]),
        discountValue: z.number().min(1),
        maxUses: z.number().optional(),
        validFrom: z.string(),
        validUntil: z.string(),
      }),
    )
    .mutation(async ({ input }) => {
      const id = await getDb().insert(coupons).values({
        code: input.code.toUpperCase(),
        description: input.description || null,
        discountType: input.discountType,
        discountValue: input.discountValue,
        maxUses: input.maxUses || null,
        validFrom: new Date(input.validFrom),
        validUntil: new Date(input.validUntil),
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(coupons).where(eq(coupons.id, input.id));
      return { success: true };
    }),

  // Admin: Seasonal rates
  listSeasonal: adminQuery.query(async () => {
    return getDb().query.seasonalRates.findMany({
      with: { room: true },
      orderBy: desc(seasonalRates.createdAt),
    });
  }),

  createSeasonal: adminQuery
    .input(
      z.object({
        roomId: z.number(),
        name: z.string(),
        startDate: z.string(),
        endDate: z.string(),
        multiplier: z.string(),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb().insert(seasonalRates).values({
        roomId: input.roomId,
        name: input.name,
        startDate: new Date(input.startDate),
        endDate: new Date(input.endDate),
        multiplier: input.multiplier,
      });
      return { success: true };
    }),

  deleteSeasonal: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(seasonalRates).where(eq(seasonalRates.id, input.id));
      return { success: true };
    }),
});
