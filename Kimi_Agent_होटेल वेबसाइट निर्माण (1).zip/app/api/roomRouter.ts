import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { findAllRooms, findActiveRooms, findRoomBySlug, seedRooms } from "./queries/rooms";

export const roomRouter = createRouter({
  list: publicQuery.query(async () => {
    const rooms = await findActiveRooms();
    return rooms.map((r) => ({
      ...r,
      amenities: r.amenities ? JSON.parse(r.amenities as string) : [],
    }));
  }),

  listAll: publicQuery.query(async () => {
    return findAllRooms();
  }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const room = await findRoomBySlug(input.slug);
      if (!room) return null;
      return {
        ...room,
        amenities: room.amenities ? JSON.parse(room.amenities as string) : [],
      };
    }),

  seed: publicQuery.query(async () => {
    await seedRooms();
    return { success: true };
  }),
});
