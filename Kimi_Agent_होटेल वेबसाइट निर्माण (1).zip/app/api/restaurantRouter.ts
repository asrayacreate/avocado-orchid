import { z } from "zod";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { restaurantOrders } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const restaurantRouter = createRouter({
  list: adminQuery.query(async () => {
    return getDb().select().from(restaurantOrders).orderBy(desc(restaurantOrders.createdAt));
  }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ count: count() }).from(restaurantOrders);
    // Revenue tracking available here if needed
    const pending = await db.select({ count: count() }).from(restaurantOrders).where(eq(restaurantOrders.status, "pending"));
    const dineIn = await db.select({ count: count() }).from(restaurantOrders).where(eq(restaurantOrders.orderType, "dine_in"));
    const roomService = await db.select({ count: count() }).from(restaurantOrders).where(eq(restaurantOrders.orderType, "room_service"));
    return {
      total: total[0].count,
      pending: pending[0].count,
      dineIn: dineIn[0].count,
      roomService: roomService[0].count,
    };
  }),

  create: adminQuery
    .input(z.object({
      tableNumber: z.string().optional(),
      guestName: z.string().min(1),
      roomNumber: z.string().optional(),
      items: z.string().min(1),
      totalAmount: z.number().min(0),
      orderType: z.enum(["dine_in", "room_service", "takeaway"]).default("dine_in"),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(restaurantOrders).values({
        tableNumber: input.tableNumber || null,
        guestName: input.guestName,
        roomNumber: input.roomNumber || null,
        items: input.items,
        totalAmount: input.totalAmount,
        orderType: input.orderType,
        notes: input.notes || null,
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  updateStatus: adminQuery
    .input(z.object({ id: z.number(), status: z.enum(["pending", "preparing", "ready", "served", "cancelled"]) }))
    .mutation(async ({ input }) => {
      await getDb().update(restaurantOrders).set({ status: input.status }).where(eq(restaurantOrders.id, input.id));
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(restaurantOrders).where(eq(restaurantOrders.id, input.id));
      return { success: true };
    }),
});
