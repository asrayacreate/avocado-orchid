import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { loyaltyMembers, referrals } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const loyaltyRouter = createRouter({
  // ─── Loyalty Member ───
  getMember: publicQuery
    .input(z.object({ email: z.string().email() }))
    .query(async ({ input }) => {
      return getDb().query.loyaltyMembers.findFirst({
        where: eq(loyaltyMembers.guestEmail, input.email),
      });
    }),

  registerMember: publicQuery
    .input(z.object({ guestEmail: z.string().email(), guestName: z.string().optional() }))
    .mutation(async ({ input }) => {
      const existing = await getDb().query.loyaltyMembers.findFirst({
        where: eq(loyaltyMembers.guestEmail, input.guestEmail),
      });
      if (existing) return { success: true, id: existing.id, existing: true };

      const id = await getDb().insert(loyaltyMembers).values({
        guestEmail: input.guestEmail,
        guestName: input.guestName || null,
      }).$returningId();
      return { success: true, id: id[0].id, existing: false };
    }),

  addPoints: adminQuery
    .input(z.object({ email: z.string().email(), points: z.number(), amount: z.number() }))
    .mutation(async ({ input }) => {
      const member = await getDb().query.loyaltyMembers.findFirst({
        where: eq(loyaltyMembers.guestEmail, input.email),
      });
      if (!member) return { success: false, message: "Member not found" };

      const newPoints = member.totalPoints + input.points;
      const newSpent = member.totalSpent + input.amount;
      const visits = member.visitCount + 1;

      let tier: "bronze" | "silver" | "gold" | "platinum" = "bronze";
      if (newSpent >= 200000) tier = "platinum";
      else if (newSpent >= 100000) tier = "gold";
      else if (newSpent >= 50000) tier = "silver";

      await getDb().update(loyaltyMembers).set({
        totalPoints: newPoints,
        totalSpent: newSpent,
        visitCount: visits,
        tier,
      }).where(eq(loyaltyMembers.id, member.id));

      return { success: true, newPoints, tier };
    }),

  listMembers: adminQuery.query(async () => {
    return getDb().select().from(loyaltyMembers).orderBy(desc(loyaltyMembers.totalPoints));
  }),

  memberStats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ count: count() }).from(loyaltyMembers);
    const bronze = await db.select({ count: count() }).from(loyaltyMembers).where(eq(loyaltyMembers.tier, "bronze"));
    const silver = await db.select({ count: count() }).from(loyaltyMembers).where(eq(loyaltyMembers.tier, "silver"));
    const gold = await db.select({ count: count() }).from(loyaltyMembers).where(eq(loyaltyMembers.tier, "gold"));
    const platinum = await db.select({ count: count() }).from(loyaltyMembers).where(eq(loyaltyMembers.tier, "platinum"));
    return { total: total[0].count, bronze: bronze[0].count, silver: silver[0].count, gold: gold[0].count, platinum: platinum[0].count };
  }),

  // ─── Referrals ───
  createReferral: publicQuery
    .input(z.object({
      referrerEmail: z.string().email(),
      refereeName: z.string().min(1),
      refereeEmail: z.string().email(),
    }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(referrals).values({
        referrerEmail: input.referrerEmail,
        refereeName: input.refereeName,
        refereeEmail: input.refereeEmail,
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  listReferrals: adminQuery.query(async () => {
    return getDb().select().from(referrals).orderBy(desc(referrals.createdAt));
  }),

  updateReferralStatus: adminQuery
    .input(z.object({ id: z.number(), status: z.enum(["pending", "booked", "completed", "rewarded"]) }))
    .mutation(async ({ input }) => {
      await getDb().update(referrals).set({ status: input.status }).where(eq(referrals.id, input.id));
      return { success: true };
    }),
});
