import { getDb } from "../queries/connection";
import { bookings } from "@db/schema";
import { eq } from "drizzle-orm";

// Phase 3: Generate invoice HTML
export function generateInvoiceHTML(booking: {
  id: number;
  guestName: string;
  guestEmail: string;
  checkIn: Date;
  checkOut: Date;
  totalNights: number;
  totalAmount: number;
  roomId: number;
  paymentStatus: string;
  paymentMethod: string | null;
  createdAt: Date;
}) {
  const invoiceNumber = `INV-${String(booking.id).padStart(5, "0")}`;
  const date = new Date(booking.createdAt).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const checkIn = new Date(booking.checkIn).toLocaleDateString("en-US");
  const checkOut = new Date(booking.checkOut).toLocaleDateString("en-US");

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Invoice ${invoiceNumber}</title>
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; max-width: 700px; margin: 0 auto; padding: 30px; color: #333; }
    .header { text-align: center; border-bottom: 2px solid #2d5a2d; padding-bottom: 20px; margin-bottom: 30px; }
    .header h1 { color: #2d5a2d; font-size: 28px; margin: 0; }
    .header p { color: #888; margin: 5px 0; }
    .invoice-details { display: flex; justify-content: space-between; margin-bottom: 30px; }
    .section { margin-bottom: 25px; }
    .section h3 { color: #2d5a2d; border-bottom: 1px solid #eee; padding-bottom: 8px; margin-bottom: 15px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    th { background: #f5f0e8; color: #2d5a2d; text-align: left; padding: 12px; }
    td { padding: 12px; border-bottom: 1px solid #eee; }
    .total { text-align: right; font-size: 20px; font-weight: bold; color: #2d5a2d; }
    .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; color: #888; font-size: 12px; }
    .status { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
    .status.paid { background: #d4edda; color: #155724; }
    .status.pending { background: #fff3cd; color: #856404; }
  </style>
</head>
<body>
  <div class="header">
    <h1>Avocado & Orchid Resort</h1>
    <p>Chaukitol 2, Tribhuvan Rajpath, Hetauda 44107, Nepal</p>
    <p>Tel: +977 980 1804340 | info@avocadoresort.com</p>
  </div>

  <div class="invoice-details">
    <div>
      <p><strong>Invoice To:</strong><br>${booking.guestName}<br>${booking.guestEmail}</p>
    </div>
    <div style="text-align: right;">
      <p><strong>Invoice #:</strong> ${invoiceNumber}<br>
      <strong>Date:</strong> ${date}<br>
      <strong>Status:</strong> <span class="status ${booking.paymentStatus === "Paid" ? "paid" : "pending"}">${booking.paymentStatus}</span></p>
    </div>
  </div>

  <div class="section">
    <h3>Booking Details</h3>
    <table>
      <tr><th>Description</th><th>Details</th></tr>
      <tr><td>Room ID</td><td>#${booking.roomId}</td></tr>
      <tr><td>Check-in</td><td>${checkIn}</td></tr>
      <tr><td>Check-out</td><td>${checkOut}</td></tr>
      <tr><td>Duration</td><td>${booking.totalNights} night(s)</td></tr>
      <tr><td>Payment Method</td><td>${booking.paymentMethod || "N/A"}</td></tr>
    </table>
  </div>

  <div class="section">
    <h3>Payment Summary</h3>
    <table>
      <tr><th>Item</th><th style="text-align: right;">Amount (NPR)</th></tr>
      <tr><td>Room Charges (${booking.totalNights} nights)</td><td style="text-align: right;">${booking.totalAmount.toLocaleString()}</td></tr>
      <tr style="font-weight: bold;"><td>Total</td><td style="text-align: right; color: #2d5a2d;">NPR ${booking.totalAmount.toLocaleString()}</td></tr>
    </table>
  </div>

  <div class="footer">
    <p>Thank you for choosing Avocado & Orchid Resort!</p>
    <p>Hetauda's only resort with fresh Avocado & Orchid Garden</p>
  </div>
</body>
</html>`;
}

// Phase 3: Send booking confirmation email (simulated)
export async function sendBookingConfirmation(bookingId: number) {
  const db = getDb();
  const booking = await db.query.bookings.findFirst({
    where: eq(bookings.id, bookingId),
  });
  if (!booking) return { success: false, message: "Booking not found" };

  const invoiceHtml = generateInvoiceHTML(booking);

  // In production: Use Resend API here
  // await resend.emails.send({ from, to: booking.guestEmail, subject, html: invoiceHtml });

  console.log(`[EMAIL] Booking confirmation sent to ${booking.guestEmail}`);

  return {
    success: true,
    message: `Confirmation email sent to ${booking.guestEmail}`,
    invoiceHtml,
  };
}

// Phase 3: Send check-in reminder (24 hours before)
export async function sendCheckInReminders() {
  const db = getDb();
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(0, 0, 0, 0);

  const dayAfter = new Date(tomorrow);
  dayAfter.setDate(dayAfter.getDate() + 1);

  const upcomingBookings = await db
    .select()
    .from(bookings)
    .where(eq(bookings.checkIn, tomorrow));

  for (const booking of upcomingBookings) {
    if (booking.status === "confirmed") {
      console.log(`[REMINDER] Check-in reminder for ${booking.guestName} (${booking.guestEmail})`);
      // In production: await resend.emails.send({...})
    }
  }

  return { sent: upcomingBookings.length };
}

// Phase 3: Generate PDF invoice data
export function generateInvoicePDFData(booking: {
  id: number;
  guestName: string;
  guestEmail: string;
  checkIn: Date;
  checkOut: Date;
  totalNights: number;
  totalAmount: number;
  roomId: number;
  paymentStatus: string;
  paymentMethod: string | null;
  createdAt: Date;
}) {
  return {
    invoiceNumber: `INV-${String(booking.id).padStart(5, "0")}`,
    guestName: booking.guestName,
    guestEmail: booking.guestEmail,
    checkIn: new Date(booking.checkIn).toLocaleDateString("en-US"),
    checkOut: new Date(booking.checkOut).toLocaleDateString("en-US"),
    totalNights: booking.totalNights,
    totalAmount: booking.totalAmount,
    roomId: booking.roomId,
    paymentStatus: booking.paymentStatus,
    paymentMethod: booking.paymentMethod || "N/A",
    date: new Date(booking.createdAt).toLocaleDateString("en-US"),
  };
}
