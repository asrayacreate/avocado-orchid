interface ICalEvent {
  start: Date;
  end: Date;
  summary: string;
  uid: string;
}

export function generateICalFeed({
  roomName,
  bookings,
}: {
  roomName: string;
  bookings: ICalEvent[];
}): string {
  const now = new Date().toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";

  let ical = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Avocado & Orchid Resort//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    `X-WR-CALNAME:${roomName} Availability`,
    "BEGIN:VTIMEZONE",
    "TZID:Asia/Kathmandu",
    "BEGIN:STANDARD",
    "DTSTART:19700101T000000",
    "TZOFFSETFROM:+0545",
    "TZOFFSETTO:+0545",
    "END:STANDARD",
    "END:VTIMEZONE",
  ].join("\r\n");

  for (const booking of bookings) {
    const start = new Date(booking.start).toISOString().replace(/[-:]/g, "").split(".")[0];
    const end = new Date(booking.end).toISOString().replace(/[-:]/g, "").split(".")[0];

    ical += [
      "",
      "BEGIN:VEVENT",
      `DTSTART;VALUE=DATE:${start.slice(0, 8)}`,
      `DTEND;VALUE=DATE:${end.slice(0, 8)}`,
      `SUMMARY:${booking.summary}`,
      `UID:${booking.uid}`,
      `DTSTAMP:${now}`,
      "STATUS:CONFIRMED",
      "END:VEVENT",
    ].join("\r\n");
  }

  ical += "\r\nEND:VCALENDAR";
  return ical;
}

export function parseICalFeed(icalData: string): Array<{ start: Date; end: Date; summary: string }> {
  const events: Array<{ start: Date; end: Date; summary: string }> = [];
  const lines = icalData.split(/\r?\n/);
  
  let inEvent = false;
  let currentEvent: Partial<{ start: Date; end: Date; summary: string }> = {};

  for (const line of lines) {
    const trimmed = line.trim();

    if (trimmed === "BEGIN:VEVENT") {
      inEvent = true;
      currentEvent = {};
    } else if (trimmed === "END:VEVENT") {
      inEvent = false;
      if (currentEvent.start && currentEvent.end) {
        events.push({
          start: currentEvent.start,
          end: currentEvent.end,
          summary: currentEvent.summary || "Blocked",
        });
      }
    } else if (inEvent) {
      if (trimmed.startsWith("DTSTART")) {
        const val = trimmed.split(":").pop() || "";
        currentEvent.start = parseICalDate(val);
      } else if (trimmed.startsWith("DTEND")) {
        const val = trimmed.split(":").pop() || "";
        currentEvent.end = parseICalDate(val);
      } else if (trimmed.startsWith("SUMMARY:")) {
        currentEvent.summary = trimmed.replace("SUMMARY:", "");
      }
    }
  }

  return events;
}

function parseICalDate(val: string): Date {
  if (val.includes("T")) {
    const y = val.slice(0, 4);
    const m = val.slice(4, 6);
    const d = val.slice(6, 8);
    return new Date(`${y}-${m}-${d}T00:00:00+05:45`);
  }
  const y = val.slice(0, 4);
  const m = val.slice(4, 6);
  const d = val.slice(6, 8);
  return new Date(`${y}-${m}-${d}T00:00:00+05:45`);
}
