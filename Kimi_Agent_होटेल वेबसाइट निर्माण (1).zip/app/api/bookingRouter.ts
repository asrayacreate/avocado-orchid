import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import {
  createBooking,
  findAllBookings,
  updateBookingStatus,
  updatePaymentStatus,
  deleteBooking,
  getBookingStats,
  getRecentBookings,
  getBookingsByMonth,
  getOccupancyRate,
} from "./queries/bookings";

export const bookingRouter = createRouter({
  // Public: Create a booking
  create: publicQuery
    .input(
      z.object({
        roomId: z.number().min(1),
        guestName: z.string().min(1),
        guestEmail: z.string().email(),
        guestPhone: z.string().optional(),
        checkIn: z.string(),
        checkOut: z.string(),
        adults: z.number().min(1).max(10),
        children: z.number().min(0).max(10),
        totalNights: z.number().min(1),
        totalAmount: z.number().min(0),
        specialRequests: z.string().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const id = await createBooking({
        ...input,
        checkIn: new Date(input.checkIn),
        checkOut: new Date(input.checkOut),
        specialRequests: input.specialRequests || null,
        guestPhone: input.guestPhone || null,
      });
      return { success: true, bookingId: id.id };
    }),

  // Phase 1: Initiate Payment (simulated - structure ready for Khalti/eSewa)
  initiatePayment: publicQuery
    .input(
      z.object({
        bookingId: z.number(),
        method: z.enum(["Khalti", "eSewa", "Stripe", "PayPal"]),
        amount: z.number().min(1),
      }),
    )
    .mutation(async ({ input }) => {
      // Simulate payment gateway initialization
      // In production: Call Khalti/eSewa/Stripe API here
      const mockPaymentId = `PAY_${Date.now()}_${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      
      await updatePaymentStatus(input.bookingId, "Pending", mockPaymentId, input.method);
      
      return {
        success: true,
        paymentId: mockPaymentId,
        paymentUrl: `/api/payment/${input.method.toLowerCase()}/redirect?pid=${mockPaymentId}&amt=${input.amount}`,
        message: `Redirect to ${input.method} payment gateway`,
      };
    }),

  // Phase 1: Verify Payment (simulated callback)
  verifyPayment: publicQuery
    .input(
      z.object({
        paymentId: z.string(),
        bookingId: z.number(),
        status: z.enum(["success", "failed"]),
      }),
    )
    .mutation(async ({ input }) => {
      if (input.status === "success") {
        await updatePaymentStatus(input.bookingId, "Paid", input.paymentId);
        await updateBookingStatus(input.bookingId, "confirmed");
        return { success: true, message: "Payment verified successfully", status: "Paid" };
      } else {
        await updatePaymentStatus(input.bookingId, "Failed", input.paymentId);
        return { success: false, message: "Payment failed", status: "Failed" };
      }
    }),

  // Admin: List all bookings
  list: adminQuery.query(async () => {
    return findAllBookings();
  }),

  // Admin: Get booking stats
  stats: adminQuery.query(async () => {
    return getBookingStats();
  }),

  // Admin: Get recent bookings
  recent: adminQuery.query(async () => {
    return getRecentBookings(10);
  }),

  // Phase 6: Monthly booking data for charts
  monthly: adminQuery
    .input(z.object({ year: z.number().default(2025) }))
    .query(async ({ input }) => {
      return getBookingsByMonth(input.year);
    }),

  // Phase 6: Occupancy rate
  occupancy: adminQuery.query(async () => {
    return getOccupancyRate();
  }),

  // Admin: Update booking status
  updateStatus: adminQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "cancelled", "completed"]),
      }),
    )
    .mutation(async ({ input }) => {
      await updateBookingStatus(input.id, input.status);
      return { success: true };
    }),

  // Admin: Delete booking
  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteBooking(input.id);
      return { success: true };
    }),
});
