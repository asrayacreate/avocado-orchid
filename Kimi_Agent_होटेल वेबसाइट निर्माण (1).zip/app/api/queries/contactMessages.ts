import { getDb } from "./connection";
import { contactMessages } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";
import type { InsertContactMessage } from "@db/schema";

export async function createContactMessage(data: Omit<InsertContactMessage, "id" | "createdAt" | "isRead">) {
  const result = await getDb().insert(contactMessages).values(data).$returningId();
  return result[0];
}

export async function findAllMessages() {
  return getDb().select().from(contactMessages).orderBy(desc(contactMessages.createdAt));
}

export async function findUnreadMessages() {
  return getDb()
    .select()
    .from(contactMessages)
    .where(eq(contactMessages.isRead, "unread"))
    .orderBy(desc(contactMessages.createdAt));
}

export async function markMessageAsRead(id: number) {
  return getDb().update(contactMessages).set({ isRead: "read" }).where(eq(contactMessages.id, id));
}

export async function deleteMessage(id: number) {
  return getDb().delete(contactMessages).where(eq(contactMessages.id, id));
}

export async function getMessageStats() {
  const db = getDb();
  const total = await db.select({ count: count() }).from(contactMessages);
  const unread = await db.select({ count: count() }).from(contactMessages).where(eq(contactMessages.isRead, "unread"));
  
  return {
    total: total[0].count,
    unread: unread[0].count,
  };
}
