import { getDb } from "./connection";
import { rooms } from "@db/schema";
import { eq } from "drizzle-orm";

export async function findAllRooms() {
  return getDb().query.rooms.findMany({
    orderBy: (rooms, { asc }) => [asc(rooms.pricePerNight)],
  });
}

export async function findRoomBySlug(slug: string) {
  return getDb().query.rooms.findFirst({
    where: eq(rooms.slug, slug),
  });
}

export async function findActiveRooms() {
  return getDb().select().from(rooms).where(eq(rooms.isActive, "active"));
}

export async function seedRooms() {
  const db = getDb();
  const existing = await db.select().from(rooms);
  if (existing.length > 0) return;

  await db.insert(rooms).values([
    {
      name: "Deluxe A/C Room",
      slug: "deluxe",
      description: "Comfortable accommodation with 1 Twin Bed and 1 Double Bed option. Perfect for families or small groups seeking a cozy retreat with all essential amenities. Features garden views and modern furnishings.",
      pricePerNight: 3500,
      maxGuests: 3,
      sizeSqFt: 251,
      beds: "1 Twin Bed + 1 Double Bed",
      amenities: JSON.stringify(["Free Wi-Fi", "Flat-screen TV", "Air Conditioning", "Private Bathroom", "Daily Housekeeping", "Garden View", "Desk", "Electric Kettle", "Wardrobe", "Complimentary Toiletries"]),
      image: "/images/room-deluxe.jpg",
    },
    {
      name: "Super Deluxe A/C Room",
      slug: "super-deluxe",
      description: "Spacious room with 1 Double Bed or 2 Single Bed options. Enjoy premium comfort with enhanced furnishings, large windows with garden views, and a relaxing atmosphere designed for discerning travelers.",
      pricePerNight: 4500,
      maxGuests: 2,
      sizeSqFt: 287,
      beds: "1 Double Bed or 2 Single Beds",
      amenities: JSON.stringify(["Free Wi-Fi", "Flat-screen TV", "Minibar", "Air Conditioning", "Private Bathroom", "Daily Housekeeping", "Garden View", "Desk", "Room Service", "Complimentary Toiletries"]),
      image: "/images/room-super-deluxe.jpg",
    },
    {
      name: "Semi Suite",
      slug: "semi-suite",
      description: "Elegant semi-suite featuring 1 Double Bed with a separate seating area. Enhanced amenities for a more luxurious experience, including garden views and refined decor that reflects the natural beauty of our resort.",
      pricePerNight: 5500,
      maxGuests: 2,
      sizeSqFt: 287,
      beds: "1 Double Bed",
      amenities: JSON.stringify(["Free Wi-Fi", "Flat-screen TV", "Minibar", "Air Conditioning", "Private Bathroom", "Daily Housekeeping", "Garden View", "Seating Area", "Room Service", "Slippers"]),
      image: "/images/room-semi-suite.jpg",
    },
    {
      name: "Suite Room",
      slug: "suite",
      description: "Our most luxurious accommodation featuring 1 Double Bed and 2 Single Beds. The suite includes a minibar, refrigerator, and separate living area. Maximum space and comfort for families or guests seeking the ultimate resort experience.",
      pricePerNight: 7500,
      maxGuests: 4,
      sizeSqFt: 538,
      beds: "1 Double Bed + 2 Single Beds",
      amenities: JSON.stringify(["Free Wi-Fi", "Flat-screen TV", "Minibar", "Refrigerator", "Air Conditioning", "Private Bathroom", "Daily Housekeeping", "Living Area", "Room Service", "Premium Toiletries"]),
      image: "/images/room-suite.jpg",
    },
  ]);
}
