import { getDb } from "./connection";
import { bookings } from "@db/schema";
import { eq, desc, sql, count } from "drizzle-orm";
import type { InsertBooking } from "@db/schema";

export async function createBooking(data: Omit<InsertBooking, "id" | "createdAt" | "updatedAt">) {
  const result = await getDb().insert(bookings).values(data).$returningId();
  return result[0];
}

export async function findAllBookings() {
  return getDb().select().from(bookings).orderBy(desc(bookings.createdAt));
}

export async function updateBookingStatus(id: number, status: "pending" | "confirmed" | "cancelled" | "completed") {
  return getDb().update(bookings).set({ status }).where(eq(bookings.id, id));
}

export async function updatePaymentStatus(
  id: number,
  paymentStatus: "Pending" | "Paid" | "Failed",
  paymentId?: string,
  paymentMethod?: string
) {
  return getDb()
    .update(bookings)
    .set({ paymentStatus, paymentId: paymentId || null, paymentMethod: paymentMethod || null })
    .where(eq(bookings.id, id));
}

export async function updateInvoiceUrl(id: number, invoiceUrl: string) {
  return getDb().update(bookings).set({ invoiceUrl }).where(eq(bookings.id, id));
}

export async function deleteBooking(id: number) {
  return getDb().delete(bookings).where(eq(bookings.id, id));
}

export async function getBookingStats() {
  const db = getDb();
  const totalBookings = await db.select({ count: count() }).from(bookings);
  const pendingBookings = await db.select({ count: count() }).from(bookings).where(eq(bookings.status, "pending"));
  const confirmedBookings = await db.select({ count: count() }).from(bookings).where(eq(bookings.status, "confirmed"));
  const totalRevenue = await db.select({ total: sql<number>`COALESCE(SUM(${bookings.totalAmount}), 0)` }).from(bookings).where(eq(bookings.status, "confirmed"));
  const paidBookings = await db.select({ count: count() }).from(bookings).where(eq(bookings.paymentStatus, "Paid"));
  
  return {
    total: totalBookings[0].count,
    pending: pendingBookings[0].count,
    confirmed: confirmedBookings[0].count,
    paid: paidBookings[0].count,
    revenue: totalRevenue[0].total,
  };
}

export async function getRecentBookings(limit = 5) {
  return getDb()
    .select()
    .from(bookings)
    .orderBy(desc(bookings.createdAt))
    .limit(limit);
}

export async function getBookingsByMonth(year: number) {
  const db = getDb();
  return db
    .select({
      month: sql<number>`MONTH(${bookings.createdAt})`,
      count: count(),
      revenue: sql<number>`COALESCE(SUM(CASE WHEN ${bookings.status} = 'confirmed' THEN ${bookings.totalAmount} ELSE 0 END), 0)`,
    })
    .from(bookings)
    .where(sql`YEAR(${bookings.createdAt}) = ${year}`)
    .groupBy(sql`MONTH(${bookings.createdAt})`);
}

export async function getOccupancyRate() {
  const db = getDb();
  const totalConfirmed = await db.select({ count: count() }).from(bookings).where(eq(bookings.status, "confirmed"));
  const totalCompleted = await db.select({ count: count() }).from(bookings).where(eq(bookings.status, "completed"));
  const totalRooms = await db.select({ count: count() }).from(bookings);
  
  const total = totalRooms[0].count || 1;
  return {
    occupancy: Math.round(((totalConfirmed[0].count + totalCompleted[0].count) / total) * 100),
    totalConfirmed: totalConfirmed[0].count,
    totalCompleted: totalCompleted[0].count,
  };
}
