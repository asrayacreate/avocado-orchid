import { z } from "zod";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { cashRegisters, expenses } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const accountingRouter = createRouter({
  // ─── Cash Register ───
  getOrCreateRegister: adminQuery
    .input(z.object({ date: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(cashRegisters).where(eq(cashRegisters.date, new Date(input.date)));
      if (existing.length > 0) return existing[0];

      // Get yesterday's closing balance
      const yesterday = new Date(input.date);
      yesterday.setDate(yesterday.getDate() - 1);
      const prev = await db.select().from(cashRegisters).where(eq(cashRegisters.date, yesterday));
      const openingBalance = prev[0]?.closingBalance || 0;

      const id = await db.insert(cashRegisters).values({
        date: new Date(input.date),
        openingBalance,
      }).$returningId();
      return db.select().from(cashRegisters).where(eq(cashRegisters.id, id[0].id)).then(r => r[0]);
    }),

  closeRegister: adminQuery
    .input(z.object({
      date: z.string(),
      closingBalance: z.number(),
      notes: z.string().optional(),
      closedBy: z.string(),
    }))
    .mutation(async ({ input }) => {
      await getDb().update(cashRegisters).set({
        closingBalance: input.closingBalance,
        notes: input.notes || null,
        closedBy: input.closedBy,
        isClosed: "yes",
      }).where(eq(cashRegisters.date, new Date(input.date)));
      return { success: true };
    }),

  // ─── Expenses ───
  expenseList: adminQuery.query(async () => {
    return getDb().select().from(expenses).orderBy(desc(expenses.createdAt));
  }),

  expenseStats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ total: sql<number>`COALESCE(SUM(${expenses.amount}), 0)` }).from(expenses);
    const byCategory = await db.select({
      category: expenses.category,
      total: sql<number>`COALESCE(SUM(${expenses.amount}), 0)`,
    }).from(expenses).groupBy(expenses.category);
    return { total: total[0].total, byCategory };
  }),

  createExpense: adminQuery
    .input(z.object({
      category: z.enum(["salary", "electricity", "water", "food", "maintenance", "marketing", "tax", "other"]),
      description: z.string().min(1),
      amount: z.number().min(1),
      paidTo: z.string().optional(),
      date: z.string(),
      createdBy: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(expenses).values({
        category: input.category,
        description: input.description,
        amount: input.amount,
        paidTo: input.paidTo || null,
        date: new Date(input.date),
        createdBy: input.createdBy || null,
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  deleteExpense: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(expenses).where(eq(expenses.id, input.id));
      return { success: true };
    }),

  // ─── GST Report ───
  gstReport: adminQuery
    .input(z.object({ month: z.number(), year: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const startDate = `${input.year}-${String(input.month).padStart(2, '0')}-01`;
      const endDate = `${input.year}-${String(input.month).padStart(2, '0')}-31`;
      const totalExpenses = await db.select({ total: sql<number>`COALESCE(SUM(${expenses.amount}), 0)` })
        .from(expenses)
        .where(sql`${expenses.date} >= ${startDate} AND ${expenses.date} <= ${endDate}`);
      return {
        month: input.month,
        year: input.year,
        totalExpenses: totalExpenses[0].total,
        gstRate: 13,
        gstAmount: Math.round(totalExpenses[0].total * 0.13),
      };
    }),
});
