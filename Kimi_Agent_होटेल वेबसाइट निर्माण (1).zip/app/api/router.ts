import { authRouter } from "./auth-router";
import { roomRouter } from "./roomRouter";
import { bookingRouter } from "./bookingRouter";
import { contactRouter } from "./contactRouter";
import { adminRouter } from "./adminRouter";
import { icalRouter } from "./icalRouter";
import { couponRouter } from "./couponRouter";
import { taskRouter } from "./taskRouter";
import { inboxRouter } from "./inboxRouter";
import { checkinRouter } from "./checkinRouter";
import { restaurantRouter } from "./restaurantRouter";
import { staffRouter } from "./staffRouter";
import { automationRouter } from "./automationRouter";
import { housekeepingRouter } from "./housekeepingRouter";
import { accountingRouter } from "./accountingRouter";
import { loyaltyRouter } from "./loyaltyRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  room: roomRouter,
  booking: bookingRouter,
  contact: contactRouter,
  admin: adminRouter,
  ical: icalRouter,
  coupon: couponRouter,
  task: taskRouter,
  inbox: inboxRouter,
  checkin: checkinRouter,
  restaurant: restaurantRouter,
  staff: staffRouter,
  automation: automationRouter,
  housekeeping: housekeepingRouter,
  accounting: accountingRouter,
  loyalty: loyaltyRouter,
});

export type AppRouter = typeof appRouter;
