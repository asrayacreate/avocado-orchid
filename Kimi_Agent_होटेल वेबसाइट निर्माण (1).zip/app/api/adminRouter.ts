import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, rooms, bookings } from "@db/schema";
import { count } from "drizzle-orm";
import { getBookingStats, getRecentBookings, getBookingsByMonth, getOccupancyRate } from "./queries/bookings";
import { getMessageStats, findUnreadMessages } from "./queries/contactMessages";
import { sendCheckInReminders } from "./utils/notification";
import { z } from "zod";

export const adminRouter = createRouter({
  // Dashboard overview stats
  dashboard: adminQuery.query(async () => {
    const db = getDb();
    
    const totalUsers = await db.select({ count: count() }).from(users);
    const totalRooms = await db.select({ count: count() }).from(rooms);
    const bookingStats = await getBookingStats();
    const messageStats = await getMessageStats();
    const recentBookings = await getRecentBookings(5);
    const recentMessages = await findUnreadMessages();
    const occupancy = await getOccupancyRate();
    
    return {
      users: totalUsers[0].count,
      rooms: totalRooms[0].count,
      bookings: bookingStats,
      messages: messageStats,
      occupancy,
      recentBookings,
      recentMessages,
    };
  }),

  // Phase 6: Monthly analytics for charts
  analytics: adminQuery
    .input(z.object({ year: z.number().default(2025) }))
    .query(async ({ input }) => {
      const monthly = await getBookingsByMonth(input.year);
      const occupancy = await getOccupancyRate();
      return { monthly, occupancy };
    }),

  // Phase 6: Export bookings as CSV data
  exportBookings: adminQuery.query(async () => {
    const allBookings = await getDb().select().from(bookings).orderBy(bookings.createdAt);
    return allBookings.map((b) => ({
      id: b.id,
      guestName: b.guestName,
      guestEmail: b.guestEmail,
      guestPhone: b.guestPhone,
      roomId: b.roomId,
      checkIn: new Date(b.checkIn).toISOString().split("T")[0],
      checkOut: new Date(b.checkOut).toISOString().split("T")[0],
      adults: b.adults,
      children: b.children,
      totalNights: b.totalNights,
      totalAmount: b.totalAmount,
      status: b.status,
      paymentStatus: b.paymentStatus,
      paymentMethod: b.paymentMethod,
      createdAt: new Date(b.createdAt).toISOString(),
    }));
  }),

  // Phase 3: Trigger check-in reminders
  sendReminders: adminQuery.mutation(async () => {
    const result = await sendCheckInReminders();
    return result;
  }),
});
