import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { bookings, rooms, calendarSync } from "@db/schema";
import { eq, and, gte } from "drizzle-orm";
import { generateICalFeed, parseICalFeed } from "./utils/ical";

export const icalRouter = createRouter({
  // Phase 2: Export iCal feed for a room (public URL for Booking.com/Agoda)
  exportFeed: publicQuery
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      
      const sync = await db.query.calendarSync.findFirst({
        where: eq(calendarSync.icalToken, input.token),
      });
      
      if (!sync) {
        return new Response("Calendar not found", { status: 404 });
      }

      const roomBookings = await db
        .select()
        .from(bookings)
        .where(
          and(
            eq(bookings.roomId, sync.roomId),
            eq(bookings.status, "confirmed"),
            gte(bookings.checkOut, new Date()),
          ),
        );

      const roomData = await db.query.rooms.findFirst({
        where: eq(rooms.id, sync.roomId),
      });

      const ical = generateICalFeed({
        roomName: roomData?.name || "Room",
        bookings: roomBookings.map((b) => ({
          start: b.checkIn,
          end: b.checkOut,
          summary: `Booked - ${b.guestName}`,
          uid: `booking-${b.id}@avocadoresort.com`,
        })),
      });

      return ical;
    }),

  // Phase 2: Import external iCal (from Booking.com/Agoda)
  importExternal: adminQuery
    .input(
      z.object({
        roomId: z.number(),
        source: z.enum(["booking.com", "agoda", "expedia"]),
        icalUrl: z.string().url(),
      }),
    )
    .mutation(async ({ input }) => {
      try {
        const response = await fetch(input.icalUrl);
        const icalData = await response.text();
        const events = parseICalFeed(icalData);

        // Mark dates as blocked in our system
        const db = getDb();
        for (const event of events) {
          await db.insert(bookings).values({
            roomId: input.roomId,
            guestName: `${input.source.toUpperCase()} Guest`,
            guestEmail: `ota@${input.source}`,
            checkIn: new Date(event.start),
            checkOut: new Date(event.end),
            adults: 2,
            children: 0,
            totalNights: Math.ceil((new Date(event.end).getTime() - new Date(event.start).getTime()) / (1000 * 60 * 60 * 24)),
            totalAmount: 0,
            status: "confirmed",
            paymentStatus: "Paid",
            paymentMethod: input.source,
          });
        }

        return { success: true, imported: events.length };
      } catch (error) {
        return { success: false, message: "Failed to import calendar" };
      }
    }),

  // Phase 2: Generate iCal token for a room
  generateToken: adminQuery
    .input(
      z.object({
        roomId: z.number(),
        source: z.string(),
      }),
    )
    .mutation(async ({ input }) => {
      const token = `AVO_${Date.now()}_${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
      
      await getDb().insert(calendarSync).values({
        roomId: input.roomId,
        source: input.source,
        icalToken: token,
      });

      return {
        success: true,
        token,
        feedUrl: `/api/ical/${token}.ics`,
      };
    }),

  // Phase 2: List sync configs
  listSyncs: adminQuery.query(async () => {
    return getDb().query.calendarSync.findMany({
      with: { room: true },
    });
  }),
});
