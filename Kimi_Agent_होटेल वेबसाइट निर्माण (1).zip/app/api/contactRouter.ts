import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import {
  createContactMessage,
  findAllMessages,
  findUnreadMessages,
  markMessageAsRead,
  deleteMessage,
  getMessageStats,
} from "./queries/contactMessages";

export const contactRouter = createRouter({
  // Public: Submit contact form
  submit: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        email: z.string().email(),
        phone: z.string().optional(),
        message: z.string().min(1),
      }),
    )
    .mutation(async ({ input }) => {
      const id = await createContactMessage({
        name: input.name,
        email: input.email,
        phone: input.phone || null,
        message: input.message,
      });
      return { success: true, messageId: id.id };
    }),

  // Admin: List all messages
  list: adminQuery.query(async () => {
    return findAllMessages();
  }),

  // Admin: List unread messages
  unread: adminQuery.query(async () => {
    return findUnreadMessages();
  }),

  // Admin: Get message stats
  stats: adminQuery.query(async () => {
    return getMessageStats();
  }),

  // Admin: Mark as read
  markRead: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await markMessageAsRead(input.id);
      return { success: true };
    }),

  // Admin: Delete message
  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteMessage(input.id);
      return { success: true };
    }),
});
