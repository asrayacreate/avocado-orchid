import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { inboxMessages } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

export const inboxRouter = createRouter({
  // Public: Submit guest message
  submit: publicQuery
    .input(z.object({
      guestName: z.string().min(1),
      guestEmail: z.string().email(),
      subject: z.string().optional(),
      message: z.string().min(1),
      channel: z.enum(["website", "email", "phone", "whatsapp"]).default("website"),
    }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(inboxMessages).values({
        guestName: input.guestName,
        guestEmail: input.guestEmail,
        subject: input.subject || null,
        message: input.message,
        channel: input.channel,
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  // Admin: List all messages
  list: adminQuery.query(async () => {
    return getDb().select().from(inboxMessages).orderBy(desc(inboxMessages.createdAt));
  }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ count: count() }).from(inboxMessages);
    const unreplied = await db.select({ count: count() }).from(inboxMessages).where(eq(inboxMessages.isReplied, "no"));
    return { total: total[0].count, unreplied: unreplied[0].count };
  }),

  reply: adminQuery
    .input(z.object({ id: z.number(), reply: z.string().min(1) }))
    .mutation(async ({ input, ctx }) => {
      await getDb().update(inboxMessages).set({
        reply: input.reply,
        isReplied: "yes",
        assignedTo: ctx.user?.name || "admin",
      }).where(eq(inboxMessages.id, input.id));
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(inboxMessages).where(eq(inboxMessages.id, input.id));
      return { success: true };
    }),
});
