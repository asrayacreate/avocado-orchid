import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { notificationLogs, chatbotConversations, reviewRequests } from "@db/schema";
import { eq, desc, count } from "drizzle-orm";

const chatbotResponses: Record<string, string> = {
  "check in": "Check-in time is 12:00 PM. Early check-in is available upon request.",
  "check out": "Check-out time is 11:00 AM. Late check-out can be arranged at reception.",
  "wifi": "Free high-speed Wi-Fi is available throughout the resort. Password: Avocado2025",
  "restaurant": "Our Avocado Restaurant is open daily from 6:30 AM to 11:00 PM. We serve Continental, Chinese, Indian & Nepalese cuisine.",
  "pool": "We have a beautiful pool area open from 7:00 AM to 8:00 PM.",
  "parking": "Yes, we offer complimentary parking for all guests.",
  "breakfast": "Breakfast is served from 6:30 AM to 10:30 AM at Avocado Restaurant.",
  "price": "Our room rates start from NPR 3,500/night for Deluxe rooms. Visit our Rooms page for detailed pricing.",
  "location": "We are located at Chaukitol 2, Tribhuvan Rajpath, Hetauda 44107, Nepal.",
  "phone": "You can reach us at +977 980 1804340.",
};

function getChatbotResponse(input: string): string {
  const lower = input.toLowerCase();
  for (const [key, response] of Object.entries(chatbotResponses)) {
    if (lower.includes(key)) return response;
  }
  return "Thank you for your message. Our team will get back to you shortly. For immediate assistance, please call +977 980 1804340.";
}

export const automationRouter = createRouter({
  // ─── Phase 7: Chatbot ───
  chatbot: publicQuery
    .input(z.object({ message: z.string(), sessionId: z.string(), guestName: z.string().optional() }))
    .mutation(async ({ input }) => {
      const response = getChatbotResponse(input.message);
      await getDb().insert(chatbotConversations).values({
        sessionId: input.sessionId,
        guestName: input.guestName || null,
        message: input.message,
        response,
      });
      return { response };
    }),

  chatHistory: adminQuery
    .input(z.object({ sessionId: z.string().optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      if (input.sessionId) {
        return db.select().from(chatbotConversations).where(eq(chatbotConversations.sessionId, input.sessionId)).orderBy(desc(chatbotConversations.createdAt));
      }
      return db.select().from(chatbotConversations).orderBy(desc(chatbotConversations.createdAt)).limit(50);
    }),

  // ─── Phase 7: Review Requests ───
  createReviewRequest: adminQuery
    .input(z.object({ bookingId: z.number(), guestEmail: z.string().email(), guestName: z.string().optional() }))
    .mutation(async ({ input }) => {
      const id = await getDb().insert(reviewRequests).values({
        bookingId: input.bookingId,
        guestEmail: input.guestEmail,
        guestName: input.guestName || null,
        status: "pending",
      }).$returningId();
      return { success: true, id: id[0].id };
    }),

  sendReviewRequest: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().update(reviewRequests).set({ status: "sent", sentAt: new Date() }).where(eq(reviewRequests.id, input.id));
      return { success: true };
    }),

  listReviewRequests: adminQuery.query(async () => {
    return getDb().select().from(reviewRequests).orderBy(desc(reviewRequests.createdAt));
  }),

  submitReview: publicQuery
    .input(z.object({ id: z.number(), rating: z.number().min(1).max(5), reviewText: z.string() }))
    .mutation(async ({ input }) => {
      await getDb().update(reviewRequests).set({
        status: "responded",
        rating: input.rating,
        reviewText: input.reviewText,
      }).where(eq(reviewRequests.id, input.id));
      return { success: true };
    }),

  // ─── Phase 7: Notification Logs ───
  notificationStats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ count: count() }).from(notificationLogs);
    const sent = await db.select({ count: count() }).from(notificationLogs).where(eq(notificationLogs.status, "sent"));
    return { total: total[0].count, sent: sent[0].count };
  }),
});
