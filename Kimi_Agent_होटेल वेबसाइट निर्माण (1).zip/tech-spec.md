# Tech Spec — Avocado & Orchid Resort

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^19.0 | UI framework |
| react-dom | ^19.0 | DOM renderer |
| react-router-dom | ^7.0 | Multi-page routing (Home, Rooms, Dining, Gallery) |
| gsap | ^3.12 | Core animation engine, ScrollTrigger, timelines |
| lenis | ^1.1 | Smooth scroll with inertia |
| lucide-react | ^0.400 | Icon system |
| tailwindcss | ^4.0 | Utility-first CSS |
| @tailwindcss/vite | ^4.0 | Tailwind Vite integration |
| vite | ^6.0 | Build tool |
| @vitejs/plugin-react | ^4.0 | React Vite plugin |
| typescript | ^5.6 | Type safety |
| @types/react | ^19.0 | React types |
| @types/react-dom | ^19.0 | ReactDOM types |

No shadcn/ui needed — this is a fully custom visual design with no standard UI patterns that would benefit from a component library.

---

## Component Inventory

### Layout (shared across all pages)

| Component | Source | Notes |
|-----------|--------|-------|
| Navigation | Custom | Fixed header with transparent → solid scroll transition, mobile hamburger overlay |
| Footer | Custom | 4-column footer with embedded map |
| BookingWidgetFAB | Custom | Floating FAB + expandable booking panel with date/guest/room-type selectors |
| SectionDivider | Custom | Reusable ornamental orchid divider between sections |
| ScrollReveal | Custom | Wrapper component using GSAP ScrollTrigger for the default reveal pattern |

### Home Page Sections

| Component | Notes |
|-----------|-------|
| HeroSection | Full-viewport, Ken Burns background, booking bar overlay at bottom, scroll indicator |
| AboutSection | Two-column asymmetric with floating circular badge, stats row |
| RoomShowcaseSection | Dark background, 4-column card grid (summary cards, not full detail) |
| WhyChooseUsSection | 3×2 feature icon grid |
| DiningSection | Two-column reversed layout with floating info card overlay |
| GallerySection | Asymmetric masonry grid (4-col, mixed spans) + lightbox |
| TestimonialsSection | Review carousel (3 visible, auto-play 5s) with nav arrows and dot indicators |
| NearbyAttractionsSection | 4-column attraction cards with distance badges |
| ContactCTASection | Two-column: contact info left, styled form card right |

### Sub-pages

| Page | Sections |
|------|----------|
| Rooms | RoomsHero, RoomListings (vertical detail cards with sticky filter bar) |
| Dining | DiningHero, RestaurantDetails (two alternating restaurant cards), BarLounge |
| Gallery | GalleryHero, PhotoGallery (masonry + category filter tabs + lightbox) |

### Reusable Components

| Component | Used By | Notes |
|-----------|---------|-------|
| Lightbox | GallerySection, PhotoGallery | Full-screen image viewer with keyboard nav, prev/next, close |
| ReviewCarousel | TestimonialsSection | Horizontal slider with auto-play, pause-on-hover, dot/arrow nav |

---

## Animation Implementation

| Animation | Library | Approach | Complexity |
|-----------|---------|----------|------------|
| Smooth scrolling | Lenis | Global Lenis instance connected to GSAP ticker | Low |
| Default scroll reveal (all sections) | GSAP + ScrollTrigger | `ScrollReveal` wrapper: opacity 0→1, translateY 40→0, stagger 0.12s, trigger at 80% viewport | Low |
| Hero Ken Burns zoom | GSAP | Continuous `scale(1.05)→scale(1)` over 8s on background image | Low |
| Hero entrance sequence | GSAP | Timeline: tagline → headline → sub → CTAs → badge, staggered delays 0.3–1.2s | Medium |
| Nav scroll transition | CSS + JS | JS threshold at 50px, CSS `transition` on background/color/shadow | Low |
| About image + badge reveal | GSAP + ScrollTrigger | Image: translateX(60)+scale(0.95)→0. Badge: scale(0)→1 with `back.out(1.7)` | Medium |
| Room cards stagger | GSAP + ScrollTrigger | Batch: translateY(60)→0, stagger 0.15s | Low |
| Gallery image stagger | GSAP + ScrollTrigger | Batch: opacity 0+scale(0.9)→1, stagger 0.08s | Low |
| Dining image + floating card | GSAP + ScrollTrigger | Image: translateX(-60)→0. Card: translateY(30)→0 with delay | Medium |
| Contact form card entrance | GSAP + ScrollTrigger | translateX(40)+rotate(1deg)→0 | Low |
| Room listing card alternation | GSAP + ScrollTrigger | Odd from left, even from right, translateX(±60)→0 | Medium |
| Testimonial carousel entrance | GSAP + ScrollTrigger | Cards: translateX(40)→0, stagger 0.1s | Low |
| Scroll indicator loop | CSS | `@keyframes` translateY loop, 1.5s ease-in-out infinite | Low |
| Booking widget expand/collapse | GSAP | scale(0.9→1), opacity(0→1), 0.3s, ease-out-expo | Low |
| Lightbox open/close | GSAP | Fade + scale transition | Low |
| Card hover effects | CSS | `transition: transform 0.3s, box-shadow 0.3s` — no JS needed | Low |
| Image hover zoom | CSS | `transition: transform 0.5s` — scale 1→1.05 within overflow:hidden | Low |
| Review carousel sliding | JS + CSS transform | translateX on container, CSS transition for smooth slide | Medium |

---

## State & Logic

This is a content-focused marketing site with minimal client-side state. No global state library needed.

### Booking Widget
- Open/close toggle (local `useState`)
- Form fields: dates, guests, room type (local state, uncontrolled acceptable)
- Submit: either redirects to external booking engine with URL params, or POSTs inquiry data

### Review Carousel
- Current slide index (`useState`)
- Auto-play timer (`useRef` + `setInterval`, paused on hover)
- Keyboard nav optional enhancement

### Gallery Lightbox
- Open/closed state + current image index (`useState`)
- Keyboard listeners: Left/Right/Escape (`useEffect`)
- Category filter on Gallery page (`useState` for active filter)

### Navigation
- Scroll threshold boolean (`useState` updated via scroll listener)
- Mobile menu open/close (`useState`)

### Lenis ↔ GSAP Integration
- Lenis `raf()` connected to `gsap.ticker` for synchronized scroll-driven animations
- Initialize once at app root level, expose via context or module-level singleton

---

## Other Key Decisions

**Multi-page routing**: React Router with 4 routes (`/`, `/rooms`, `/dining`, `/gallery`). Navigation scroll state and BookingWidgetFAB persist across all routes as layout-level components.

**No shadcn/ui**: The design is fully bespoke — every element has custom styling (colors, radii, shadows, hover states). Installing shadcn would add unused infrastructure without benefit.

**Image strategy**: ~14 generated images total. Hero and first-fold images loaded eagerly; all others lazy-loaded. No video assets needed — the Ken Burns effect on a static hero image replaces video.

**Google Maps**: Footer uses an embedded iframe preview (not an API integration). No `@react-google-maps/api` needed.
